"use strict";
exports.id = 507;
exports.ids = [507];
exports.modules = {

/***/ 2507:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _context_SidebarContext__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6812);
/* harmony import */ var _services_EnquiryService__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1086);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5641);
/* harmony import */ var _utils_toast__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8548);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_context_SidebarContext__WEBPACK_IMPORTED_MODULE_0__, _services_EnquiryService__WEBPACK_IMPORTED_MODULE_1__, react_hook_form__WEBPACK_IMPORTED_MODULE_3__]);
([_context_SidebarContext__WEBPACK_IMPORTED_MODULE_0__, _services_EnquiryService__WEBPACK_IMPORTED_MODULE_1__, react_hook_form__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const useAskForService = ()=>{
    const { register , handleSubmit , setValue , formState: { errors  } ,  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_3__.useForm)();
    const { 0: error , 1: setError  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const { isLoading , setIsLoading , askForPriceProduct , useAskForPriceProduct  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(_context_SidebarContext__WEBPACK_IMPORTED_MODULE_0__/* .SidebarContext */ .l);
    const { 0: shippingState , 1: setShippingState  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("select state");
    const submitHandler = async (data)=>{
        setError("");
        // const userInfo = {
        //   name: `${data.firstName} ${data.lastName}`,
        //   contact: data.contact,
        //   email: data.email,
        //   address: data.address,
        //   state: shippingState,
        //   city: data.city,
        //   zipCode: data.zipCode,
        //   message: data.message,
        // };
        // const userInfo = {
        //   name: `${data.firstName} ${data.lastName}`,
        //   contact: data.contact,
        //   email: data.email,
        //   address: data.address,
        //   state: shippingState,
        //   city: data.city,
        //   zipCode: data.zipCode,
        //   message: data.message,
        // };
        const userInfo = {
            productId: askForPriceProduct?._id,
            personalDetails: {
                firstName: data.firstName,
                lastName: data.lastName,
                emailAddress: data.email,
                phoneNumber: data.contact
            },
            shippingDetails: {
                streetAddress: data.address,
                state: shippingState,
                city: data.city,
                zipCode: data.zipCode
            },
            message: data.message
        };
        // console.log("userInfo", userInfo);
        _services_EnquiryService__WEBPACK_IMPORTED_MODULE_1__/* ["default"].Postaskforprice */ .Z.Postaskforprice(userInfo).then((res)=>{
            if (res?.success === true) {
                console.log("getEnquiry", res);
                (0,_utils_toast__WEBPACK_IMPORTED_MODULE_4__/* .notifySuccess */ .t5)("your Enquiry message sent successfully. We will contact you shortly.");
                setValue("firstName", "");
                setValue("lastName", "");
                setValue("email", "");
                setValue("contact", "");
                setValue("address", "");
                setValue("city", "");
                setValue("zipCode", "");
                setValue("message", "");
            }
        });
    };
    const stateData = [
        "Select state",
        "Andaman & Nicobar (UT)",
        "Andhra Pradesh",
        "Arunachal Pradesh",
        "Assam",
        "Bihar",
        "Chandigarh (UT)",
        "Chhattisgarh",
        "Dadra & Nagar Haveli and Daman & Diu (UT)",
        "Delhi [National Capital Territory (NCT)]",
        "Goa",
        "Gujarat",
        "Haryana",
        "Himachal Pradesh",
        "Jammu & Kashmir (UT)",
        "Jharkhand",
        "Karnataka",
        "Kerala",
        "Ladakh (UT)",
        "Lakshadweep (UT)",
        "Maharashtra",
        "Madhya Pradesh",
        "Manipur",
        "Meghalaya",
        "Mizoram",
        "Nagaland",
        "Odisha",
        "Puducherry (UT)",
        "Punjab",
        "Rajasthan",
        "Sikkim",
        "Tamil Nadu",
        "Tripura",
        "Telangana",
        "Uttar Pradesh",
        "Uttarakhand",
        "West Bengal", 
    ];
    return {
        handleSubmit,
        submitHandler,
        error,
        register,
        errors,
        setShippingState,
        shippingState,
        stateData
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useAskForService);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;