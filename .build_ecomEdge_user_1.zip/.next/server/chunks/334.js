"use strict";
exports.id = 334;
exports.ids = [334];
exports.modules = {

/***/ 1334:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8027);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9989);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_io5__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _hooks_useAsync__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9338);
/* harmony import */ var _services_CategoryServices__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5442);
/* harmony import */ var _component_preloader_CMSkeleton__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2038);
/* harmony import */ var _context_SidebarContext__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6812);
/* harmony import */ var _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(545);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_CategoryServices__WEBPACK_IMPORTED_MODULE_6__, _component_preloader_CMSkeleton__WEBPACK_IMPORTED_MODULE_7__, _context_SidebarContext__WEBPACK_IMPORTED_MODULE_8__, _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_9__]);
([_services_CategoryServices__WEBPACK_IMPORTED_MODULE_6__, _component_preloader_CMSkeleton__WEBPACK_IMPORTED_MODULE_7__, _context_SidebarContext__WEBPACK_IMPORTED_MODULE_8__, _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





//internal import





// ... (import statements)
const FeatureCategory = ()=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const { isLoading , setIsLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useContext)(_context_SidebarContext__WEBPACK_IMPORTED_MODULE_8__/* .SidebarContext */ .l);
    const { showingTranslateValue  } = (0,_hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)();
    const { 0: expandedCategoryId , 1: setExpandedCategoryId  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(null);
    const categoryRef = (0,react__WEBPACK_IMPORTED_MODULE_3__.useRef)(null); //expanded category list
    const { 0: showSubCategory , 1: setShowSubCategory  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({
        id: "",
        show: false
    });
    // Close the expanded category list when clicking outside of it
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        function handleClickOutside(event) {
            if (categoryRef.current && !categoryRef.current.contains(event.target)) {
                setExpandedCategoryId(null);
            }
        }
        // Add event listener when component mounts
        document.addEventListener("mousedown", handleClickOutside);
        // Remove event listener when component unmounts
        return ()=>{
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, []);
    const { data , error , loading  } = (0,_hooks_useAsync__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)(_services_CategoryServices__WEBPACK_IMPORTED_MODULE_6__/* ["default"].getShowingCategory */ .Z.getShowingCategory);
    const handleCategoryClick = (id, categoryName)=>{
        const category_name = categoryName.toLowerCase().replace(/[^A-Z0-9]+/gi, "-");
        const url = `/search?category=${category_name}&_id=${id}`;
        router.push(url);
        setIsLoading(!isLoading);
    };
    const toggleSubCategories = (categoryId)=>{
        setExpandedCategoryId((prev)=>prev === categoryId ? null : categoryId);
    };
    const handleSubNestedCategory = (id, title)=>{
        const name = title.toLowerCase().replace(/[^A-Z0-9]+/gi, "-");
        setShowSubCategory((prevState)=>({
                id: id,
                show: prevState.id === id ? !prevState.show : true
            }));
    };
    const handleSubChildrenCategory = (id, title)=>{
        const name = title.toLowerCase().replace(/[^A-Z0-9]+/gi, "-");
        router.push(`/search?category=${name}&_id=${id}`);
        setExpandedCategoryId(null);
        setIsLoading(!isLoading);
    };
    const { 0: isHovered , 1: setIsHovered  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const handleMouseEnter = ()=>{
        setIsHovered(true);
    };
    const handleMouseLeave = ()=>{
        setIsHovered(false);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "flex justify-center",
        children: loading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_preloader_CMSkeleton__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
            count: 10,
            height: 20,
            error: error,
            loading: loading
        }) : // <ul className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-6">
        //   {data[0]?.children?.map((category, i) => (
        //     <li className="group mr-" key={i + 1}>
        //       <div className="flex w-full h-full border border-gray-100 shadow-sm bg-white pl-1  cursor-pointer transition duration-200 ease-linear transform group-hover:shadow-lg   ">
        //         <div className="flex items-center">
        //           <div className="relative w-16 h-16 mt-3">
        //             <div>
        //               {category?.icon ? (
        //                 <img
        //                   src={category?.icon}
        //                   alt="category"
        //                   className="w-12 h-12 object-cover rounded-full"
        //                 />
        //               ) : (
        //                 <img
        //                   src="https://res.cloudinary.com/ahossain/image/upload/v1655097002/placeholder_kvepfp.png"
        //                   alt="category"
        //                   className="w-full h-full object-cover rounded-full"
        //                 />
        //               )}
        //             </div>
        //           </div>
        //           <div className="pl-4 flex-grow ">
        //             <div className="flex items-center justify-between  ">
        //               <h2
        //                 onClick={() =>
        //                   handleCategoryClick(category._id, category?.name)
        //                 }
        //                 className="text-base text-gray-600  font-serif font-medium leading-tight line-clamp-1 mr-2 group-hover "
        //               >
        //                 {category?.name}
        //               </h2>
        //               {category.children && (
        //                 <button
        //                   className="text-xl text-gray-400 cursor-pointer  "
        //                   onClick={() => toggleSubCategories(category._id)}
        //                 >
        //                   {expandedCategoryId === category._id ? (
        //                     <>
        //                       <IoChevronDownSharp />
        //                     </>
        //                   ) : (
        //                     category.children.length > 0 && (
        //                       <IoChevronForwardSharp />
        //                     )
        //                   )}
        //                 </button>
        //               )}
        //             </div>
        //             { expandedCategoryId === category._id && (
        //               <div
        //                 ref={categoryRef}
        //                 className="mt-8 w-full absolute bg-white border rounded-md shadow-md z-10"
        //               >
        //                 <ul
        //                   className="py-2 text-sm text-gray-600 dark:text-gray-500"
        //                   style={{ maxHeight: "200px", overflowY: "auto" }}
        //                 >
        //                   {category?.children?.map((child, index) => (
        //                     <li key={child._id} className="pt-1">
        //                       <a className="px-4 py-2 hover:bg-gray-100 flex items-center ">
        //                         <span
        //                           onClick={() =>
        //                             handleCategoryClick(child._id, child?.name)
        //                           }
        //                         >
        //                           {child?.name}
        //                         </span>
        //                         <div
        //                           onClick={() =>
        //                             handleSubNestedCategory(
        //                               child?._id,
        //                               child?.name
        //                             )
        //                           }
        //                           className="inline-flex items-center justify-between ml-3 text-sm font-medium w-full hover:text-gray-600 "
        //                         >
        //                           {child.children.length > 0 ? (
        //                             <span className="transition duration-700 ease-in-out inline-flex loading-none items-end text-gray-400  ">
        //                               {showSubCategory.id === child._id &&
        //                               showSubCategory.show ? (
        //                                 <IoChevronDownOutline />
        //                               ) : (
        //                                 <IoChevronForwardOutline />
        //                               )}
        //                             </span>
        //                           ) : null}
        //                         </div>
        //                       </a>
        //                       {showSubCategory.id === child._id &&
        //                       showSubCategory.show === true ? (
        //                         <ul className="pl-6 pb-3 ">
        //                           {child.children.map((subChildren) => (
        //                             <li
        //                               className="hover:bg-gray-100"
        //                               key={subChildren._id}
        //                             >
        //                               <a
        //                                 onClick={() =>
        //                                   handleSubChildrenCategory(
        //                                     subChildren._id,
        //                                     subChildren?.name
        //                                   )
        //                                 }
        //                                 className="font-serif py-1 px-2 text-sm   items-center cursor-pointer"
        //                               >
        //                                 {subChildren?.name}
        //                                 {showingTranslateValue(
        //                                   subChildren?.name
        //                                 )}
        //                               </a>
        //                             </li>
        //                           ))}
        //                         </ul>
        //                       ) : null}
        //                     </li>
        //                   ))}
        //                 </ul>
        //               </div>
        //             )}
        //           </div>
        //         </div>
        //       </div>
        //     </li>
        //   ))}
        // </ul>
        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "section--padding py-1",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "multicolumn page-width max-w-screen-xl mx-auto",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "slider-component flex flex-wrap justify-center gap-6",
                    children: data[0]?.children?.map((category)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "multicolumn-card w-full sm:w-1/2 md:w-1/4 lg:w-1/4 p-2",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "media-wrapper overflow-hidden rounded-full h-600",
                                    children: [
                                        " ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                            src: category?.icon,
                                            // alt={slide.alt}
                                            width: 500,
                                            height: 500,
                                            className: "media w-full h-auto object-cover transition-transform transform hover:scale-105 rounded-full" // Added rounded-full here as well
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "flex items-center pt-3 justify-center",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                        onClick: ()=>handleCategoryClick(category._id, category?.name),
                                        className: "text-base text-gray-600 font-serif text-4xl font-extrabold leading-tight line-clamp-1",
                                        children: category?.name
                                    })
                                })
                            ]
                        }, category.id))
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FeatureCategory);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;