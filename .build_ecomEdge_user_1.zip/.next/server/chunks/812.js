"use strict";
exports.id = 812;
exports.ids = [812];
exports.modules = {

/***/ 6812:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "H": () => (/* binding */ SidebarProvider),
/* harmony export */   "l": () => (/* binding */ SidebarContext)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _hooks_useNotification__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1941);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_useNotification__WEBPACK_IMPORTED_MODULE_1__]);
_hooks_useNotification__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



// create context
const SidebarContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_2__.createContext)();
const SidebarProvider = ({ children  })=>{
    const { 0: cartDrawerOpen , 1: setCartDrawerOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const { 0: notificationDrawerOpen , 1: setNotificationDrawerOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const { 0: categoryDrawerOpen , 1: setCategoryDrawerOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const { 0: isModalOpen , 1: setIsModalOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const { 0: currentPage , 1: setCurrentPage  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(1);
    const { 0: isLoading , 1: setIsLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const { 0: askForPriceProduct , 1: useAskForPriceProduct  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    // console.log('askForPriceProduct side',askForPriceProduct);
    const { socket  } = (0,_hooks_useNotification__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)();
    const toggleCartDrawer = ()=>setCartDrawerOpen(!cartDrawerOpen);
    const closeCartDrawer = ()=>setCartDrawerOpen(false);
    const toggleNotificationDrawer = ()=>setNotificationDrawerOpen(!notificationDrawerOpen);
    const closeNotificationDrawer = ()=>setNotificationDrawerOpen(false);
    const toggleCategoryDrawer = ()=>setCategoryDrawerOpen(!categoryDrawerOpen);
    const closeCategoryDrawer = ()=>setCategoryDrawerOpen(false);
    const toggleModal = ()=>setIsModalOpen(!isModalOpen);
    const closeModal = ()=>setIsModalOpen(false);
    const handleChangePage = (p)=>{
        setCurrentPage(p);
    };
    const value = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>({
            cartDrawerOpen,
            toggleCartDrawer,
            closeCartDrawer,
            setCartDrawerOpen,
            categoryDrawerOpen,
            toggleCategoryDrawer,
            closeCategoryDrawer,
            isModalOpen,
            toggleModal,
            closeModal,
            currentPage,
            setCurrentPage,
            handleChangePage,
            isLoading,
            setIsLoading,
            askForPriceProduct,
            useAskForPriceProduct,
            //  notification
            notificationDrawerOpen,
            setNotificationDrawerOpen,
            toggleNotificationDrawer,
            closeNotificationDrawer
        }), [
        cartDrawerOpen,
        notificationDrawerOpen,
        categoryDrawerOpen,
        isModalOpen,
        currentPage,
        isLoading,
        askForPriceProduct
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SidebarContext.Provider, {
        value: value,
        children: children
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1941:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _redux_slice_settingSlice__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4636);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var socket_io_client__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4612);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([socket_io_client__WEBPACK_IMPORTED_MODULE_3__]);
socket_io_client__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




// Create a single socket instance
// const socket = io(process.env.NEXT_PUBLIC_API_SOCKET_URL);
const useNotification = ()=>{
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useDispatch)();
    const { 0: socket , 1: setSocket  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        // setSocket(io(import.meta.env.VITE_APP_API_BASE_URL));
        setSocket((0,socket_io_client__WEBPACK_IMPORTED_MODULE_3__["default"])("https://tridyota.com"));
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        // Listen for the 'notification' event from the server
        socket?.on("notification", (notification)=>{
            // Update data in real-time here
            console.log("notification", notification);
            if (notification?.option === "globalSetting") {
                dispatch((0,_redux_slice_settingSlice__WEBPACK_IMPORTED_MODULE_0__/* .removeSetting */ .Wf)("globalSetting"));
                const globalSettingData = {
                    ...notification.globalSetting,
                    name: "globalSetting"
                };
                dispatch((0,_redux_slice_settingSlice__WEBPACK_IMPORTED_MODULE_0__/* .addSetting */ .XS)(globalSettingData));
            }
            if (notification?.option === "storeCustomizationSetting") {
                dispatch((0,_redux_slice_settingSlice__WEBPACK_IMPORTED_MODULE_0__/* .removeSetting */ .Wf)("storeCustomizationSetting"));
                const storeCustomizationSettingData = {
                    ...notification.storeCustomizationSetting,
                    name: "storeCustomizationSetting"
                };
                dispatch((0,_redux_slice_settingSlice__WEBPACK_IMPORTED_MODULE_0__/* .addSetting */ .XS)(storeCustomizationSettingData));
            }
        });
        return ()=>{
            // Disconnect the socket when the component unmounts
            socket?.disconnect();
        };
    }, [
        socket
    ]);
    return {
        socket
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useNotification);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4636:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Wf": () => (/* binding */ removeSetting),
/* harmony export */   "XS": () => (/* binding */ addSetting),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export clearSetting */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const settingSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "setting",
    initialState: {
        settingItem: []
    },
    reducers: {
        addSetting: (state, action)=>{
            const existsItem = state.settingItem.find((x)=>x.name === action.payload.name);
            if (existsItem) {
                return {
                    ...state,
                    settingItem: state.settingItem.map((x)=>{
                        if (x.name === existsItem.name) {
                            return x;
                        }
                        return x;
                    })
                };
            } else {
                return {
                    ...state,
                    settingItem: [
                        ...state.settingItem,
                        action.payload
                    ]
                };
            }
        },
        removeSetting: (state, action)=>{
            return {
                ...state,
                settingItem: state.settingItem.filter((x)=>x.name !== action.payload)
            };
        },
        clearSetting: (state)=>{
            return {
                ...state,
                settingItem: []
            };
        }
    }
});
const { addSetting , removeSetting , clearSetting  } = settingSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (settingSlice.reducer);


/***/ })

};
;