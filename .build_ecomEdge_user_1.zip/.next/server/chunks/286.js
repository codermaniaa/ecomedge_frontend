"use strict";
exports.id = 286;
exports.ids = [286];
exports.modules = {

/***/ 2574:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(543);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_use_cart__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9878);
/* harmony import */ var react_use_cart__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_use_cart__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9989);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_icons_io5__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _component_cart_CartItem__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9340);
/* harmony import */ var _component_modal_LoginModal__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1859);
/* harmony import */ var _context_UserContext__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5408);
/* harmony import */ var _context_SidebarContext__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6812);
/* harmony import */ var _services_SettingServices__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3644);
/* harmony import */ var _hooks_useAsync__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9338);
/* harmony import */ var _hooks_useCheckoutSubmit__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(7284);
/* harmony import */ var _hooks_useAddToCart__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1353);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_component_cart_CartItem__WEBPACK_IMPORTED_MODULE_6__, _component_modal_LoginModal__WEBPACK_IMPORTED_MODULE_7__, _context_UserContext__WEBPACK_IMPORTED_MODULE_8__, _context_SidebarContext__WEBPACK_IMPORTED_MODULE_9__, _services_SettingServices__WEBPACK_IMPORTED_MODULE_10__, _hooks_useCheckoutSubmit__WEBPACK_IMPORTED_MODULE_12__]);
([_component_cart_CartItem__WEBPACK_IMPORTED_MODULE_6__, _component_modal_LoginModal__WEBPACK_IMPORTED_MODULE_7__, _context_UserContext__WEBPACK_IMPORTED_MODULE_8__, _context_SidebarContext__WEBPACK_IMPORTED_MODULE_9__, _services_SettingServices__WEBPACK_IMPORTED_MODULE_10__, _hooks_useCheckoutSubmit__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






//internal import








const Cart = ()=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const { 0: modalOpen , 1: setModalOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const { isEmpty , items , cartTotal  } = (0,react_use_cart__WEBPACK_IMPORTED_MODULE_4__.useCart)();
    const { toggleCartDrawer , closeCartDrawer  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useContext)(_context_SidebarContext__WEBPACK_IMPORTED_MODULE_9__/* .SidebarContext */ .l);
    const { data: globalSetting  } = (0,_hooks_useAsync__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z)(_services_SettingServices__WEBPACK_IMPORTED_MODULE_10__/* ["default"].getGlobalSetting */ .Z.getGlobalSetting);
    const { handleAddItem , setItem , item  } = (0,_hooks_useAddToCart__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z)();
    const { total  } = (0,_hooks_useCheckoutSubmit__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z)();
    const currency = globalSetting?.default_currency || "₹";
    const { state: { userInfo  } ,  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useContext)(_context_UserContext__WEBPACK_IMPORTED_MODULE_8__/* .UserContext */ .S);
    const handleOpenLogin = ()=>{
        if (router.push("/?redirect=/checkout")) {
            toggleCartDrawer();
            setModalOpen(!modalOpen);
        }
    };
    const checkoutClass = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
        onClick: closeCartDrawer,
        className: "w-full py-3 px-3 rounded-lg bg-gray-800 hover:bg-gray-600 flex items-center justify-between bg-heading text-sm sm:text-base text-white focus:outline-none transition duration-300",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "align-middle font-medium font-serif",
                children: "Proceed To Checkout"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                className: "rounded-lg font-bold font-serif py-2 px-3 bg-white text-gray-600",
                children: [
                    currency,
                    parseFloat(total).toFixed(2)
                ]
            })
        ]
    });
    console.log("itemsforquantity", item);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            modalOpen && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_modal_LoginModal__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                modalOpen: modalOpen,
                setModalOpen: setModalOpen
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-col w-full h-full justify-between items-middle bg-white rounded cursor-pointer",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full flex justify-between items-center relative px-5 py-4 border-b bg-indigo-50 border-gray-100",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                                className: "font-semibold font-serif text-lg m-0 text-heading flex items-center",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text-xl mr-2 mb-1",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io5__WEBPACK_IMPORTED_MODULE_5__.IoBagCheckOutline, {})
                                    }),
                                    "Shopping Cart"
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                onClick: closeCartDrawer,
                                className: "inline-flex text-base items-center justify-center text-gray-500 p-2 focus:outline-none transition-opacity hover:text-red-400",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io5__WEBPACK_IMPORTED_MODULE_5__.IoClose, {}),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "font-sens text-sm text-gray-500 hover:text-red-400 ml-1",
                                        children: "Close"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "overflow-y-scroll flex-grow scrollbar-hide w-full max-h-full",
                        children: [
                            isEmpty && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex flex-col h-full justify-center",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex flex-col items-center",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "flex justify-center items-center w-20 h-20 rounded-full bg-gray-100",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-gray-600 text-4xl block",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io5__WEBPACK_IMPORTED_MODULE_5__.IoBagHandle, {})
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                            className: "font-serif font-semibold text-gray-700 text-lg pt-5",
                                            children: "Your cart is empty"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "px-12 text-center text-sm text-gray-500 pt-2",
                                            children: "No items added in your cart. Please add product to your cart list."
                                        })
                                    ]
                                })
                            }),
                            items.map((item, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_cart_CartItem__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                    item: item
                                }, i + 1))
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "mx-5 my-3",
                        children: items.length <= 0 ? checkoutClass : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            children: !userInfo ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                onClick: handleOpenLogin,
                                children: checkoutClass
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                href: "/checkout",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    children: checkoutClass
                                })
                            })
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Cart);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9340:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(543);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_use_cart__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9878);
/* harmony import */ var react_use_cart__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_use_cart__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2750);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _hooks_useAddToCart__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1353);
/* harmony import */ var _context_SidebarContext__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6812);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_context_SidebarContext__WEBPACK_IMPORTED_MODULE_6__]);
_context_SidebarContext__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





//internal import


const CartItem = ({ item , currency  })=>{
    const { updateItemQuantity , removeItem  } = (0,react_use_cart__WEBPACK_IMPORTED_MODULE_3__.useCart)();
    const { closeCartDrawer  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_SidebarContext__WEBPACK_IMPORTED_MODULE_6__/* .SidebarContext */ .l);
    const { handleIncreaseQuantity  } = (0,_hooks_useAddToCart__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)();
    const { isEmpty , items , cartTotal  } = (0,react_use_cart__WEBPACK_IMPORTED_MODULE_3__.useCart)();
    console.log("cartitem...", item);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "group w-full h-auto flex justify-start items-center bg-white py-3 px-4 border-b hover:bg-gray-50 transition-all border-gray-100 relative last:border-b-0",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "relative flex rounded-full border border-gray-100 shadow-sm overflow-hidden flex-shrink-0 cursor-pointer mr-4",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    src: item.image,
                    width: 40,
                    height: 40,
                    alt: item.title
                }, item.id)
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-col w-full overflow-hidden",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                        href: `/product/${item?.slug}`,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                            onClick: closeCartDrawer,
                            className: "truncate text-sm font-medium text-gray-700 text-heading line-clamp-1",
                            children: item.title
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: "text-xs text-gray-400 mb-1",
                        children: [
                            "Item Price ₹",
                            item.prices?.salePrice ? item.prices?.salePrice : item.prices
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex items-center justify-between",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "font-bold text-sm md:text-base text-heading leading-5",
                                children: item.prices?.salePrice ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                    children: [
                                        currency,
                                        (item.prices?.salePrice * item.quantity).toFixed(2)
                                    ]
                                }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                    children: [
                                        currency,
                                        (item.price * item.quantity).toFixed(2)
                                    ]
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "h-8 w-22 md:w-24 lg:w-24 flex flex-wrap items-center justify-evenly p-1 border border-gray-100 bg-white text-gray-600 rounded-md",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        onClick: ()=>updateItemQuantity(item.id, item.quantity - 1),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "text-dark text-base",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_4__.FiMinus, {})
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "text-sm font-semibold text-dark px-1",
                                        children: item.quantity
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        onClick: ()=>handleIncreaseQuantity(item),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "text-dark text-base",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_4__.FiPlus, {})
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                onClick: ()=>removeItem(item.id),
                                className: "hover:text-red-600 text-red-400 text-lg cursor-pointer",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_4__.FiTrash2, {})
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CartItem);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9800:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(543);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8027);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9989);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_io5__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _utils_data__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2386);
/* harmony import */ var _hooks_useAsync__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9338);
/* harmony import */ var _component_preloader_Loading__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8906);
/* harmony import */ var _context_SidebarContext__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6812);
/* harmony import */ var _services_CategoryServices__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5442);
/* harmony import */ var _component_category_CategoryCard__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3285);
/* harmony import */ var _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(545);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_context_SidebarContext__WEBPACK_IMPORTED_MODULE_8__, _services_CategoryServices__WEBPACK_IMPORTED_MODULE_9__, _component_category_CategoryCard__WEBPACK_IMPORTED_MODULE_10__, _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_11__]);
([_context_SidebarContext__WEBPACK_IMPORTED_MODULE_8__, _services_CategoryServices__WEBPACK_IMPORTED_MODULE_9__, _component_category_CategoryCard__WEBPACK_IMPORTED_MODULE_10__, _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_11__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





//internal import







const Category = ()=>{
    const { categoryDrawerOpen , closeCategoryDrawer  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_SidebarContext__WEBPACK_IMPORTED_MODULE_8__/* .SidebarContext */ .l);
    const { showingTranslateValue  } = (0,_hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z)();
    const { data , loading , error  } = (0,_hooks_useAsync__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)(()=>_services_CategoryServices__WEBPACK_IMPORTED_MODULE_9__/* ["default"].getShowingCategory */ .Z.getShowingCategory());
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex flex-col w-full h-full bg-white cursor-pointer scrollbar-hide",
        children: [
            categoryDrawerOpen && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-full flex justify-between items-center h-16 px-6 py-4 bg-gray-800 text-white border-b border-gray-100",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: "font-semibold font-serif text-lg m-0 text-heading flex align-center",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                            href: "/",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                className: "mr-10",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    width: 30,
                                    height: 20,
                                    src: "/logo/Ecomedge.png",
                                    alt: "logo"
                                })
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        onClick: closeCategoryDrawer,
                        className: "flex text-xl items-center justify-center w-8 h-8 rounded-full bg-gray-50 text-red-500 p-2 focus:outline-none transition-opacity hover:text-red-600",
                        "aria-label": "close",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io5__WEBPACK_IMPORTED_MODULE_4__.IoClose, {})
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-full max-h-full",
                children: [
                    categoryDrawerOpen && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: "font-semibold font-serif text-lg m-0 text-heading flex align-center border-b px-8 py-3",
                        children: "All Categories"
                    }),
                    error ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "flex justify-center align-middle items-center m-auto text-xl text-red-500",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            children: [
                                " ",
                                error
                            ]
                        })
                    }) : data.length === 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_preloader_Loading__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        loading: loading
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "relative grid gap-2 p-6",
                        children: data[0]?.children?.map((category)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_category_CategoryCard__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                id: category._id,
                                icon: category.icon,
                                nested: category.children,
                                title: category?.name
                            }, category._id))
                    }),
                    categoryDrawerOpen && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "relative grid gap-2 mt-5",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "font-semibold font-serif text-lg m-0 text-heading flex align-center border-b px-8 py-3",
                                children: "Pages"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "relative grid gap-1 p-6",
                                children: _utils_data__WEBPACK_IMPORTED_MODULE_5__/* .pages.map */ .L1.map((item)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                        href: item.href,
                                        className: "p-2 flex font-serif items-center rounded-md hover:bg-gray-50 w-full hover:text-gray-600",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(item.icon, {
                                                className: "flex-shrink-0 h-4 w-4",
                                                "aria-hidden": "true"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: "inline-flex items-center justify-between ml-2 text-sm font-medium w-full hover:text-gray-600",
                                                children: item.title
                                            })
                                        ]
                                    }, item.title))
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Category);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3285:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8027);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9989);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_io5__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _context_SidebarContext__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6812);
/* harmony import */ var _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(545);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_context_SidebarContext__WEBPACK_IMPORTED_MODULE_5__, _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_6__]);
([_context_SidebarContext__WEBPACK_IMPORTED_MODULE_5__, _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





//internal import


const CategoryCard = ({ title , icon , nested , id  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const { closeCategoryDrawer , isLoading , setIsLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useContext)(_context_SidebarContext__WEBPACK_IMPORTED_MODULE_5__/* .SidebarContext */ .l);
    const { showingTranslateValue  } = (0,_hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)();
    // react hook
    const { 0: show , 1: setShow  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const { 0: showSubCategory , 1: setShowSubCategory  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({
        id: "",
        show: false
    });
    // handle show category
    const showCategory = (id, title)=>{
        const name = title.toLowerCase().replace(/[^A-Z0-9]+/gi, "-");
        setShow(!show);
        router.push(`/search?category=${name}&_id=${id}`);
        closeCategoryDrawer;
        setIsLoading(!isLoading);
    };
    // handle sub nested category
    const handleSubNestedCategory = (id, title)=>{
        const name = title.toLowerCase().replace(/[^A-Z0-9]+/gi, "-");
        setShowSubCategory((prevState)=>({
                id: id,
                show: prevState.id === id ? !prevState.show : true
            }));
        router.push(`/search?category=${name}&_id=${id}`);
        closeCategoryDrawer;
        setIsLoading(!isLoading);
    };
    const handleSubCategory = (id, title)=>{
        const name = title.toLowerCase().replace(/[^A-Z0-9]+/gi, "-");
        router.push(`/search?category=${name}&_id=${id}`);
        closeCategoryDrawer;
        setIsLoading(!isLoading);
    };
    const handleSubChildrenCategory = (id, title)=>{
        const name = title.toLowerCase().replace(/[^A-Z0-9]+/gi, "-");
        router.push(`/search?category=${name}&_id=${id}`);
        closeCategoryDrawer;
        setIsLoading(!isLoading);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                onClick: ()=>showCategory(id, title),
                className: "p-2 flex items-center rounded-md hover:bg-gray-50 w-full hover:text-gray-600",
                role: "button",
                children: [
                    icon ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        src: icon,
                        width: 18,
                        height: 18,
                        alt: "Category"
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        src: "https://res.cloudinary.com/ahossain/image/upload/v1655097002/placeholder_kvepfp.png",
                        width: 18,
                        height: 18,
                        alt: "category"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "inline-flex items-center justify-between ml-3 text-sm font-medium w-full hover:text-gray-600",
                        children: [
                            title,
                            nested?.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "transition duration-700 ease-in-out inline-flex loading-none items-end text-gray-400",
                                children: show ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io5__WEBPACK_IMPORTED_MODULE_4__.IoChevronDownOutline, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io5__WEBPACK_IMPORTED_MODULE_4__.IoChevronForwardOutline, {})
                            })
                        ]
                    })
                ]
            }),
            show && nested.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                className: "pl-6 pb-3 pt-1 -mt-1",
                children: nested?.map((children)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                        children: [
                            children?.children?.length > 0 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                onClick: ()=>handleSubNestedCategory(children?._id, children?.name),
                                className: "flex items-center font-serif pr-2 text-sm text-gray-600 hover:text-gray-600 py-1 cursor-pointer",
                                children: [
                                    children?.name,
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "inline-flex items-center justify-between ml-3 text-sm font-medium w-full hover:text-gray-600",
                                        children: children.children.length > 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "transition duration-700 ease-in-out inline-flex loading-none items-end text-gray-400",
                                            children: showSubCategory.id === children._id && showSubCategory.show ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io5__WEBPACK_IMPORTED_MODULE_4__.IoChevronDownOutline, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io5__WEBPACK_IMPORTED_MODULE_4__.IoChevronForwardOutline, {})
                                        }) : null
                                    })
                                ]
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                onClick: ()=>handleSubCategory(children._id, children.name),
                                className: "flex items-center font-serif py-1 text-sm text-gray-600 hover:text-gray-600 cursor-pointer",
                                children: children?.name
                            }),
                            showSubCategory.id === children._id && showSubCategory.show === true ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                className: "pl-6 pb-3",
                                children: children.children.map((subChildren)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                            onClick: ()=>handleSubChildrenCategory(subChildren._id, subChildren?.name),
                                            className: "flex items-center font-serif py-1 text-sm text-gray-600 hover:text-gray-600 cursor-pointer",
                                            children: [
                                                subChildren?.name,
                                                showingTranslateValue(subChildren?.name)
                                            ]
                                        })
                                    }, subChildren._id))
                            }) : null
                        ]
                    }, children._id))
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CategoryCard);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6517:
/***/ ((module, __unused_webpack___webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(545);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_1__]);
_hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


// import { getNumber } from "@utils/numberFormat";
const Discount = ({ discount , product , slug , modal  })=>{
    const { getNumber  } = useUtilsFunction();
    const price = product?.isCombination ? getNumber(product?.variants[0]?.price) : getNumber(product?.prices?.price);
    const originalPrice = product?.isCombination ? getNumber(product?.variants[0]?.originalPrice) : getNumber(product?.prices?.originalPrice);
    console.log(price, originalPrice, discount);
    const discountPercentage = getNumber((originalPrice - price) / originalPrice * 100);
    return /*#__PURE__*/ _jsxs(_Fragment, {
        children: [
            discount > 0 && /*#__PURE__*/ _jsxs("span", {
                className: modal ? "absolute text-dark text-sm bg-orange-500 text-white py-1 px-2 rounded font-medium z-10 left-4 top-4" : slug ? "relative text-dark text-sm bg-orange-500 text-white py-1 px-2 rounded font-medium z-10 right-0 top-6" : " absolute text-dark text-xs bg-orange-500 text-white py-1 px-2 rounded font-medium z-10 right-4 top-4",
                children: [
                    discount,
                    "% Off"
                ]
            }),
            discount === undefined && originalPrice > 1 ? /*#__PURE__*/ _jsxs("span", {
                className: modal ? "absolute text-dark text-sm bg-orange-500 text-white py-1 px-2 rounded font-medium z-10 left-4 top-4" : slug ? "  text-dark text-sm bg-orange-500 text-white py-1 px-2 rounded font-medium z-10 right-4 top-4" : " absolute text-dark text-xs bg-orange-500 text-white py-1 px-2 rounded font-medium z-10 right-4 top-4",
                children: [
                    Number(product.prices.discount).toFixed(0),
                    "% Off",
                    discountPercentage,
                    " % Off"
                ]
            }) : ""
        ]
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (Discount)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7493:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(545);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_1__]);
_hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const Price = ({ product , price , card , currency , originalPrice  })=>{
    const { getNumberTwo  } = (0,_hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "font-serif product-price font-bold",
        children: product?.isCombination ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: card ? "inline-block text-lg font-semibold text-gray-800" : "inline-block text-2xl",
                    children: [
                        currency,
                        getNumberTwo(price)
                    ]
                }),
                originalPrice > price ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("del", {
                        className: card ? "sm:text-sm font-normal text-base text-gray-400 ml-1" : "text-lg font-normal text-gray-400 ml-1",
                        children: [
                            currency,
                            getNumberTwo(originalPrice)
                        ]
                    })
                }) : null
            ]
        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: card ? "inline-block text-lg font-semibold text-gray-800" : "inline-block text-2xl",
                    children: [
                        currency,
                        getNumberTwo(originalPrice)
                    ]
                }),
                originalPrice < price ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("del", {
                        className: card ? "sm:text-sm font-normal text-base text-gray-400 ml-1" : "text-lg font-normal text-gray-400 ml-1",
                        children: [
                            currency,
                            getNumberTwo(price)
                        ]
                    })
                }) : null
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Price);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6616:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(866);
/* harmony import */ var next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_1__);


const Stock = ({ product , stock , card  })=>{
    const { t  } = next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_1___default()();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: stock === 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
            className: "bg-red-100 absolute z-10 text-red-500 dark:text-red-400 rounded-full inline-flex items-center justify-center px-2 py-0 text-xs font-medium font-serif",
            children: t("common:stockOut")
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: stock == null ? "" : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                className: `${card ? "bg-gray-100 absolute z-10 text-gray-800 rounded-full text-xs px-2 py-0 font-medium" : "bg-gray-100 text-gray-500 rounded-full inline-flex items-center justify-center px-2 py-0 text-xs font-semibold font-serif"}`,
                children: [
                    t("common:stock"),
                    " :",
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "text-red-500 dark:text-red-400 pl-1 font-bold",
                        children: product?.fewLeft === true ? "Few Left" : stock
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Stock);


/***/ }),

/***/ 386:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const Tags = ({ product  })=>{
    console.log("product", product);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: product.tag.length !== 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex flex-row flex-wrap",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "mr-2 mb-2",
                    children: product?.tag.slice(0, Math.ceil(product.tag.length / 2)).map((t, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "bg-gray-50 border-0 text-gray-600 rounded-full inline-flex items-center justify-center px-3 py-1 text-xs font-semibold font-serif mt-2",
                            children: t
                        }, i + 1))
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    children: product?.tag.slice(Math.ceil(product.tag.length / 2)).map((t, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "bg-gray-50 border-0 text-gray-600 rounded-full inline-flex items-center justify-center px-3 py-1 text-xs font-semibold font-serif mt-2",
                            children: t
                        }, i + Math.ceil(product.tag.length / 2)))
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Tags);


/***/ }),

/***/ 3596:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3521);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var rc_drawer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5307);
/* harmony import */ var rc_drawer__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(rc_drawer__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _component_cart_Cart__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2574);
/* harmony import */ var _context_SidebarContext__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6812);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_component_cart_Cart__WEBPACK_IMPORTED_MODULE_4__, _context_SidebarContext__WEBPACK_IMPORTED_MODULE_5__]);
([_component_cart_Cart__WEBPACK_IMPORTED_MODULE_4__, _context_SidebarContext__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




//internal import


const CartDrawer = ()=>{
    const { cartDrawerOpen , closeCartDrawer  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_SidebarContext__WEBPACK_IMPORTED_MODULE_5__/* .SidebarContext */ .l);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((rc_drawer__WEBPACK_IMPORTED_MODULE_3___default()), {
        open: cartDrawerOpen,
        onClose: closeCartDrawer,
        parent: null,
        level: null,
        placement: "right",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_cart_Cart__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (next_dynamic__WEBPACK_IMPORTED_MODULE_2___default()(()=>Promise.resolve(CartDrawer), {
    ssr: false
}));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4407:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3521);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var rc_drawer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5307);
/* harmony import */ var rc_drawer__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(rc_drawer__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _component_category_Category__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9800);
/* harmony import */ var _context_SidebarContext__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6812);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_component_category_Category__WEBPACK_IMPORTED_MODULE_4__, _context_SidebarContext__WEBPACK_IMPORTED_MODULE_5__]);
([_component_category_Category__WEBPACK_IMPORTED_MODULE_4__, _context_SidebarContext__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const CategoryDrawer = ()=>{
    const { categoryDrawerOpen , closeCategoryDrawer  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_SidebarContext__WEBPACK_IMPORTED_MODULE_5__/* .SidebarContext */ .l);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((rc_drawer__WEBPACK_IMPORTED_MODULE_3___default()), {
        open: categoryDrawerOpen,
        onClose: closeCategoryDrawer,
        parent: null,
        level: null,
        placement: "left",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_category_Category__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (next_dynamic__WEBPACK_IMPORTED_MODULE_2___default()(()=>Promise.resolve(CategoryDrawer), {
    ssr: false
}));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8643:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3521);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var rc_drawer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5307);
/* harmony import */ var rc_drawer__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(rc_drawer__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _context_SidebarContext__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6812);
/* harmony import */ var _component_notification_NotificationSidebar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8688);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_context_SidebarContext__WEBPACK_IMPORTED_MODULE_4__, _component_notification_NotificationSidebar__WEBPACK_IMPORTED_MODULE_5__]);
([_context_SidebarContext__WEBPACK_IMPORTED_MODULE_4__, _component_notification_NotificationSidebar__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




//internal import


const NotificationDrawer = ()=>{
    const { notificationDrawerOpen , closeNotificationDrawer  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_SidebarContext__WEBPACK_IMPORTED_MODULE_4__/* .SidebarContext */ .l);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((rc_drawer__WEBPACK_IMPORTED_MODULE_3___default()), {
        open: notificationDrawerOpen,
        onClose: closeNotificationDrawer,
        parent: null,
        level: null,
        placement: "right",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_notification_NotificationSidebar__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (next_dynamic__WEBPACK_IMPORTED_MODULE_2___default()(()=>Promise.resolve(NotificationDrawer), {
    ssr: false
}));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7577:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2750);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5538);
/* harmony import */ var _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(545);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_3__, _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_4__]);
([_hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_3__, _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



//internal import


const FeatureCard = ()=>{
    const { storeCustomizationSetting  } = (0,_hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)();
    const { showingTranslateValue  } = (0,_hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)();
    const featurePromo = [
        // {
        //   id: 1,
        //   title: showingTranslateValue(
        //     storeCustomizationSetting?.footer?.shipping_card
        //   ),
        //   icon: FiTruck,
        // },
        {
            id: 2,
            title: showingTranslateValue(storeCustomizationSetting?.footer?.support_card),
            icon: react_icons_fi__WEBPACK_IMPORTED_MODULE_2__.FiPhoneCall
        },
        {
            id: 3,
            title: showingTranslateValue(storeCustomizationSetting?.footer?.payment_card),
            icon: react_icons_fi__WEBPACK_IMPORTED_MODULE_2__.FiCreditCard
        }, 
    ];
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "flex w-full grid grid-cols-2 gap-1 items-center justify-center sm:grid-cols-2 mx-auto",
        children: featurePromo.map((promo)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: " border-r border-gray-200 py-1 flex items-center justify-center bg-white",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "mr-3",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(promo.icon, {
                            className: "flex-shrink-0 h-4 w-4 text-gray-600",
                            "aria-hidden": "true"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "block font-serif text-sm font-medium leading-5",
                            children: promo?.title
                        })
                    })
                ]
            }, promo.id))
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FeatureCard);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6072:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_dropzone__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6358);
/* harmony import */ var react_dropzone__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_dropzone__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2750);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_4__);
// Certainly! If you want to modify the code similar to the previous one, here it is:





// import { notifyError, notifySuccess } from '@/utils/toast';
const Uploader = ({ setImageUrl , imageUrl  })=>{
    const { 0: files , 1: setFiles  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const { getRootProps , getInputProps  } = (0,react_dropzone__WEBPACK_IMPORTED_MODULE_3__.useDropzone)({
        accept: "image/*",
        multiple: false,
        maxSize: 100000,
        onDrop: (acceptedFiles)=>{
            setFiles(acceptedFiles.map((file)=>Object.assign(file, {
                    preview: URL.createObjectURL(file)
                })));
        }
    });
    const thumbs = files.map((file)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    className: "inline-flex border-2 border-gray-100 w-24 max-h-24",
                    src: file.preview,
                    alt: file.name
                })
            })
        }, file.name));
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const uploadUrl = "https://api.cloudinary.com/v1_1/dren3tno6/image/uploadNEXT_PUBLIC_STORE_DOMAIN";
        const uploadPreset = "upload_preset";
        const uploadFiles = async ()=>{
            try {
                const formData = new FormData();
                formData.append("file", files[0]);
                formData.append("upload_preset", uploadPreset);
                const response = await axios__WEBPACK_IMPORTED_MODULE_2___default().post(uploadUrl, formData, {
                    headers: {
                        "Content-Type": "application/x-www-form-urlencoded"
                    }
                });
                setImageUrl(response.data.secure_url);
                notifySuccess("Image Uploaded successfully!");
            } catch (error) {
                console.error("Error uploading image:", error);
            // notifyError('An error occurred while uploading the image.');
            }
        };
        if (files.length > 0) {
            uploadFiles();
        }
    }, [
        files,
        setImageUrl
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>()=>{
            // Make sure to revoke the data URIs to avoid memory leaks
            files.forEach((file)=>URL.revokeObjectURL(file.preview));
        }, [
        files
    ]);
    const handleRemoveImage = ()=>{
        setFiles([]);
        setImageUrl("");
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "w-full text-center",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md cursor-pointer",
                ...getRootProps(),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                        ...getInputProps()
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "mx-auto flex justify-center",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_4__.FiUploadCloud, {
                            className: "text-3xl text-gray-500"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "text-sm mt-2",
                        children: "Drag your image here"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("em", {
                        className: "text-xs text-gray-400",
                        children: "(Only *.jpeg and *.png images will be accepted)"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("aside", {
                className: "flex flex-row flex-wrap mt-4",
                children: imageUrl ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "relative",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            className: "inline-flex border rounded-md border-gray-100 w-24 max-h-24 p-2",
                            src: imageUrl,
                            alt: "product"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            type: "button",
                            className: "absolute top-0 right-0 text-red-500 focus:outline-none",
                            onClick: handleRemoveImage,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_4__.FiXCircle, {})
                        })
                    ]
                }) : thumbs
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Uploader); // This modified code uses the Cloudinary upload preset and URL as in your previous code, and it allows you to upload and display a single image. If you need any further adjustments or have specific requirements, feel free to let me know!


/***/ }),

/***/ 4012:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons_im__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(924);
/* harmony import */ var react_icons_im__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_im__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _component_login_Login__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(474);
/* harmony import */ var _component_login_Register__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8909);
/* harmony import */ var _component_login_ResetPassword__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6853);
/* harmony import */ var _hooks_useLoginSubmit__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8269);
/* harmony import */ var _utils_toast__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8548);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_component_login_Login__WEBPACK_IMPORTED_MODULE_3__, _component_login_Register__WEBPACK_IMPORTED_MODULE_4__, _component_login_ResetPassword__WEBPACK_IMPORTED_MODULE_5__, _hooks_useLoginSubmit__WEBPACK_IMPORTED_MODULE_6__]);
([_component_login_Login__WEBPACK_IMPORTED_MODULE_3__, _component_login_Register__WEBPACK_IMPORTED_MODULE_4__, _component_login_ResetPassword__WEBPACK_IMPORTED_MODULE_5__, _hooks_useLoginSubmit__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



//internal import





const Common = ({ setModalOpen  })=>{
    const { 0: showRegister , 1: setShowRegister  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: showResetPassword , 1: setShowResetPassword  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { handleGoogleSignIn , GoogleLogin  } = (0,_hooks_useLoginSubmit__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)(setModalOpen);
    const handleModal = ()=>{
        setShowRegister(!showRegister);
        setShowResetPassword(false);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "overflow-hidden bg-white mx-auto",
            children: [
                showResetPassword ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_login_ResetPassword__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                    setShowResetPassword: setShowResetPassword,
                    setModalOpen: setModalOpen
                }) : showRegister ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_login_Register__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                    setShowResetPassword: setShowResetPassword,
                    setModalOpen: setModalOpen
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_login_Login__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    setShowResetPassword: setShowResetPassword,
                    setModalOpen: setModalOpen
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex justify-center ... flex-col lg:flex-row"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "text-center text-sm text-gray-900 mt-4",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "text-gray-500 mt-2.5",
                        children: [
                            showRegister ? "Already have a account ?" : "Not have a account ?",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                onClick: handleModal,
                                className: "text-gray-800 hover:text-gray-500 font-bold mx-2",
                                children: showRegister ? "Login" : "Register"
                            })
                        ]
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Common);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 474:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2750);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _component_form_Error__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9948);
/* harmony import */ var _hooks_useLoginSubmit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8269);
/* harmony import */ var _component_form_InputArea__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6791);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_useLoginSubmit__WEBPACK_IMPORTED_MODULE_3__]);
_hooks_useLoginSubmit__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


//internal  import



const Login = ({ setShowResetPassword , setModalOpen  })=>{
    const { handleSubmit , submitHandler , register , errors , loading  } = (0,_hooks_useLoginSubmit__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)(setModalOpen);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "text-center mb-6",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: "text-3xl font-bold font-serif",
                        children: "Login"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "text-sm md:text-base text-gray-500 mt-2 mb-8 sm:mb-10",
                        children: "Login with your email and password"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                onSubmit: handleSubmit(submitHandler),
                className: "flex flex-col justify-center",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "grid grid-cols-1 gap-5",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "form-group",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_InputArea__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                    register: register,
                                    // defaultValue="justin@gmail.com"
                                    label: "Email",
                                    name: "loginIdentifier",
                                    type: "email",
                                    placeholder: "Email",
                                    Icon: react_icons_fi__WEBPACK_IMPORTED_MODULE_1__.FiMail
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_Error__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                    errorName: errors.loginIdentifier
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "form-group",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_InputArea__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                    register: register,
                                    // defaultValue="12345678"
                                    label: "Password",
                                    name: "password",
                                    type: "password",
                                    placeholder: "Password",
                                    Icon: react_icons_fi__WEBPACK_IMPORTED_MODULE_1__.FiLock
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_Error__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                    errorName: errors.password
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "flex items-center justify-between",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex ms-auto",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    type: "button",
                                    onClick: ()=>setShowResetPassword(true),
                                    className: "text-end text-sm text-heading ps-3 underline hover:no-underline focus:outline-none",
                                    children: "Forgot password?"
                                })
                            })
                        }),
                        loading ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                            disabled: loading,
                            type: "submit",
                            className: "md:text-sm leading-5 inline-flex items-center cursor-pointer transition ease-in-out duration-300 font-medium text-center justify-center border-0 border-transparent rounded-md placeholder-white focus-visible:outline-none focus:outline-none bg-gray-800 text-white px-5 md:px-6 lg:px-8 py-2 md:py-3 lg:py-3 hover:text-white hover:bg-gray-600 h-12 mt-1 text-sm lg:text-sm w-full sm:w-auto",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: "/loader/spinner.gif",
                                    alt: "Loading",
                                    width: 20,
                                    height: 10
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "font-serif ml-2 font-light",
                                    children: "Processing"
                                })
                            ]
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            disabled: loading,
                            type: "submit",
                            className: "w-full text-center py-3 rounded bg-gray-800 text-white hover:bg-gray-600 transition-all focus:outline-none my-1",
                            children: "Login"
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Login);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8909:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2750);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _component_form_Error__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9948);
/* harmony import */ var _component_form_InputArea__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6791);
/* harmony import */ var _hooks_useLoginSubmit__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8269);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_useLoginSubmit__WEBPACK_IMPORTED_MODULE_4__]);
_hooks_useLoginSubmit__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


//internal import



const Register = ({ setShowResetPassword , setModalOpen  })=>{
    const { handleSubmit , submitHandler , register , errors , loading  } = (0,_hooks_useLoginSubmit__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)(setModalOpen);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "text-center mb-6",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: "text-3xl font-bold font-serif",
                        children: "Signing Up"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "text-sm md:text-base text-gray-500 mt-2 mb-8 sm:mb-10",
                        children: "Create an account with email"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                onSubmit: handleSubmit(submitHandler),
                className: "flex flex-col justify-center",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "grid grid-cols-1 gap-5",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "form-group",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_InputArea__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                    register: register,
                                    label: "Name",
                                    name: "name",
                                    type: "text",
                                    placeholder: "Full Name",
                                    Icon: react_icons_fi__WEBPACK_IMPORTED_MODULE_1__.FiUser
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_Error__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                    errorName: errors.name
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "form-group",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_InputArea__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                    register: register,
                                    label: "Email",
                                    name: "email",
                                    type: "email",
                                    placeholder: "Email",
                                    Icon: react_icons_fi__WEBPACK_IMPORTED_MODULE_1__.FiMail
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_Error__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                    errorName: errors.email
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "form-group",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_InputArea__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                    register: register,
                                    label: "Password",
                                    name: "password",
                                    type: "password",
                                    placeholder: "Password",
                                    Icon: react_icons_fi__WEBPACK_IMPORTED_MODULE_1__.FiLock
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_Error__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                    errorName: errors.password
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "flex items-center justify-between",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex ms-auto",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    type: "button",
                                    onClick: ()=>setShowResetPassword(true),
                                    className: "text-end text-sm text-heading ps-3 underline hover:no-underline focus:outline-none",
                                    children: "Forgot password?"
                                })
                            })
                        }),
                        loading ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                            disabled: loading,
                            type: "submit",
                            className: "md:text-sm leading-5 inline-flex items-center cursor-pointer transition ease-in-out duration-300 font-medium text-center justify-center border-0 border-transparent rounded-md placeholder-white focus-visible:outline-none focus:outline-none bg-gray-800 text-white px-5 md:px-6 lg:px-8 py-2 md:py-3 lg:py-3 hover:text-white hover:bg-gray-600 h-12 mt-1 text-sm lg:text-sm w-full sm:w-auto",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: "/loader/spinner.gif",
                                    alt: "Loading",
                                    width: 20,
                                    height: 10
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "font-serif ml-2 font-light",
                                    children: "Processing"
                                })
                            ]
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            disabled: loading,
                            type: "submit",
                            className: "w-full text-center py-3 rounded bg-gray-800 text-white hover:bg-gray-600 transition-all focus:outline-none my-1",
                            children: "Register"
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Register);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6853:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(543);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2750);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _component_form_Error__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9948);
/* harmony import */ var _component_form_InputArea__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6791);
/* harmony import */ var _hooks_useLoginSubmit__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8269);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_useLoginSubmit__WEBPACK_IMPORTED_MODULE_6__]);
_hooks_useLoginSubmit__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




//internal import



const ResetPassword = ({ setShowResetPassword , setModalOpen  })=>{
    const { handleSubmit , submitHandler , register , errors , loading  } = (0,_hooks_useLoginSubmit__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)(setModalOpen);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "text-center mb-6",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                        href: "/",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                            className: "text-3xl font-bold font-serif",
                            children: "Forget Password"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "text-sm md:text-base text-gray-500 mt-2 mb-8 sm:mb-10",
                        children: "Reset Your Password"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                onSubmit: handleSubmit(submitHandler),
                className: "flex flex-col justify-center",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "grid grid-cols-1 gap-5",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "form-group",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_InputArea__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                    register: register,
                                    label: "Email",
                                    name: "verifyEmail",
                                    type: "email",
                                    placeholder: "Your Register Email",
                                    Icon: react_icons_fi__WEBPACK_IMPORTED_MODULE_3__.FiMail
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_Error__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                    errorName: errors.verifyEmail
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "flex items-center justify-between",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex ms-auto",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    type: "button",
                                    onClick: ()=>setShowResetPassword(true),
                                    className: "text-end text-sm text-heading ps-3 underline hover:no-underline focus:outline-none",
                                    children: "Forgot password?"
                                })
                            })
                        }),
                        loading ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                            disabled: loading,
                            type: "submit",
                            className: "md:text-sm leading-5 inline-flex items-center cursor-pointer transition ease-in-out duration-300 font-medium text-center justify-center border-0 border-transparent rounded-md placeholder-white focus-visible:outline-none focus:outline-none bg-gray-800 text-white px-5 md:px-6 lg:px-8 py-2 md:py-3 lg:py-3 hover:text-white hover:bg-gray-600 h-12 mt-1 text-sm lg:text-sm w-full sm:w-auto",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: "/loader/spinner.gif",
                                    alt: "Loading",
                                    width: 20,
                                    height: 10
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "font-serif ml-2 font-light",
                                    children: "Processing"
                                })
                            ]
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            disabled: loading,
                            type: "submit",
                            className: "w-full text-center py-3 rounded bg-gray-800 text-white hover:bg-gray-600 transition-all focus:outline-none my-1",
                            children: "Recover password"
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ResetPassword);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1859:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _component_login_Common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4012);
/* harmony import */ var _component_modal_MainModal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1173);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_component_login_Common__WEBPACK_IMPORTED_MODULE_2__, _component_modal_MainModal__WEBPACK_IMPORTED_MODULE_3__]);
([_component_login_Common__WEBPACK_IMPORTED_MODULE_2__, _component_modal_MainModal__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


//internal import


const LoginModal = ({ modalOpen , setModalOpen  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_modal_MainModal__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
        modalOpen: modalOpen,
        setModalOpen: setModalOpen,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "inline-block w-full max-w-lg p-10 overflow-hidden text-left align-middle transition-all transform bg-white shadow-xl rounded-2xl",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_login_Common__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                setModalOpen: setModalOpen
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(LoginModal));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1173:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1185);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9989);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_io5__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_headlessui_react__WEBPACK_IMPORTED_MODULE_2__]);
_headlessui_react__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const MainModal = ({ modalOpen , setModalOpen , children  })=>{
    const cancelButtonRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_2__.Transition, {
            appear: true,
            show: modalOpen,
            as: react__WEBPACK_IMPORTED_MODULE_1__.Fragment,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_2__.Dialog, {
                as: "div",
                className: "fixed inset-0 z-30 overflow-y-auto text-center",
                onClose: ()=>setModalOpen(false),
                initialFocus: cancelButtonRef,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "min-h-screen px-4",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_2__.Transition.Child, {
                            as: react__WEBPACK_IMPORTED_MODULE_1__.Fragment,
                            enter: "ease-out duration-300",
                            enterFrom: "opacity-0",
                            enterTo: "opacity-100",
                            leave: "ease-in duration-200",
                            leaveFrom: "opacity-100 scale-100",
                            leaveTo: "opacity-0 ",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_2__.Dialog.Overlay, {
                                className: "fixed inset-0 bg-black opacity-60"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "inline-block h-screen align-middle",
                            "aria-hidden": "true",
                            children: "​"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_2__.Transition.Child, {
                            as: react__WEBPACK_IMPORTED_MODULE_1__.Fragment,
                            enter: "ease-out duration-300",
                            enterFrom: "opacity-0 scale-95",
                            enterTo: "opacity-100 scale-100",
                            leave: "ease-in duration-200",
                            leaveFrom: "opacity-100 scale-100",
                            leaveTo: "opacity-0 scale-95",
                            children: children
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "absolute right-5 top-5",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                onClick: ()=>setModalOpen(false),
                                type: "button",
                                className: "inline-flex justify-center px-2 py-2 text-base font-medium text-red-500 bg-white border border-transparent rounded-full hover:bg-red-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-blue-500",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io5__WEBPACK_IMPORTED_MODULE_3__.IoClose, {})
                            })
                        })
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(MainModal));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8624:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(866);
/* harmony import */ var next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8027);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(543);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2750);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _component_common_Price__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7493);
/* harmony import */ var _component_common_Stock__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6616);
/* harmony import */ var _component_common_Tags__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(386);
/* harmony import */ var _utils_toast__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8548);
/* harmony import */ var _hooks_useAddToCart__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1353);
/* harmony import */ var _component_modal_MainModal__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1173);
/* harmony import */ var _component_common_Discount__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(6517);
/* harmony import */ var _component_variants_VariantList__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(2479);
/* harmony import */ var _context_SidebarContext__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(6812);
/* harmony import */ var _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(545);
/* harmony import */ var _component_form_InputArea__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(6791);
/* harmony import */ var _hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(5538);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(5641);
/* harmony import */ var _component_form_Error__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(9948);
/* harmony import */ var _component_form_Label__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(9545);
/* harmony import */ var _component_image_uploader_Uploader__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(6072);
/* harmony import */ var _services_EnquiryService__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(1086);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_component_common_Price__WEBPACK_IMPORTED_MODULE_7__, _component_modal_MainModal__WEBPACK_IMPORTED_MODULE_12__, _component_common_Discount__WEBPACK_IMPORTED_MODULE_13__, _component_variants_VariantList__WEBPACK_IMPORTED_MODULE_14__, _context_SidebarContext__WEBPACK_IMPORTED_MODULE_15__, _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_16__, _hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_18__, react_hook_form__WEBPACK_IMPORTED_MODULE_19__, _services_EnquiryService__WEBPACK_IMPORTED_MODULE_23__]);
([_component_common_Price__WEBPACK_IMPORTED_MODULE_7__, _component_modal_MainModal__WEBPACK_IMPORTED_MODULE_12__, _component_common_Discount__WEBPACK_IMPORTED_MODULE_13__, _component_variants_VariantList__WEBPACK_IMPORTED_MODULE_14__, _context_SidebarContext__WEBPACK_IMPORTED_MODULE_15__, _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_16__, _hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_18__, react_hook_form__WEBPACK_IMPORTED_MODULE_19__, _services_EnquiryService__WEBPACK_IMPORTED_MODULE_23__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







//internal import

















const ProductEnquiry = ({ modalOpen , setModalOpen  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const { loading , storeCustomizationSetting  } = (0,_hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z)();
    const { showingTranslateValue  } = (0,_hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z)();
    const { register , handleSubmit , setValue , formState: { errors  } ,  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_19__.useForm)();
    const { 0: error , 1: setError  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)("");
    const { 0: productImage , 1: setProductImage  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)("");
    const submitHandler = async (data)=>{
        setError("");
        const userInfo = {
            productImage: "https://example.com/product-image.jpg",
            productName: data.productName,
            name: data.name,
            address: data.address,
            message: data.message,
            city: data.city,
            email: "john.doe@gmail.com",
            phone: data.contact,
            zipCode: data.zipCode,
            quantity: data.quantity
        };
        console.log("product enquiry", userInfo);
        _services_EnquiryService__WEBPACK_IMPORTED_MODULE_23__/* ["default"].PostEnquiry */ .Z.PostEnquiry(userInfo).then((res)=>{
            if (res?.success === true) {
                console.log("getEnquiry", res);
                setModalOpen(false);
                (0,_utils_toast__WEBPACK_IMPORTED_MODULE_10__/* .notifySuccess */ .t5)(res.message);
            }
        });
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_modal_MainModal__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
            modalOpen: modalOpen,
            setModalOpen: setModalOpen,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "inline-block overflow-y-auto h-full align-middle transition-all transform bg-white shadow-xl rounded-2xl",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex flex-col p-3 lg:flex-row md:flex-row w-full max-w-4xl overflow-hidden",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                        onSubmit: handleSubmit(submitHandler),
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "form-group mt-12",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                    className: "font-semibold font-serif text-base text-gray-700 pb-3",
                                    children: "Product Enquiry"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "grid grid-cols-6 gap-6 mb-8",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_Label__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .Z, {
                                            className: "col-span-4 sm:col-span-2 font-medium text-sm",
                                            children: "product image"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "col-span-8 sm:col-span-4",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_image_uploader_Uploader__WEBPACK_IMPORTED_MODULE_22__/* ["default"] */ .Z, {
                                                product: true,
                                                folder: "product",
                                                imageUrl: productImage,
                                                setImageUrl: setProductImage
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "col-span-6 sm:col-span-6 lg:col-span-2",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_InputArea__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                                                    register: register,
                                                    //   label='Product Name'
                                                    name: "productName",
                                                    type: "text",
                                                    placeholder: 'Product name "mcb,switch board"'
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_Error__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {
                                                    errorName: errors.productName
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "col-span-6 sm:col-span-6 lg:col-span-2",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_InputArea__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                                                    register: register,
                                                    //   label='Name'
                                                    name: "name",
                                                    type: "text",
                                                    placeholder: "Enter your name"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_Error__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {
                                                    errorName: errors.yourName
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "col-span-6 sm:col-span-6 lg:col-span-2",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_InputArea__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                                                    register: register,
                                                    //   label='Name'
                                                    name: "contact",
                                                    type: "text",
                                                    placeholder: "Enter your contact number"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_Error__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {
                                                    errorName: errors.yourName
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "col-span-6 sm:col-span-6 lg:col-span-2",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_InputArea__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                                                    register: register,
                                                    //   label='Name'
                                                    name: "quantity",
                                                    type: "text",
                                                    placeholder: "Quantity needed"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_Error__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {
                                                    errorName: errors.yourName
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "col-span-6 sm:col-span-6 lg:col-span-2",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_InputArea__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                                                    register: register,
                                                    //   label={showingTranslateValue(
                                                    //     storeCustomizationSetting?.checkout?.city
                                                    //   )}
                                                    name: "city",
                                                    type: "text",
                                                    placeholder: "city"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_Error__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {
                                                    errorName: errors.city
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "col-span-6 sm:col-span-3 lg:col-span-2",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_InputArea__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                                                    register: register,
                                                    //   label={showingTranslateValue(
                                                    //     storeCustomizationSetting?.checkout?.zip_code
                                                    //   )}
                                                    name: "zipCode",
                                                    type: "text",
                                                    placeholder: "zipCode"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_Error__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {
                                                    errorName: errors.zipCode
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "col-span-6 flex flex-col justify-start",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_InputArea__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                                                    register: register,
                                                    //   label={showingTranslateValue(
                                                    //     storeCustomizationSetting?.checkout?.street_address
                                                    //   )}
                                                    name: "address",
                                                    type: "text",
                                                    placeholder: 'address "123 Boulevard Rd, Beverley Hills"'
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_Error__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {
                                                    errorName: errors.address
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "col-span-6 flex flex-col justify-start",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_InputArea__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                                                    register: register,
                                                    //   label={showingTranslateValue(
                                                    //     storeCustomizationSetting?.checkout?.street_address
                                                    //   )}
                                                    name: "message",
                                                    type: "text",
                                                    placeholder: "Write any additional message"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_Error__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {
                                                    errorName: errors.address
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-span-6 sm:col-span-3 flex justify-end",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        type: "submit",
                                        className: "bg-gray-800 hover:bg-gray-600 border border-gray-500 transition-all rounded py-3 text-center text-sm font-serif font-medium text-white flex justify-center w-[200px]",
                                        children: "Submit"
                                    })
                                })
                            ]
                        })
                    })
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductEnquiry);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8688:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(543);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9989);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_io5__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _component_modal_LoginModal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1859);
/* harmony import */ var _context_UserContext__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5408);
/* harmony import */ var _context_SidebarContext__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6812);
/* harmony import */ var _services_SettingServices__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3644);
/* harmony import */ var _services_NotificationServices__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6018);
/* harmony import */ var _hooks_useAsync__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9338);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_component_modal_LoginModal__WEBPACK_IMPORTED_MODULE_5__, _context_UserContext__WEBPACK_IMPORTED_MODULE_6__, _context_SidebarContext__WEBPACK_IMPORTED_MODULE_7__, _services_SettingServices__WEBPACK_IMPORTED_MODULE_8__, _services_NotificationServices__WEBPACK_IMPORTED_MODULE_9__]);
([_component_modal_LoginModal__WEBPACK_IMPORTED_MODULE_5__, _context_UserContext__WEBPACK_IMPORTED_MODULE_6__, _context_SidebarContext__WEBPACK_IMPORTED_MODULE_7__, _services_SettingServices__WEBPACK_IMPORTED_MODULE_8__, _services_NotificationServices__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






//internal import






// import useAsync from "@hooks/useAsync";
const NotificationSidebar = ()=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const { 0: modalOpen , 1: setModalOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const { closeNotificationDrawer  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useContext)(_context_SidebarContext__WEBPACK_IMPORTED_MODULE_7__/* .SidebarContext */ .l);
    // const { data: globalSetting } = useAsync(SettingServices.getGlobalSetting);
    const { data  } = (0,_hooks_useAsync__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)(_services_NotificationServices__WEBPACK_IMPORTED_MODULE_9__/* ["default"].getAllNotification */ .Z.getAllNotification);
    const { state: { userInfo  } ,  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useContext)(_context_UserContext__WEBPACK_IMPORTED_MODULE_6__/* .UserContext */ .S);
    const { 0: notifications , 1: setNotifications  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)([]);
    console.log("notifications data", data);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            modalOpen && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_modal_LoginModal__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                modalOpen: modalOpen,
                setModalOpen: setModalOpen
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-col w-full h-full justify-between items-middle bg-white rounded cursor-pointer",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full flex justify-between items-center relative px-5 py-4 border-b bg-indigo-50 border-gray-100",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                                className: "font-semibold font-serif text-lg m-0 text-heading flex items-center",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text-xl mr-2 mb-1",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io5__WEBPACK_IMPORTED_MODULE_4__.IoNotificationsOutline, {})
                                    }),
                                    "Notification"
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                onClick: closeNotificationDrawer,
                                className: "inline-flex text-base items-center justify-center text-gray-500 p-2 focus:outline-none transition-opacity hover:text-red-400",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io5__WEBPACK_IMPORTED_MODULE_4__.IoClose, {}),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "font-sens text-sm text-gray-500 hover:text-red-400 ml-1",
                                        children: "Close"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "overflow-y-scroll flex-grow scrollbar-hide w-full max-h-full",
                        children: data?.notificationDetails?.map((notification, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: " ml-4 notification-item cursor-pointer hover:bg-green-200 hover:text-gray-800 transition-colors duration-300 ease-in-out mb-2 flex items-center",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: "mr-2",
                                        children: [
                                            index + 1,
                                            "."
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "flex-grow",
                                        children: notification?.notification?.notification_body
                                    })
                                ]
                            }, notification.id))
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NotificationSidebar);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2038:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_loading_skeleton__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4275);
/* harmony import */ var react_loading_skeleton_dist_skeleton_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6593);
/* harmony import */ var react_loading_skeleton_dist_skeleton_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_loading_skeleton_dist_skeleton_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var html_react_parser__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2905);
/* harmony import */ var _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(545);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_loading_skeleton__WEBPACK_IMPORTED_MODULE_2__, html_react_parser__WEBPACK_IMPORTED_MODULE_4__, _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_5__]);
([react_loading_skeleton__WEBPACK_IMPORTED_MODULE_2__, html_react_parser__WEBPACK_IMPORTED_MODULE_4__, _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const CMSkeleton = ({ html , count , height , color , loading , error , data , highlightColor , newData ,  })=>{
    const { showingTranslateValue  } = (0,_hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: loading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_loading_skeleton__WEBPACK_IMPORTED_MODULE_2__["default"], {
            count: count || 6,
            height: height || 25,
            // className="bg-gray-200"
            baseColor: color || "#f1f5f9",
            highlightColor: highlightColor || "#cbd5e1"
        }) : error ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
            className: "text-center mx-auto text-red-500",
            children: error
        }) : data ? html ? (0,html_react_parser__WEBPACK_IMPORTED_MODULE_4__["default"])(showingTranslateValue(data)) : showingTranslateValue(data) : newData ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: newData
        }) : null
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CMSkeleton);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2479:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(545);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_1__]);
_hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const VariantList = ({ att , option , variants , setValue , varTitle , selectVariant , setSelectVariant , setSelectVa ,  })=>{
    const { showingTranslateValue  } = (0,_hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)();
    const handleChangeVariant = (v)=>{
        setValue(v);
        setSelectVariant({
            ...selectVariant,
            [att]: v
        });
        setSelectVa({
            [att]: v
        });
    };
    // console.log("option", );
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: option === "Dropdown" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
            onChange: (e)=>handleChangeVariant(e.target.value),
            className: "focus:shadow-none w-40 px-2 py-1 form-select outline-none h-10 text-sm focus:outline-none block rounded-md bg-gray-100 border-transparent focus:bg-white border-gray-600 focus:border-gray-400 focus:ring focus:ring-gray-200",
            name: "parent",
            children: [
                [
                    ...new Map(variants.map((v)=>[
                            v[att],
                            v
                        ].filter(Boolean))).values(), 
                ].filter(Boolean).map((vl, i)=>Object?.values(selectVariant).includes(vl[att]) && varTitle.map((vr)=>vr?.variants?.map((el)=>vr?._id === att && el?._id === vl[att] && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: selectVariant[att],
                                defaultValue: selectVariant[att],
                                hidden: true,
                                children: el.name
                            }, i + 1)))),
                [
                    ...new Map(variants.map((v)=>[
                            v[att],
                            v
                        ].filter(Boolean))).values(), 
                ].filter(Boolean).map((vl, i)=>varTitle.map((vr)=>vr?.variants?.map((el)=>vr?._id === att && el?._id === vl[att] && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: vl[att],
                                defaultValue: true,
                                children: el.name
                            }, el._id))))
            ]
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "grid lg:grid-cols-3 grid-cols-2",
            children: [
                ...new Map(variants?.map((v)=>[
                        v[att],
                        v
                    ].filter(Boolean))).values(), 
            ].filter(Boolean).map((vl, i)=>varTitle.map((vr)=>vr?.variants?.map((el)=>vr?._id === att && el?._id === vl[att] && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            onClick: (e)=>handleChangeVariant(vl[att]),
                            className: `${Object?.values(selectVariant).includes(vl[att]) ? "bg-gray-800 text-white mr-2 border-0 rounded-full inline-flex items-center justify-center px-3 py-1 text-xs font-serif mt-2 focus:outline-none" : "bg-gray-100 mr-2 border-0 text-gray-600 rounded-full inline-flex items-center justify-center px-3 py-1 text-xs font-serif mt-2 focus:outline-none"}`,
                            children: el.name
                        }, i + 1))))
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (VariantList);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5376:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A": () => (/* binding */ useOrder),
/* harmony export */   "u": () => (/* binding */ OrderProvider)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


// Create the OrderContext
const OrderContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)();
// Create the OrderProvider
const OrderProvider = ({ children  })=>{
    const { 0: order , 1: setOrder  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null); // State to hold order data
    // Function to set order data
    const setOrderData = (data)=>{
        setOrder(data);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(OrderContext.Provider, {
        value: {
            order,
            setOrderData
        },
        children: children
    });
};
// Custom hook to consume the context
const useOrder = ()=>{
    const context = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(OrderContext);
    if (!context) {
        throw new Error("useOrder must be used within an OrderProvider");
    }
    return context;
};


/***/ }),

/***/ 1353:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_use_cart__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9878);
/* harmony import */ var react_use_cart__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_use_cart__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_toast__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8548);



const useAddToCart = ()=>{
    const { 0: item , 1: setItem  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(1);
    const { addItem , items , updateItemQuantity  } = (0,react_use_cart__WEBPACK_IMPORTED_MODULE_1__.useCart)();
    const handleAddItem = (product)=>{
        const result = items.find((i)=>i.id === product.id);
        const { variants , categories , description , ...updatedProduct } = product;
        if (result !== undefined) {
            if (product.stock === null || product.stock > 0) {
                addItem(updatedProduct, item);
                (0,_utils_toast__WEBPACK_IMPORTED_MODULE_2__/* .notifySuccess */ .t5)(`${item} ${product.title} added to cart!`);
            } else {
                (0,_utils_toast__WEBPACK_IMPORTED_MODULE_2__/* .notifyError */ .cB)("Insufficient stock!");
            }
        }
    };
    const handleIncreaseQuantity = (product)=>{
        const result = items?.find((p)=>p.id === product.id);
        if (result) {
            // Check if product.stock is null and the increased quantity is greater than 0
            if ((product.stock === null || product.stock > 0) && result.quantity + item > 0) {
                // Check if the increased quantity is less than or equal to the stock
                if (product.stock === null || result.quantity + item <= product.stock) {
                    updateItemQuantity(product.id, result.quantity + 1);
                    (0,_utils_toast__WEBPACK_IMPORTED_MODULE_2__/* .notifySuccess */ .t5)(`item add to cart`);
                } else {
                    (0,_utils_toast__WEBPACK_IMPORTED_MODULE_2__/* .notifyError */ .cB)("Insufficient stock!");
                }
            }
            ;
        }
    };
    return {
        item,
        handleAddItem,
        handleIncreaseQuantity,
        setItem
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useAddToCart);


/***/ }),

/***/ 9338:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const useAsync = (asyncFunction)=>{
    const { 0: data , 1: setData  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([] || 0);
    const { 0: error , 1: setError  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const { 0: errCode , 1: setErrCode  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const { 0: loading , 1: setLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        let unmounted = false;
        let source = axios__WEBPACK_IMPORTED_MODULE_0___default().CancelToken.source();
        (async ()=>{
            try {
                const res = await asyncFunction({
                    cancelToken: source.token
                });
                if (!unmounted) {
                    setData(res);
                    // console.log("res", res);
                    setError("");
                    setLoading(false);
                }
            } catch (err) {
                setErrCode(err?.response?.status);
                if (!unmounted) {
                    console.log(err.message);
                    setError(err.message);
                    if (axios__WEBPACK_IMPORTED_MODULE_0___default().isCancel(err)) {
                        setError(err.message);
                        setLoading(false);
                        setData({});
                    } else {
                        // console.log('another error happened:' + err.message);
                        setError(err.message);
                        setLoading(false);
                        setData({});
                    }
                }
            }
        })();
        return ()=>{
            unmounted = true;
            source.cancel("Cancelled in cleanup");
        };
    // eslint-disable-next-line react-hooks/exhaustive-deps
    // }, [currentPage]);
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (errCode === 401) {
            Cookies.remove("userInfo");
            console.log("status 401", errCode);
            window.location.replace(`${"http://localhost:3000/"}`);
        }
    }, [
        errCode
    ]);
    return {
        data,
        error,
        loading
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useAsync);


/***/ }),

/***/ 7284:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9915);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1635);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(dayjs__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5641);
/* harmony import */ var react_use_cart__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9878);
/* harmony import */ var react_use_cart__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_use_cart__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _stripe_react_stripe_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4515);
/* harmony import */ var _stripe_react_stripe_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_stripe_react_stripe_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _hooks_useAsync__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9338);
/* harmony import */ var _context_UserContext__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5408);
/* harmony import */ var _services_OrderServices__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6139);
/* harmony import */ var _services_CouponServices__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4935);
/* harmony import */ var _utils_toast__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8548);
/* harmony import */ var _services_SettingServices__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3644);
/* harmony import */ var _context_OrderContext__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(5376);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([js_cookie__WEBPACK_IMPORTED_MODULE_0__, react_hook_form__WEBPACK_IMPORTED_MODULE_4__, _context_UserContext__WEBPACK_IMPORTED_MODULE_8__, _services_OrderServices__WEBPACK_IMPORTED_MODULE_9__, _services_CouponServices__WEBPACK_IMPORTED_MODULE_10__, _services_SettingServices__WEBPACK_IMPORTED_MODULE_12__]);
([js_cookie__WEBPACK_IMPORTED_MODULE_0__, react_hook_form__WEBPACK_IMPORTED_MODULE_4__, _context_UserContext__WEBPACK_IMPORTED_MODULE_8__, _services_OrderServices__WEBPACK_IMPORTED_MODULE_9__, _services_CouponServices__WEBPACK_IMPORTED_MODULE_10__, _services_SettingServices__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







//internal import







const useCheckoutSubmit = ()=>{
    const { state: { userInfo , shippingAddress  } , dispatch ,  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useContext)(_context_UserContext__WEBPACK_IMPORTED_MODULE_8__/* .UserContext */ .S);
    const { 0: error , 1: setError  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)("");
    const { 0: total , 1: setTotal  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)("");
    const { 0: couponInfo , 1: setCouponInfo  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({});
    const { 0: minimumAmount , 1: setMinimumAmount  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(0);
    const { 0: showCard , 1: setShowCard  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const { 0: shippingCost , 1: setShippingCost  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(0);
    const { 0: discountAmount , 1: setDiscountAmount  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(0);
    const { 0: discountPercentage , 1: setDiscountPercentage  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(0);
    const { 0: isCheckoutSubmit , 1: setIsCheckoutSubmit  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const { 0: isCouponApplied , 1: setIsCouponApplied  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const { 0: shippingDetails , 1: setShippingDetails  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)();
    const { 0: tax , 1: setTax  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)([]);
    const { 0: taxCalRes , 1: setCalRes  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)("");
    const { 0: selectItemId , 1: setSelectItemId  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)("");
    const { 0: shippingState , 1: setShippingState  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)("select state");
    const { 0: billingState , 1: setBillingState  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)("select state");
    const { 0: useFormSubmit , 1: setUseFormSubmit  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({});
    const { 0: shippingContactInfo , 1: setShippingContactInfo  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)("");
    const { 0: shippingPersonInfo , 1: setShippingPersonInfo  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)("");
    const { 0: orderResponse , 1: setOrderResponse  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(null);
    const { setOrderData  } = (0,_context_OrderContext__WEBPACK_IMPORTED_MODULE_13__/* .useOrder */ .A)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const stripe = (0,_stripe_react_stripe_js__WEBPACK_IMPORTED_MODULE_6__.useStripe)();
    const elements = (0,_stripe_react_stripe_js__WEBPACK_IMPORTED_MODULE_6__.useElements)();
    const couponRef = (0,react__WEBPACK_IMPORTED_MODULE_3__.useRef)("");
    const { isEmpty , emptyCart , items , cartTotal  } = (0,react_use_cart__WEBPACK_IMPORTED_MODULE_5__.useCart)();
    console.log("items.prices.salePrice", items);
    const totalSalePrice = items.map((items)=>items.prices.salePrice * items.quantity).reduce((acc, curr)=>acc + curr, 0);
    const { register , handleSubmit , setValue , reset , formState: { errors  } ,  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_4__.useForm)();
    const { data  } = (0,_hooks_useAsync__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)(_services_CouponServices__WEBPACK_IMPORTED_MODULE_10__/* ["default"].getAllCoupons */ .Z.getAllCoupons);
    console.log("CouponServices..", data);
    const { data: globalSetting  } = (0,_hooks_useAsync__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)(_services_SettingServices__WEBPACK_IMPORTED_MODULE_12__/* ["default"].getGlobalSetting */ .Z.getGlobalSetting);
    const currency = globalSetting?.default_currency || "₹";
    const getShippingDetails = ()=>{
        _services_SettingServices__WEBPACK_IMPORTED_MODULE_12__/* ["default"].getShippingDetails */ .Z.getShippingDetails().then((res)=>{
            if (res) {
                if (res?.success === true) {
                    setShippingDetails(res?.shippingDetailsdData);
                }
            }
        });
    };
    // const SubmitShippingData = async (data) => {};
    const handleAddress = (e)=>{
        const val = e.target.value;
        setUseFormSubmit({
            ...useFormSubmit,
            [e.target.name]: val
        });
    };
    const handleSameDetails = (e)=>{
        const checked = e.target.checked;
        if (checked === true) {
            // SubmitShippingData();
            setValue("BIllingAddress", useFormSubmit.address);
            setValue("BIllingCity", useFormSubmit.city);
            setValue("BIllingZipCode", useFormSubmit.zipCode);
            setBillingState(shippingState);
        } else {
            console.log("step2");
            setValue("BIllingAddress", "");
            setValue("BIllingCity", "");
            setValue("BIllingZipCode", "");
            setBillingState("select state");
        }
    };
    // -------------------------------tax calculation--------------------------------------------
    const handleUpdate = ()=>{
        const arr = [];
        for (let ele of items){
            const data = {
                totalPrice: ele?.itemTotal,
                quantity: ele?.quantity,
                tax: ele?.tax,
                _id: ele?._id,
                title: ele?.title,
                // variant: ele?.variant,
                pricePerUnit: ele?.price,
                state: shippingState,
                discountPerUnit: ele?.prices?.discount,
                totalPrice: ele?.prices?.price,
                salePrice: ele?.prices?.salePrice
            };
            arr.push(data);
        }
        _services_OrderServices__WEBPACK_IMPORTED_MODULE_9__/* ["default"].taxCredential */ .Z.taxCredential(arr).then((res)=>{
            if (res?.success === true) {
                // notifySuccess(res.message);
                setCalRes(res?.result);
            } else {
            // notifyError(res.message);
            }
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        if (items) {
            handleUpdate();
        }
    }, [
        items,
        shippingState
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        if (js_cookie__WEBPACK_IMPORTED_MODULE_0__["default"].get("couponInfo")) {
            const coupon = JSON.parse(js_cookie__WEBPACK_IMPORTED_MODULE_0__["default"].get("couponInfo"));
            setCouponInfo(coupon);
            setDiscountPercentage(coupon.discountType);
            setMinimumAmount(coupon.minimumAmount);
        }
    }, [
        isCouponApplied
    ]);
    const TaxCal = (items)=>{
        let taxArr = [];
        items.forEach((ele)=>{
            let totalTax = 0;
            let textName = [];
            ele?.tax?.forEach((item)=>{
                if (item.taxType === "percentage") {
                    totalTax = totalTax + ele?.prices?.salePrice * ele?.quantity * (item?.amount / 100);
                    console.log("ele?.prices?.salePrice", ele?.prices?.salePrice);
                    console.log("ele?.prices?.salePrice", totalTax);
                    console.log("ele?.prices?.salePrice", item?.amount);
                    console.log("ele?.prices?.salePrice", ele);
                    textName.push(item?.taxName);
                } else if (item.taxType === "flatin") {
                    totalTax = totalTax + parseFloat(item.amount);
                    textName.push(item?.taxName);
                }
            });
            let obj = {
                productName: ele?.slug,
                taxName: textName,
                totalTax: totalTax
            };
            taxArr.push(obj);
        });
        setTax(taxArr);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        getShippingDetails();
        TaxCal(items);
    }, [
        items
    ]);
    //remove coupon if total value less then minimum amount of coupon
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        if (minimumAmount - discountAmount > total || isEmpty) {
            setDiscountPercentage(0);
            js_cookie__WEBPACK_IMPORTED_MODULE_0__["default"].remove("couponInfo");
        }
    }, [
        minimumAmount,
        total
    ]);
    //calculate total and discount value
    //calculate total and discount value
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        const discountProductTotal = items?.reduce((preValue, currentValue)=>preValue + currentValue.itemTotal, 0);
        let totalValue = "";
        let subTotal = parseFloat(totalSalePrice + Number(shippingCost)).toFixed(2);
        const discountAmount = discountPercentage?.taxType === "fixed" ? discountPercentage?.value : discountProductTotal * (discountPercentage?.value / 100);
        console.log("discountProductTotal..", discountProductTotal);
        const discountAmountTotal = discountAmount ? discountAmount : 0;
        let totalTax = 0;
        for (let ele of tax){
            totalTax = totalTax + ele?.totalTax;
        }
        console.log("totalTax.checkout", totalTax);
        totalValue = Number(subTotal) - discountAmountTotal;
        setDiscountAmount(discountAmountTotal);
        const totalAmount = totalValue + totalTax;
        console.log("totalValue..", totalValue);
        console.log("totalTax..", totalTax);
        setTotal(totalAmount);
    }, [
        cartTotal,
        shippingCost,
        discountPercentage,
        tax
    ]);
    //if not login then push user to home page
    // useEffect(() => {
    //   if (!userInfo) {
    //     router.push("/");
    //   }
    //   setValue("firstName", shippingAddress.firstName);
    //   setValue("lastName", shippingAddress.lastName);
    //   setValue("address", shippingAddress.address);
    //   setValue("contact", shippingAddress.contact);
    //   setValue("email", shippingAddress.email);
    //   setValue("city", shippingAddress.city);
    //   setValue("country", shippingAddress.country);
    //   setValue("zipCode", shippingAddress.zipCode);
    // }, []);
    // State to hold order response
    const submitHandler = async (data)=>{
        dispatch({
            type: "SAVE_SHIPPING_ADDRESS",
            payload: data
        });
        js_cookie__WEBPACK_IMPORTED_MODULE_0__["default"].set("shippingAddress", JSON.stringify(data));
        setIsCheckoutSubmit(true);
        setError("");
        setUseFormSubmit(data);
        console.log("submitHandler..", data);
        function extractCartData(items) {
            const cartData = items.map((item)=>{
                return {
                    product: item._id,
                    quantity: item.quantity,
                    itemprice: item?.prices?.salePrice,
                    productName: item?.title
                };
            });
            return cartData;
        }
        let orderInfo = {
            user_info: {
                name: `${data.firstName} ${data.lastName}`,
                // user:userInfo._id,
                contact: data.contact,
                email: data.email,
                address: data.address,
                state: shippingState,
                city: data.city,
                zipCode: data.zipCode,
                gstnumber: data.gstnumber
            },
            user: userInfo._id,
            paymentMethod: data.paymentMethod,
            shippingOption: data.shippingOption,
            status: "Pending",
            cart: taxCalRes,
            subTotal: cartTotal,
            shippingCost: shippingCost,
            discount: discountAmount,
            total: total
        };
        // userInfo = {
        //   name: `${data.firstName} ${data.lastName}`,
        //   // user:userInfo._id,
        //   contact: data.contact,
        //   email: data.email,
        //   address: data.address,
        //   state: shippingState,
        //   city: data.city,
        //   zipCode: data.zipCode,
        // };
        let BillingInfo = {
            user_info: userInfo,
            shippingOption: data.shippingOption,
            paymentMethod: data.paymentMethod,
            status: "Pending",
            cart: items,
            subTotal: cartTotal,
            shippingCost: shippingCost,
            discount: discountAmount,
            total: total
        };
        if (data.paymentMethod === "Card") {
            if (!stripe || !elements) {
                return;
            }
            const { error , paymentMethod  } = await stripe.createPaymentMethod({
                type: "card",
                card: elements.getElement(_stripe_react_stripe_js__WEBPACK_IMPORTED_MODULE_6__.CardElement)
            });
            // console.log('error', error);
            if (error && !paymentMethod) {
                setError(error.message);
                setIsCheckoutSubmit(false);
            } else {
                setError("");
                const orderData = {
                    ...orderInfo,
                    cardInfo: paymentMethod
                };
                handlePaymentWithStripe(orderData);
                // console.log('cardInfo', orderData);
                return;
            }
        }
        if (data.paymentMethod === "Cash") {
            // const res = await OrderServices.addOrder(orderInfo); // Make the API call to add order
            // Store the order response in state
            _services_OrderServices__WEBPACK_IMPORTED_MODULE_9__/* ["default"].addOrder */ .Z.addOrder(orderInfo).then((res)=>{
                setOrderResponse(res?.order);
                setOrderData(res?.order);
                console.log(res?.order, "OrderServicesInvoice");
                js_cookie__WEBPACK_IMPORTED_MODULE_0__["default"].remove("couponInfo");
                sessionStorage.removeItem("products");
                setIsCheckoutSubmit(false);
                console.log("orderResponse...... ", orderResponse);
                router.push(`/order/${res?.order?.user}`);
                (0,_utils_toast__WEBPACK_IMPORTED_MODULE_11__/* .notifySuccess */ .t5)("Your Order Confirmed!");
                emptyCart();
            }).catch((err)=>{
                (0,_utils_toast__WEBPACK_IMPORTED_MODULE_11__/* .notifyError */ .cB)(err.message);
                setIsCheckoutSubmit(false);
            });
        }
    // reset();
    };
    // submit
    const handlePaymentWithStripe = async (order)=>{
        try {
            // console.log('try goes here!', order);
            // const updatedOrder = {
            //   ...order,
            //   currency: 'usd',
            // };
            _services_OrderServices__WEBPACK_IMPORTED_MODULE_9__/* ["default"].createPaymentIntent */ .Z.createPaymentIntent(order).then((res)=>{
                stripe.confirmCardPayment(res.client_secret, {
                    payment_method: {
                        card: elements.getElement(_stripe_react_stripe_js__WEBPACK_IMPORTED_MODULE_6__.CardElement)
                    }
                });
                const orderData = {
                    ...order,
                    cardInfo: res
                };
                _services_OrderServices__WEBPACK_IMPORTED_MODULE_9__/* ["default"].addOrder */ .Z.addOrder(orderData).then((res)=>{
                    router.push(`/order/${res._id}`);
                    (0,_utils_toast__WEBPACK_IMPORTED_MODULE_11__/* .notifySuccess */ .t5)("Your Order Confirmed!");
                    js_cookie__WEBPACK_IMPORTED_MODULE_0__["default"].remove("couponInfo");
                    emptyCart();
                    sessionStorage.removeItem("products");
                    setIsCheckoutSubmit(false);
                }).catch((err)=>{
                    (0,_utils_toast__WEBPACK_IMPORTED_MODULE_11__/* .notifyError */ .cB)(err ? err?.response?.data?.message : err.message);
                    setIsCheckoutSubmit(false);
                });
            // console.log('res', res, 'paymentIntent', paymentIntent);
            }).catch((err)=>{
                (0,_utils_toast__WEBPACK_IMPORTED_MODULE_11__/* .notifyError */ .cB)(err ? err?.response?.data?.message : err.message);
                setIsCheckoutSubmit(false);
            });
        } catch (err) {
            (0,_utils_toast__WEBPACK_IMPORTED_MODULE_11__/* .notifyError */ .cB)(err ? err?.response?.data?.message : err.message);
            setIsCheckoutSubmit(false);
        }
    };
    const handleShippingCost = (value, id)=>{
        setShippingCost(value);
        setSelectItemId(id);
        setShippingContactInfo("");
        setShippingPersonInfo("");
        setValue("contactInfo", "");
        setValue("PersonInfo", "");
    };
    const handleShippingContactInfo = (val)=>{
        setShippingContactInfo(val);
        setValue("contactInfo", val);
    };
    const handleShippingPersonInfo = (val)=>{
        setShippingPersonInfo(val);
        setValue("PersonInfo", val);
    };
    const handleCouponCode = (e)=>{
        console.log("couponRef..", e);
        e.preventDefault();
        if (!couponRef.current.value) {
            (0,_utils_toast__WEBPACK_IMPORTED_MODULE_11__/* .notifyError */ .cB)("Please Input a Coupon Code!");
            return;
        }
        const result = data.coupons.filter((coupons)=>coupons.couponCode === couponRef.current.value);
        if (result.length < 1) {
            (0,_utils_toast__WEBPACK_IMPORTED_MODULE_11__/* .notifyError */ .cB)("Please Input a Valid Coupon!");
            return;
        }
        if (dayjs__WEBPACK_IMPORTED_MODULE_1___default()().isAfter(dayjs__WEBPACK_IMPORTED_MODULE_1___default()(result[0]?.endTime))) {
            (0,_utils_toast__WEBPACK_IMPORTED_MODULE_11__/* .notifyError */ .cB)("This coupon is not valid!");
            return;
        }
        if (total < result[0]?.minimumAmount) {
            (0,_utils_toast__WEBPACK_IMPORTED_MODULE_11__/* .notifyError */ .cB)(`Minimum Rs: ${result[0].minimumAmount} required for Apply this coupon!`);
            return;
        } else {
            (0,_utils_toast__WEBPACK_IMPORTED_MODULE_11__/* .notifySuccess */ .t5)(`Your Coupon ${result[0].couponCode} is Applied on ${result[0].productType}!`);
            setIsCouponApplied(true);
            setMinimumAmount(result[0]?.minimumAmount);
            setDiscountPercentage(result[0].discountType);
            dispatch({
                type: "SAVE_COUPON",
                payload: result[0]
            });
            js_cookie__WEBPACK_IMPORTED_MODULE_0__["default"].set("couponInfo", JSON.stringify(result[0]));
        }
    };
    return {
        handleSubmit,
        submitHandler,
        handleShippingCost,
        register,
        errors,
        showCard,
        setShowCard,
        error,
        stripe,
        couponInfo,
        couponRef,
        handleCouponCode,
        discountPercentage,
        discountAmount,
        shippingCost,
        total,
        isEmpty,
        items,
        cartTotal,
        currency,
        isCheckoutSubmit,
        isCouponApplied,
        shippingDetails,
        tax,
        taxCalRes,
        selectItemId,
        handleSameDetails,
        billingState,
        setBillingState,
        shippingState,
        setShippingState,
        handleAddress,
        handleShippingContactInfo,
        handleShippingPersonInfo,
        orderResponse,
        setOrderResponse
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useCheckoutSubmit);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8269:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9915);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5641);
/* harmony import */ var _react_oauth_google__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6999);
/* harmony import */ var _react_oauth_google__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_react_oauth_google__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _context_UserContext__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5408);
/* harmony import */ var _utils_toast__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8548);
/* harmony import */ var _services_CustomerServices__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4354);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([js_cookie__WEBPACK_IMPORTED_MODULE_0__, react_hook_form__WEBPACK_IMPORTED_MODULE_3__, _context_UserContext__WEBPACK_IMPORTED_MODULE_5__, _services_CustomerServices__WEBPACK_IMPORTED_MODULE_7__]);
([js_cookie__WEBPACK_IMPORTED_MODULE_0__, react_hook_form__WEBPACK_IMPORTED_MODULE_3__, _context_UserContext__WEBPACK_IMPORTED_MODULE_5__, _services_CustomerServices__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





//internal import



const useLoginSubmit = (setModalOpen)=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
    const { redirect  } = router.query;
    const { dispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(_context_UserContext__WEBPACK_IMPORTED_MODULE_5__/* .UserContext */ .S);
    const { 0: loading , 1: setLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const { register , handleSubmit , setValue , formState: { errors  } ,  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_3__.useForm)();
    const submitHandler = ({ name , email , loginIdentifier , verifyEmail , password ,  })=>{
        setLoading(true);
        const cookieTimeOut = 0.5;
        if (loginIdentifier && password) {
            _services_CustomerServices__WEBPACK_IMPORTED_MODULE_7__/* ["default"].customerLogin */ .Z.customerLogin({
                loginIdentifier,
                password,
                loginType: "email"
            }).then((res)=>{
                console.log("user login ...", res);
                setLoading(false);
                setModalOpen(false);
                router.push(redirect || "/");
                (0,_utils_toast__WEBPACK_IMPORTED_MODULE_6__/* .notifySuccess */ .t5)("Login Success!");
                dispatch({
                    type: "USER_LOGIN",
                    payload: res
                });
                js_cookie__WEBPACK_IMPORTED_MODULE_0__["default"].set("userInfo", JSON.stringify(res), {
                    expires: cookieTimeOut
                });
            }).catch((err)=>{
                (0,_utils_toast__WEBPACK_IMPORTED_MODULE_6__/* .notifyError */ .cB)(err ? err.response.data.message : err.message);
                setLoading(false);
            });
        }
        if (name && email && password) {
            _services_CustomerServices__WEBPACK_IMPORTED_MODULE_7__/* ["default"].verifyEmailAddress */ .Z.verifyEmailAddress({
                name,
                email,
                password
            }).then((res)=>{
                setLoading(false);
                setModalOpen(false);
                (0,_utils_toast__WEBPACK_IMPORTED_MODULE_6__/* .notifySuccess */ .t5)(res.message);
            }).catch((err)=>{
                setLoading(false);
                (0,_utils_toast__WEBPACK_IMPORTED_MODULE_6__/* .notifyError */ .cB)(err.response.data.message);
            });
        }
        if (verifyEmail) {
            _services_CustomerServices__WEBPACK_IMPORTED_MODULE_7__/* ["default"].forgetPassword */ .Z.forgetPassword({
                verifyEmail
            }).then((res)=>{
                setLoading(false);
                (0,_utils_toast__WEBPACK_IMPORTED_MODULE_6__/* .notifySuccess */ .t5)(res.message);
                setValue("verifyEmail");
            }).catch((err)=>{
                setLoading(false);
                (0,_utils_toast__WEBPACK_IMPORTED_MODULE_6__/* .notifyError */ .cB)(err ? err.response.data.message : err.message);
            });
        }
    };
    const handleGoogleSignIn = (user)=>{
        // console.log("google sign in", user?.credential);
        const cookieTimeOut = 0.5;
        if (user) {
            _services_CustomerServices__WEBPACK_IMPORTED_MODULE_7__/* ["default"].signUpWithProvider */ .Z.signUpWithProvider(user?.credential).then((res)=>{
                setModalOpen(false);
                (0,_utils_toast__WEBPACK_IMPORTED_MODULE_6__/* .notifySuccess */ .t5)("Login success!");
                router.push(redirect || "/");
                dispatch({
                    type: "USER_LOGIN",
                    payload: res
                });
                js_cookie__WEBPACK_IMPORTED_MODULE_0__["default"].set("userInfo", JSON.stringify(res), {
                    expires: cookieTimeOut
                });
            }).catch((err)=>{
                (0,_utils_toast__WEBPACK_IMPORTED_MODULE_6__/* .notifyError */ .cB)(err.message);
                setModalOpen(false);
            });
        }
    };
    return {
        handleSubmit,
        submitHandler,
        handleGoogleSignIn,
        register,
        errors,
        GoogleLogin: _react_oauth_google__WEBPACK_IMPORTED_MODULE_4__.GoogleLogin,
        loading
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useLoginSubmit);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1286:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1187);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _layout_navbar_Navbar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4780);
/* harmony import */ var _layout_footer_Footer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4560);
/* harmony import */ var _navbar_NavBarTop__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7893);
/* harmony import */ var _layout_footer_FooterTop__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6395);
/* harmony import */ var _layout_footer_MobileFooter__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2728);
/* harmony import */ var _component_feature_card_FeatureCard__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7577);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_layout_navbar_Navbar__WEBPACK_IMPORTED_MODULE_3__, _layout_footer_Footer__WEBPACK_IMPORTED_MODULE_4__, _navbar_NavBarTop__WEBPACK_IMPORTED_MODULE_5__, _layout_footer_FooterTop__WEBPACK_IMPORTED_MODULE_6__, _layout_footer_MobileFooter__WEBPACK_IMPORTED_MODULE_7__, _component_feature_card_FeatureCard__WEBPACK_IMPORTED_MODULE_8__]);
([_layout_navbar_Navbar__WEBPACK_IMPORTED_MODULE_3__, _layout_footer_Footer__WEBPACK_IMPORTED_MODULE_4__, _navbar_NavBarTop__WEBPACK_IMPORTED_MODULE_5__, _layout_footer_FooterTop__WEBPACK_IMPORTED_MODULE_6__, _layout_footer_MobileFooter__WEBPACK_IMPORTED_MODULE_7__, _component_feature_card_FeatureCard__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



//internal import






const Layout = ({ title , description , children  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_toastify__WEBPACK_IMPORTED_MODULE_2__.ToastContainer, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "font-sans",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                                children: title ? `EcommEdge | ${title}` : "EcommEdge"
                            }),
                            description && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                                name: "description",
                                content: description
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                                ref: "icon",
                                href: "/logo/Ecomedge.png"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_navbar_NavBarTop__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_layout_navbar_Navbar__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "bg-gray-50",
                        children: children
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_layout_footer_MobileFooter__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {}),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "hidden relative lg:block mx-auto max-w-screen-2xl py-6 px-3 sm:px-10",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_feature_card_FeatureCard__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {})
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                className: "hr-line"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "border-t border-gray-100 w-full",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_layout_footer_Footer__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Layout);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4560:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(543);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8027);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3521);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(866);
/* harmony import */ var next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_share__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6158);
/* harmony import */ var react_share__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_share__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _context_UserContext__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5408);
/* harmony import */ var _hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5538);
/* harmony import */ var _component_preloader_CMSkeleton__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2038);
/* harmony import */ var _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(545);
/* harmony import */ var _hooks_useAsync__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9338);
/* harmony import */ var _services_SettingServices__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3644);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_context_UserContext__WEBPACK_IMPORTED_MODULE_7__, _hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_8__, _component_preloader_CMSkeleton__WEBPACK_IMPORTED_MODULE_9__, _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_10__, _services_SettingServices__WEBPACK_IMPORTED_MODULE_12__]);
([_context_UserContext__WEBPACK_IMPORTED_MODULE_7__, _hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_8__, _component_preloader_CMSkeleton__WEBPACK_IMPORTED_MODULE_9__, _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_10__, _services_SettingServices__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







//internal import








const Footer = ()=>{
    const { t  } = next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_5___default()();
    const { state: { userInfo  } ,  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_UserContext__WEBPACK_IMPORTED_MODULE_7__/* .UserContext */ .S);
    const { showingTranslateValue  } = (0,_hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)();
    const { loading , storeCustomizationSetting  } = (0,_hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
    const { data , error  } = (0,_hooks_useAsync__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z)(()=>_services_SettingServices__WEBPACK_IMPORTED_MODULE_12__/* ["default"].getSettingFooter */ .Z.getSettingFooter());
    // console.log("data==>", data);
    const currentDate = new Date();
    const currentYear = currentDate.getFullYear().toString();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "pb-16 lg:pb-0 xl:pb-0 bg-white",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mx-auto max-w-screen-2xl px-4 sm:px-10",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "grid grid-cols-2 md:grid-cols-7 xl:grid-cols-12 gap-5 sm:gap-9 lg:gap-11 xl:gap-7 py-10 lg:py-16 justify-between",
                        children: [
                            storeCustomizationSetting?.footer?.block1_status && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "pb-3.5 sm:pb-0 col-span-1 md:col-span-2 lg:col-span-3",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: "text-md lg:leading-7 font-medium mb-4 sm:mb-5 lg:mb-6 pb-0.5",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_preloader_CMSkeleton__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                            count: 1,
                                            height: 20,
                                            // error={error}
                                            loading: loading,
                                            data: storeCustomizationSetting?.footer?.block1_title
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                        className: "text-sm flex flex-col space-y-3",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                className: "flex items-baseline",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                    href: `${storeCustomizationSetting?.footer?.block1_sub_link1}`,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                        className: "text-gray-600 inline-block w-full hover:text-gray-500",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_preloader_CMSkeleton__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                            count: 1,
                                                            height: 10,
                                                            // error={error}
                                                            loading: loading,
                                                            data: storeCustomizationSetting?.footer?.block1_sub_title1
                                                        })
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                className: "flex items-baseline",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                    href: `${storeCustomizationSetting?.footer?.block1_sub_link2}`,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                        className: "text-gray-600 inline-block w-full hover:text-gray-500",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_preloader_CMSkeleton__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                            count: 1,
                                                            height: 10,
                                                            // error={error}
                                                            loading: loading,
                                                            data: storeCustomizationSetting?.footer?.block1_sub_title2
                                                        })
                                                    })
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            storeCustomizationSetting?.footer?.block3_status && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "pb-3.5 sm:pb-0 col-span-1 md:col-span-2 lg:col-span-3",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: "text-md lg:leading-7 font-medium mb-4 sm:mb-5 lg:mb-6 pb-0.5",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_preloader_CMSkeleton__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                            count: 1,
                                            height: 20,
                                            // error={error}
                                            loading: loading,
                                            data: storeCustomizationSetting?.footer?.block3_title
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                        className: "text-sm lg:text-15px flex flex-col space-y-3",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                className: "flex items-baseline",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                    href: `${userInfo?.email ? storeCustomizationSetting?.footer?.block3_sub_link2 : "#"}`,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                        className: "text-gray-600 inline-block w-full hover:text-gray-500",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_preloader_CMSkeleton__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                            count: 1,
                                                            height: 10,
                                                            // error={error}
                                                            loading: loading,
                                                            data: storeCustomizationSetting?.footer?.block3_sub_title2
                                                        })
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                className: "flex items-baseline",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                    href: `${userInfo?.email ? storeCustomizationSetting?.footer?.block3_sub_link3 : "#"}`,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                        className: "text-gray-600 inline-block w-full hover:text-gray-500",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_preloader_CMSkeleton__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                            count: 1,
                                                            height: 10,
                                                            // error={error}
                                                            loading: loading,
                                                            data: storeCustomizationSetting?.footer?.block3_sub_title3
                                                        })
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                className: "flex items-baseline",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                    href: `${userInfo?.email ? storeCustomizationSetting?.footer?.block3_sub_link4 : "#"}`,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                        className: "text-gray-600 inline-block w-full hover:text-gray-500",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_preloader_CMSkeleton__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                            count: 1,
                                                            height: 10,
                                                            // error={error}
                                                            loading: loading,
                                                            data: storeCustomizationSetting?.footer?.block3_sub_title4
                                                        })
                                                    })
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            storeCustomizationSetting?.footer?.block4_status && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "pb-3.5 sm:pb-0 col-span-1 md:col-span-2 lg:col-span-3",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        href: "/",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            className: "mr-3 lg:mr-12 xl:mr-12",
                                            rel: "noreferrer",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                width: 50,
                                                height: 30,
                                                src: "/logo/Ecomedge.png",
                                                alt: "logo"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                        className: "leading-7 font-sans text-sm text-gray-600 mt-3",
                                        children: [
                                            data?.globalSetting?.address,
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_preloader_CMSkeleton__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                count: 1,
                                                height: 10,
                                                // error={error}
                                                loading: loading,
                                                data: data?.globalSetting?.address
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                children: [
                                                    " Tel : ",
                                                    data?.globalSetting?.contact
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                children: [
                                                    " Email : ",
                                                    data?.globalSetting?.email
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                        className: "hr-line"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "mx-auto max-w-screen-2xl px-4 sm:px-10 bg-gray-50 shadow-sm border border-gray-50 rounded-lg",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "grid grid-cols-2 md:grid-cols-3 xl:grid-cols-3 gap-5 sm:gap-9 lg:gap-11 xl:gap-7 py-8 items-center justify-between",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-span-1",
                                    children: storeCustomizationSetting?.footer?.social_links_status && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        children: [
                                            (storeCustomizationSetting?.footer?.social_facebook || storeCustomizationSetting?.footer?.social_twitter || storeCustomizationSetting?.footer?.social_pinterest || storeCustomizationSetting?.footer?.social_linkedin || storeCustomizationSetting?.footer?.social_whatsapp) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-base leading-7 font-medium block mb-2 pb-0.5",
                                                children: t("common:footer-follow-us")
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                                className: "text-sm flex",
                                                children: [
                                                    storeCustomizationSetting?.footer?.social_facebook && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        className: "flex items-center mr-3 transition ease-in-out duration-500",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                            href: `${storeCustomizationSetting?.footer?.social_facebook}`,
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                "aria-label": "Social Link",
                                                                rel: "noreferrer",
                                                                target: "_blank",
                                                                className: "block text-center mx-auto text-gray-500 hover:text-white",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_6__.FacebookIcon, {
                                                                    size: 34,
                                                                    round: true
                                                                })
                                                            })
                                                        })
                                                    }),
                                                    storeCustomizationSetting?.footer?.social_linkedin && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        className: "flex items-center mr-3 transition ease-in-out duration-500",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                            href: `${storeCustomizationSetting?.footer?.social_linkedin}`,
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                "aria-label": "Social Link",
                                                                rel: "noreferrer",
                                                                target: "_blank",
                                                                className: "block text-center mx-auto text-gray-500 hover:text-white",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_6__.LinkedinIcon, {
                                                                    size: 34,
                                                                    round: true
                                                                })
                                                            })
                                                        })
                                                    }),
                                                    storeCustomizationSetting?.footer?.social_whatsapp && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        className: "flex items-center mr-3 transition ease-in-out duration-500",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                            href: `${storeCustomizationSetting?.footer?.social_whatsapp}`,
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                "aria-label": "Social Link",
                                                                rel: "noreferrer",
                                                                target: "_blank",
                                                                className: "block text-center mx-auto text-gray-500 hover:text-white",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_6__.WhatsappIcon, {
                                                                    size: 34,
                                                                    round: true
                                                                })
                                                            })
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-span-1 text-center hidden lg:block md:block",
                                    children: storeCustomizationSetting?.footer?.bottom_contact_status && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: "text-base leading-7 font-medium block",
                                                children: t("common:footer-call-us")
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                                className: "text-2xl font-bold text-grey-500 leading-7",
                                                children: data?.globalSetting?.contact
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "mx-auto max-w-screen-2xl px-3 sm:px-10 flex justify-center py-4",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                    className: "text-sm text-gray-500 leading-6",
                    children: [
                        "Copyright ",
                        currentYear,
                        " @",
                        " ",
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                            href: "http://tridyota.com",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                target: "_blank",
                                rel: "noopener noreferrer",
                                className: "text-gray-500",
                                children: "EcommEdge"
                            })
                        }),
                        " ",
                        ", All rights reserved.",
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                        "Developed and Maintained by",
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                            href: "https://amitcorpo.com",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                target: "_blank",
                                rel: "noopener noreferrer",
                                className: "text-gray-800",
                                children: "\xa0amitcorpo.com"
                            })
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (next_dynamic__WEBPACK_IMPORTED_MODULE_4___default()(()=>Promise.resolve(Footer), {
    ssr: false
}));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6395:
/***/ ((module, __unused_webpack___webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(543);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8027);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5538);
/* harmony import */ var _component_preloader_CMSkeleton__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2038);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_4__, _component_preloader_CMSkeleton__WEBPACK_IMPORTED_MODULE_5__]);
([_hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_4__, _component_preloader_CMSkeleton__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




//internal import


const FooterTop = ()=>{
    const { storeCustomizationSetting , loading , error  } = useGetSetting();
    return /*#__PURE__*/ _jsx("div", {
        id: "downloadApp",
        className: "bg-indigo-50 py-10 lg:py-16 bg-repeat bg-center overflow-hidden",
        children: /*#__PURE__*/ _jsx("div", {
            className: "max-w-screen-2xl mx-auto px-4 sm:px-10",
            children: /*#__PURE__*/ _jsxs("div", {
                className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 2xl:grid-cols-3 gap-2 md:gap-3 lg:gap-3 items-center",
                children: [
                    /*#__PURE__*/ _jsx("div", {
                        className: "flex-grow hidden lg:flex md:flex md:justify-items-center lg:justify-start",
                        children: /*#__PURE__*/ _jsx("img", {
                            src: storeCustomizationSetting?.home?.daily_need_img_left || "/app-download-img-left.png",
                            alt: "app download",
                            width: 500,
                            height: 394,
                            className: "block w-auto"
                        })
                    }),
                    /*#__PURE__*/ _jsxs("div", {
                        className: "text-center",
                        children: [
                            /*#__PURE__*/ _jsx("h3", {
                                className: "text-xl md:text-2xl lg:text-3xl font-bold font-serif mb-3",
                                children: /*#__PURE__*/ _jsx(CMSkeleton, {
                                    count: 1,
                                    height: 30,
                                    // error={error}
                                    loading: loading,
                                    data: storeCustomizationSetting?.home?.daily_need_title
                                })
                            }),
                            /*#__PURE__*/ _jsx("p", {
                                className: "text-base opacity-90 leading-7",
                                children: /*#__PURE__*/ _jsx(CMSkeleton, {
                                    count: 5,
                                    height: 10,
                                    error: error,
                                    loading: loading,
                                    data: storeCustomizationSetting?.home?.daily_need_description
                                })
                            }),
                            /*#__PURE__*/ _jsxs("div", {
                                className: "mt-8",
                                children: [
                                    /*#__PURE__*/ _jsx(Link, {
                                        href: `${storeCustomizationSetting?.home?.daily_need_app_link}`,
                                        children: /*#__PURE__*/ _jsx("a", {
                                            className: "mx-2",
                                            target: "_blank",
                                            rel: "noreferrer",
                                            children: /*#__PURE__*/ _jsx("img", {
                                                width: 170,
                                                height: 50,
                                                className: "mr-2 rounded",
                                                src: storeCustomizationSetting?.home?.button1_img || "/app/app-store.svg",
                                                alt: "app store"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ _jsx(Link, {
                                        href: `${storeCustomizationSetting?.home?.daily_need_google_link}`,
                                        children: /*#__PURE__*/ _jsx("a", {
                                            target: "_blank",
                                            rel: "noreferrer",
                                            children: /*#__PURE__*/ _jsx("img", {
                                                width: 170,
                                                height: 50,
                                                src: storeCustomizationSetting?.home?.button2_img || "/app/play-store.svg",
                                                alt: "",
                                                className: "block w-auto object-contain"
                                            })
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ _jsx("div", {
                        className: "md:hidden lg:block",
                        children: /*#__PURE__*/ _jsx("div", {
                            className: "flex-grow hidden lg:flex md:flex lg:justify-end",
                            children: /*#__PURE__*/ _jsx("img", {
                                src: storeCustomizationSetting?.home?.daily_need_img_right || "/app-download-img.png",
                                width: 500,
                                height: 394,
                                alt: "app download",
                                className: "block w-auto"
                            })
                        })
                    })
                ]
            })
        })
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (FooterTop)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2728:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(543);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8027);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3521);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_use_cart__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9878);
/* harmony import */ var react_use_cart__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_use_cart__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2750);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _context_UserContext__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5408);
/* harmony import */ var _component_modal_LoginModal__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1859);
/* harmony import */ var _context_SidebarContext__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6812);
/* harmony import */ var _component_drawer_CategoryDrawer__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4407);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_context_UserContext__WEBPACK_IMPORTED_MODULE_7__, _component_modal_LoginModal__WEBPACK_IMPORTED_MODULE_8__, _context_SidebarContext__WEBPACK_IMPORTED_MODULE_9__, _component_drawer_CategoryDrawer__WEBPACK_IMPORTED_MODULE_10__]);
([_context_UserContext__WEBPACK_IMPORTED_MODULE_7__, _component_modal_LoginModal__WEBPACK_IMPORTED_MODULE_8__, _context_SidebarContext__WEBPACK_IMPORTED_MODULE_9__, _component_drawer_CategoryDrawer__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











const MobileFooter = ()=>{
    const { 0: modalOpen , 1: setModalOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { toggleCartDrawer , toggleCategoryDrawer  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_SidebarContext__WEBPACK_IMPORTED_MODULE_9__/* .SidebarContext */ .l);
    const { totalItems  } = (0,react_use_cart__WEBPACK_IMPORTED_MODULE_5__.useCart)();
    const { state: { userInfo  } ,  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_UserContext__WEBPACK_IMPORTED_MODULE_7__/* .UserContext */ .S);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_modal_LoginModal__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                modalOpen: modalOpen,
                setModalOpen: setModalOpen
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex flex-col h-full justify-between align-middle bg-white rounded cursor-pointer overflow-y-scroll flex-grow scrollbar-hide w-full",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_drawer_CategoryDrawer__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                    className: "w-6 h-6 drop-shadow-xl"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("footer", {
                className: "lg:hidden fixed z-30 bottom-0 bg-gray-800 flex items-center justify-between w-full h-16 px-3 sm:px-10",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        "aria-label": "Bar",
                        onClick: toggleCategoryDrawer,
                        className: "flex items-center justify-center flex-shrink-0 h-auto relative focus:outline-none",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "text-xl text-white",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_6__.FiAlignLeft, {
                                className: "w-6 h-6 drop-shadow-xl"
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                        href: "/",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                            className: "text-xl text-white",
                            rel: "noreferrer",
                            "aria-label": "Home",
                            children: [
                                " ",
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_6__.FiHome, {
                                    className: "w-6 h-6 drop-shadow-xl"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                        onClick: toggleCartDrawer,
                        className: "h-9 w-9 relative whitespace-nowrap inline-flex items-center justify-center text-white text-lg",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "absolute z-10 top-0 right-0 inline-flex items-center justify-center p-1 h-5 w-5 text-xs font-bold leading-none text-red-100 transform translate-x-1/2 bg-red-500 rounded-full",
                                children: totalItems
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_6__.FiShoppingCart, {
                                className: "w-6 h-6 drop-shadow-xl"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        "aria-label": "User",
                        type: "button",
                        className: "text-xl text-white indicator justify-center",
                        children: userInfo?.image ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                            href: "/user/dashboard",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                className: "relative top-1 w-6 h-6",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    width: 29,
                                    height: 29,
                                    src: userInfo.image,
                                    alt: "user",
                                    className: "rounded-full"
                                })
                            })
                        }) : userInfo?.name ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                            href: "/user/dashboard",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                className: "leading-none font-bold font-serif block",
                                children: userInfo?.name[0]
                            })
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            onClick: ()=>setModalOpen(!modalOpen),
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_6__.FiUser, {
                                className: "w-6 h-6 drop-shadow-xl"
                            })
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (next_dynamic__WEBPACK_IMPORTED_MODULE_4___default()(()=>Promise.resolve(MobileFooter), {
    ssr: false
}));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7893:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(543);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9915);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3521);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9989);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_icons_io5__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2750);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _component_modal_LoginModal__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1859);
/* harmony import */ var _context_UserContext__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5408);
/* harmony import */ var _hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5538);
/* harmony import */ var _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(545);
/* harmony import */ var _services_SettingServices__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3644);
/* harmony import */ var _hooks_useAsync__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9338);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([js_cookie__WEBPACK_IMPORTED_MODULE_4__, _component_modal_LoginModal__WEBPACK_IMPORTED_MODULE_8__, _context_UserContext__WEBPACK_IMPORTED_MODULE_9__, _hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_10__, _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_11__, _services_SettingServices__WEBPACK_IMPORTED_MODULE_12__]);
([js_cookie__WEBPACK_IMPORTED_MODULE_4__, _component_modal_LoginModal__WEBPACK_IMPORTED_MODULE_8__, _context_UserContext__WEBPACK_IMPORTED_MODULE_9__, _hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_10__, _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_11__, _services_SettingServices__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








//internal import






const NavBarTop = ()=>{
    const { dispatch , state: { userInfo  } ,  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_UserContext__WEBPACK_IMPORTED_MODULE_9__/* .UserContext */ .S);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const { 0: modalOpen , 1: setModalOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { storeCustomizationSetting  } = (0,_hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)();
    const { showingTranslateValue  } = (0,_hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z)();
    const { data , error  } = (0,_hooks_useAsync__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z)(()=>_services_SettingServices__WEBPACK_IMPORTED_MODULE_12__/* ["default"].getSettingFooter */ .Z.getSettingFooter());
    const handleModal = ()=>{
        if (userInfo?.email) {
            router.push("/user/dashboard");
        } else {
            setModalOpen(!modalOpen);
        }
    };
    const handleLogOut = ()=>{
        dispatch({
            type: "USER_LOGOUT"
        });
        js_cookie__WEBPACK_IMPORTED_MODULE_4__["default"].remove("userInfo");
        js_cookie__WEBPACK_IMPORTED_MODULE_4__["default"].remove("couponInfo");
        router.push("/");
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            modalOpen && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_modal_LoginModal__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                modalOpen: modalOpen,
                setModalOpen: setModalOpen
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "hidden lg:block bg-gray-100",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "max-w-screen-2xl mx-auto px-3 sm:px-10",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "text-gray-700 py-2 font-sans text-xs font-medium border-b flex justify-between items-center",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "flex items-center",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_7__.FiPhoneCall, {
                                        className: "mr-2"
                                    }),
                                    showingTranslateValue(storeCustomizationSetting?.navbar?.help_text),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        href: `tel:${data?.globalSetting?.contact}`,
                                        className: "font-bold text-gray-500 ml-1",
                                        children: data?.globalSetting?.contact
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "lg:text-right flex items-center navBar",
                                children: [
                                    storeCustomizationSetting?.navbar?.about_menu_status && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                href: "/about-us",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                    className: "font-medium hover:text-gray-600",
                                                    children: showingTranslateValue(storeCustomizationSetting?.navbar?.about_us)
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "mx-2",
                                                children: "|"
                                            })
                                        ]
                                    }),
                                    storeCustomizationSetting?.navbar?.contact_menu_status && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                href: "/contact-us",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                    className: "font-medium hover:text-gray-600",
                                                    children: showingTranslateValue(storeCustomizationSetting?.navbar?.contact_us)
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "mx-2",
                                                children: "|"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        onClick: handleModal,
                                        className: "font-medium hover:text-gray-600",
                                        children: showingTranslateValue(storeCustomizationSetting?.navbar?.my_account)
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "mx-2",
                                        children: "|"
                                    }),
                                    userInfo?.email ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                        onClick: handleLogOut,
                                        className: "flex items-center font-medium hover:text-gray-600",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "mr-1",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io5__WEBPACK_IMPORTED_MODULE_6__.IoLockOpenOutline, {})
                                            }),
                                            showingTranslateValue(storeCustomizationSetting?.navbar?.logout)
                                        ]
                                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                        onClick: ()=>setModalOpen(!modalOpen),
                                        className: "flex items-center font-medium hover:text-gray-600",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "mr-1",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_7__.FiUser, {})
                                            }),
                                            showingTranslateValue(storeCustomizationSetting?.navbar?.login)
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (next_dynamic__WEBPACK_IMPORTED_MODULE_5___default()(()=>Promise.resolve(NavBarTop), {
    ssr: false
}));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4780:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9915);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(543);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8027);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3521);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_use_cart__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9878);
/* harmony import */ var react_use_cart__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_use_cart__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9989);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_icons_io5__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2750);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(866);
/* harmony import */ var next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _layout_navbar_NavbarPromo__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1000);
/* harmony import */ var _context_UserContext__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5408);
/* harmony import */ var _component_modal_LoginModal__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1859);
/* harmony import */ var _component_drawer_CartDrawer__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(3596);
/* harmony import */ var _context_SidebarContext__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(6812);
/* harmony import */ var _hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(5538);
/* harmony import */ var _services_ProductServices__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(2981);
/* harmony import */ var _utils_toast__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(8548);
/* harmony import */ var _component_modal_ProductEnquiry__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(8624);
/* harmony import */ var _component_drawer_NotificationDrawer__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(8643);
/* harmony import */ var _hooks_useAsync__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(9338);
/* harmony import */ var _services_NotificationServices__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(6018);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([js_cookie__WEBPACK_IMPORTED_MODULE_2__, _layout_navbar_NavbarPromo__WEBPACK_IMPORTED_MODULE_11__, _context_UserContext__WEBPACK_IMPORTED_MODULE_12__, _component_modal_LoginModal__WEBPACK_IMPORTED_MODULE_13__, _component_drawer_CartDrawer__WEBPACK_IMPORTED_MODULE_14__, _context_SidebarContext__WEBPACK_IMPORTED_MODULE_15__, _hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_16__, _services_ProductServices__WEBPACK_IMPORTED_MODULE_17__, _component_modal_ProductEnquiry__WEBPACK_IMPORTED_MODULE_19__, _component_drawer_NotificationDrawer__WEBPACK_IMPORTED_MODULE_20__, _services_NotificationServices__WEBPACK_IMPORTED_MODULE_22__]);
([js_cookie__WEBPACK_IMPORTED_MODULE_2__, _layout_navbar_NavbarPromo__WEBPACK_IMPORTED_MODULE_11__, _context_UserContext__WEBPACK_IMPORTED_MODULE_12__, _component_modal_LoginModal__WEBPACK_IMPORTED_MODULE_13__, _component_drawer_CartDrawer__WEBPACK_IMPORTED_MODULE_14__, _context_SidebarContext__WEBPACK_IMPORTED_MODULE_15__, _hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_16__, _services_ProductServices__WEBPACK_IMPORTED_MODULE_17__, _component_modal_ProductEnquiry__WEBPACK_IMPORTED_MODULE_19__, _component_drawer_NotificationDrawer__WEBPACK_IMPORTED_MODULE_20__, _services_NotificationServices__WEBPACK_IMPORTED_MODULE_22__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











//internal import












const Navbar = ()=>{
    const { t  } = next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_10___default()();
    const { 0: imageUrl , 1: setImageUrl  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const { 0: searchText , 1: setSearchText  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const { 0: modalOpen , 1: setModalOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: modalOpenEnquiry , 1: setModalOpenEnquiry  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: searchData , 1: setSearchData  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { 0: showSearchData , 1: setShowSearchData  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: searchRes , 1: setSearchRes  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { toggleCartDrawer  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_SidebarContext__WEBPACK_IMPORTED_MODULE_15__/* .SidebarContext */ .l);
    const { toggleNotificationDrawer  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_SidebarContext__WEBPACK_IMPORTED_MODULE_15__/* .SidebarContext */ .l);
    const { totalItems  } = (0,react_use_cart__WEBPACK_IMPORTED_MODULE_7__.useCart)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_6__.useRouter)();
    const { data  } = (0,_hooks_useAsync__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .Z)(_services_NotificationServices__WEBPACK_IMPORTED_MODULE_22__/* ["default"].getAllNotification */ .Z.getAllNotification);
    const searchRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const { storeCustomizationSetting  } = (0,_hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z)();
    const { state: { userInfo  } ,  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_UserContext__WEBPACK_IMPORTED_MODULE_12__/* .UserContext */ .S);
    const handleSearchInput = (e)=>{
        const val = e.target.value;
        setSearchText(val);
        if (val.length > 2) {
            _services_ProductServices__WEBPACK_IMPORTED_MODULE_17__/* ["default"].getSearchSuggestProducts */ .Z.getSearchSuggestProducts({
                query: val
            }).then((res)=>{
                if (res) {
                    if (res?.success === true) {
                        setSearchData(res);
                        setShowSearchData(true);
                        if (!res?.categorysearchResult && !res?.productsearchResult) {
                            setSearchRes(true);
                        } else {
                            setSearchRes(false);
                        }
                    } else {
                        (0,_utils_toast__WEBPACK_IMPORTED_MODULE_18__/* .notifyError */ .cB)(res.message);
                    }
                }
            });
        } else {
            setSearchData(null);
            setShowSearchData(false);
            setSearchRes(false); // Reset searchRes when input length is less than 3
        }
    };
    const handleSubmit = (e)=>{
        e.preventDefault();
        if (searchText) {
            router.push(`/search?category=${searchText}`, null, {
                scroll: false
            });
            setSearchText("");
        } else {
            router.push(`/`, null, {
                scroll: false
            });
            setSearchText("");
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (js_cookie__WEBPACK_IMPORTED_MODULE_2__["default"].get("userInfo")) {
            const user = JSON.parse(js_cookie__WEBPACK_IMPORTED_MODULE_2__["default"].get("userInfo"));
            setImageUrl(user.image);
        }
    }, []);
    // Handle clicks outside the search bar to hide search data
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const handleClickOutside = (event)=>{
            if (searchRef.current && !searchRef.current.contains(event.target)) {
                setShowSearchData(false);
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return ()=>{
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, [
        searchRef
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_drawer_CartDrawer__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_drawer_NotificationDrawer__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {}),
            modalOpen && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_modal_LoginModal__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                modalOpen: modalOpen,
                setModalOpen: setModalOpen
            }),
            modalOpenEnquiry && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_modal_ProductEnquiry__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z, {
                modalOpen: modalOpenEnquiry,
                setModalOpen: setModalOpenEnquiry
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "bg-gray-800 sticky top-0 z-20",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "max-w-screen-2xl mx-auto px-3 sm:px-10",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "top-bar h-16 lg:h-auto flex items-center justify-between py-4 mx-auto",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                    href: "/",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        className: "mr-3 lg:mr-12 xl:mr-12 hidden md:hidden lg:block",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            width: 50,
                                            height: 20,
                                            src: storeCustomizationSetting?.navbar?.header_logo || "/logo/Ecomedge.png",
                                            // /logo/Ecomedge.png
                                            alt: "logo"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "w-full transition-all duration-200 ease-in-out lg:flex lg:max-w-[520px] xl:max-w-[750px] 2xl:max-w-[900px] md:mx-12 lg:mx-4 xl:mx-0",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "w-full flex flex-col justify-center flex-shrink-0 relative z-30",
                                        ref: searchRef,
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex flex-col mx-auto w-full",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                                    onSubmit: handleSubmit,
                                                    className: "relative pr-12 md:pr-14 bg-white overflow-hidden shadow-sm rounded-md w-full",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                            className: "flex items-center py-0.5",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                onChange: handleSearchInput,
                                                                value: searchText,
                                                                className: "form-input w-full pl-5 appearance-none transition ease-in-out border text-input text-sm font-sans rounded-md min-h-10 h-10 duration-200 bg-white focus:ring-0 outline-none border-none focus:outline-none placeholder-gray-500 placeholder-opacity-75",
                                                                placeholder: "Search by products"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                            "aria-label": "Search",
                                                            type: "submit",
                                                            className: "outline-none text-xl text-gray-400 absolute top-0 right-0 end-0 w-12 md:w-14 h-full flex items-center justify-center transition duration-200 ease-in-out hover:text-heading focus:outline-none",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io5__WEBPACK_IMPORTED_MODULE_8__.IoSearchOutline, {})
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {})
                                                    ]
                                                }),
                                                showSearchData && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "absolute w-full top-10 px-[20px] py-[20px] left-0 bg-white rounded",
                                                    children: [
                                                        searchData && searchData.productsearchResult?.length > 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                                                    className: "text-slate-600 text-[13px]",
                                                                    children: "Products:"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {}),
                                                                searchData.productsearchResult.map((item, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                                        href: `/product/${item?.slug?.toLowerCase()}`,
                                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                            className: " flex gap-2 items-center m-1 py-1 px-3 text-[12px] text-gray-500 hover:text-[#189669] rounded bg-slate-100 cursor-pointer hover:bg-[#d1fae5]",
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                    src: item?.image[0]?.medialink,
                                                                                    alt: "product",
                                                                                    width: 25,
                                                                                    height: 25
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                                    children: item?.title
                                                                                })
                                                                            ]
                                                                        })
                                                                    }, i))
                                                            ]
                                                        }),
                                                        searchData && searchData.categorysearchResult?.length > 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                                    className: "text-slate-600 text-[13px]",
                                                                    children: "Categories:"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {}),
                                                                searchData.categorysearchResult.map((item, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                                        href: `/search?category=${item?.name}&_id=${item?._id}`,
                                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                            className: " flex gap-2 items-center m-1 py-1 px-3 text-[12px] text-gray-500 hover:text-[#189669] rounded bg-slate-100 cursor-pointer hover:bg-[#d1fae5]",
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                    src: item?.icon,
                                                                                    alt: "product",
                                                                                    width: 25,
                                                                                    height: 25
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                                    children: item.name
                                                                                })
                                                                            ]
                                                                        })
                                                                    }, i))
                                                            ]
                                                        }),
                                                        searchRes || /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "flex gap-2 items-center m-1 py-1 px-3 text-[12px] text-gray-500 rounded bg-slate-100 cursor-pointer",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                    children: "Do enquiry if product is not available "
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                    onClick: ()=>setModalOpenEnquiry(true),
                                                                    className: "py-1 px-3 rounded bg-gray-800 text-white",
                                                                    children: "Enquiry"
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "hidden md:hidden md:items-center lg:flex xl:block absolute inset-y-0 right-0 pr-2 sm:static sm:inset-auto sm:ml-6 sm:pr-0",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                            className: "relative pr-5 text-white text-2xl font-bold",
                                            "aria-label": "Alert",
                                            onClick: toggleNotificationDrawer,
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "absolute z-10 top-0 right-0 inline-flex items-center justify-center p-1 h-5 w-5 text-xs font-medium leading-none text-red-100 transform -translate-x-1/2 -translate-y-1/2 bg-red-500 rounded-full",
                                                    children: data?.notificationDetails?.length
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_9__.FiBell, {
                                                    className: "w-6 h-6 drop-shadow-xl"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                            "aria-label": "Total",
                                            onClick: toggleCartDrawer,
                                            className: "relative px-5 text-white text-2xl font-bold",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "absolute z-10 top-0 right-0 inline-flex items-center justify-center p-1 h-5 w-5 text-xs font-medium leading-none text-red-100 transform -translate-x-1/2 -translate-y-1/2 bg-red-500 rounded-full",
                                                    children: totalItems
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_9__.FiShoppingCart, {
                                                    className: "w-6 h-6 drop-shadow-xl"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            className: "pl-5 text-white text-2xl font-bold",
                                            "aria-label": "Login",
                                            children: imageUrl || userInfo?.image ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                href: "/user/dashboard",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                    className: "relative top-1 w-6 h-6",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                        width: 29,
                                                        height: 29,
                                                        src: imageUrl || userInfo?.image,
                                                        alt: "user",
                                                        className: "bg-white rounded-full"
                                                    })
                                                })
                                            }) : userInfo?.name ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                href: "/user/dashboard",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                    className: "leading-none font-bold font-serif block",
                                                    children: userInfo?.name[0]
                                                })
                                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                onClick: ()=>setModalOpen(!modalOpen),
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_9__.FiUser, {
                                                    className: "w-6 h-6 drop-shadow-xl"
                                                })
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_layout_navbar_NavbarPromo__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {})
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (next_dynamic__WEBPACK_IMPORTED_MODULE_5___default()(()=>Promise.resolve(Navbar), {
    ssr: false
}));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1000:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(543);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1185);
/* harmony import */ var _heroicons_react_outline__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8768);
/* harmony import */ var _heroicons_react_outline__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_heroicons_react_outline__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _services_SettingServices__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3644);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9915);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2750);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_icons_tb__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4152);
/* harmony import */ var react_icons_tb__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_icons_tb__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _utils_toast__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8548);
/* harmony import */ var _hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5538);
/* harmony import */ var _component_category_Category__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9800);
/* harmony import */ var _context_SidebarContext__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6812);
/* harmony import */ var _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(545);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_headlessui_react__WEBPACK_IMPORTED_MODULE_3__, _services_SettingServices__WEBPACK_IMPORTED_MODULE_5__, js_cookie__WEBPACK_IMPORTED_MODULE_6__, _hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_10__, _component_category_Category__WEBPACK_IMPORTED_MODULE_11__, _context_SidebarContext__WEBPACK_IMPORTED_MODULE_12__, _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_13__]);
([_headlessui_react__WEBPACK_IMPORTED_MODULE_3__, _services_SettingServices__WEBPACK_IMPORTED_MODULE_5__, js_cookie__WEBPACK_IMPORTED_MODULE_6__, _hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_10__, _component_category_Category__WEBPACK_IMPORTED_MODULE_11__, _context_SidebarContext__WEBPACK_IMPORTED_MODULE_12__, _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









//internal import





const NavbarPromo = ()=>{
    const { 0: languages , 1: setLanguages  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const { 0: currentLang , 1: setCurrentLang  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});
    const { lang , storeCustomizationSetting  } = (0,_hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)();
    const { isLoading , setIsLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_SidebarContext__WEBPACK_IMPORTED_MODULE_12__/* .SidebarContext */ .l);
    const { showingTranslateValue  } = (0,_hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z)();
    const handleLanguage = (lang)=>{
        setCurrentLang(lang);
        js_cookie__WEBPACK_IMPORTED_MODULE_6__["default"].set("_lang", lang?.iso_code, {
            sameSite: "None",
            secure: true
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        (async ()=>{
            {
                try {
                    const res = await _services_SettingServices__WEBPACK_IMPORTED_MODULE_5__/* ["default"].getShowingLanguage */ .Z.getShowingLanguage();
                    setLanguages(res);
                    const result = res?.find((language)=>language?.iso_code === lang);
                    setCurrentLang(result);
                } catch (err) {
                    (0,_utils_toast__WEBPACK_IMPORTED_MODULE_9__/* .notifyError */ .cB)(err);
                    console.log("error on getting lang", err);
                }
            }
        })();
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "hidden lg:block xl:block bg-white border-b",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "max-w-screen-2xl mx-auto px-3 sm:px-10 h-12 flex justify-between items-center",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "inline-flex",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_3__.Popover, {
                            className: "relative",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "max-w-7xl mx-auto",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "flex justify-between items-center md:justify-start md:space-x-10",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_headlessui_react__WEBPACK_IMPORTED_MODULE_3__.Popover.Group, {
                                        as: "nav",
                                        className: "md:flex space-x-10 items-center",
                                        children: [
                                            storeCustomizationSetting?.navbar?.categories_menu_status && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_headlessui_react__WEBPACK_IMPORTED_MODULE_3__.Popover, {
                                                className: "relative font-serif",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_headlessui_react__WEBPACK_IMPORTED_MODULE_3__.Popover.Button, {
                                                        className: "group inline-flex items-center py-2 hover:text-gray-600 focus:outline-none",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                className: "font-serif text-sm font-medium",
                                                                children: showingTranslateValue(storeCustomizationSetting?.navbar?.categories)
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_heroicons_react_outline__WEBPACK_IMPORTED_MODULE_4__.ChevronDownIcon, {
                                                                className: "ml-1 h-3 w-3 group-hover:text-gray-600",
                                                                "aria-hidden": "true"
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_3__.Transition, {
                                                        as: react__WEBPACK_IMPORTED_MODULE_1__.Fragment,
                                                        enter: "transition ease-out duration-200",
                                                        enterFrom: "opacity-0 translate-y-1",
                                                        enterTo: "opacity-100 translate-y-0",
                                                        leave: "transition ease-in duration-150",
                                                        leaveFrom: "opacity-100 translate-y-0",
                                                        leaveTo: "opacity-0 translate-y-1",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_3__.Popover.Panel, {
                                                            className: "absolute z-10 -ml-1 mt-1 transform w-screen max-w-xs c-h-65vh bg-white",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "rounded-md shadow-lg ring-1 ring-black ring-opacity-5 overflow-y-scroll flex-grow scrollbar-hide w-full h-full",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_category_Category__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {})
                                                            })
                                                        })
                                                    })
                                                ]
                                            }),
                                            storeCustomizationSetting?.navbar?.about_menu_status && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                href: "/about-us",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                    onClick: ()=>setIsLoading(!isLoading),
                                                    className: "font-serif mx-4 py-2 text-sm font-medium hover:text-gray-600",
                                                    children: showingTranslateValue(storeCustomizationSetting?.navbar?.about_us)
                                                })
                                            }),
                                            storeCustomizationSetting?.navbar?.contact_menu_status && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                href: "/contact-us",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                    onClick: ()=>setIsLoading(!isLoading),
                                                    className: "font-serif mx-4 py-2 text-sm font-medium hover:text-gray-600",
                                                    children: showingTranslateValue(storeCustomizationSetting?.navbar?.contact_us)
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_3__.Popover, {
                                                className: "relative font-serif",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_3__.Popover.Button, {
                                                    className: "group inline-flex items-center py-2 text-sm font-medium hover:text-gray-600 focus:outline-none",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "p-2 font-serif items-center rounded-md w-full hover:text-gray-600",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "w-full flex",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_tb__WEBPACK_IMPORTED_MODULE_8__.TbBrandGooglePodcasts, {
                                                                    className: "my-auto"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                                    href: "/catalog",
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                        // onClick={() => setIsLoading(!isLoading)}
                                                                        className: "relative inline-flex items-cente font-serif ml-2 py-0 rounded text-sm font-medium hover:text-gray-600",
                                                                        children: "Brand Catalog"
                                                                    })
                                                                })
                                                            ]
                                                        })
                                                    })
                                                })
                                            }),
                                            storeCustomizationSetting?.navbar?.offers_menu_status && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                href: "/offer",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                                    onClick: ()=>setIsLoading(!isLoading),
                                                    className: "relative inline-flex items-center bg-red-100 font-serif ml-4 py-0 px-2 rounded text-sm font-medium text-red-500 hover:text-gray-600",
                                                    children: [
                                                        showingTranslateValue(storeCustomizationSetting?.navbar?.offers),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "absolute flex w-2 h-2 left-auto -right-1 -top-1",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                    className: "animate-ping absolute inline-flex h-2 w-2 rounded-full bg-red-400 opacity-75"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                    className: "relative inline-flex rounded-full h-2 w-2 bg-red-500"
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                })
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex",
                        children: [
                            storeCustomizationSetting?.navbar?.privacy_policy_status && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                href: "/privacy-policy",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    onClick: ()=>setIsLoading(!isLoading),
                                    className: "font-serif mx-4 py-2 text-sm font-medium hover:text-gray-600",
                                    children: showingTranslateValue(storeCustomizationSetting?.navbar?.privacy_policy)
                                })
                            }),
                            storeCustomizationSetting?.navbar?.term_and_condition_status && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                href: "/terms-and-conditions",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    onClick: ()=>setIsLoading(!isLoading),
                                    className: "font-serif mx-4 py-2 text-sm font-medium hover:text-gray-600",
                                    children: showingTranslateValue(storeCustomizationSetting?.navbar?.term_and_condition)
                                })
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NavbarPromo);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5442:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _httpServices__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8272);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_httpServices__WEBPACK_IMPORTED_MODULE_0__]);
_httpServices__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const CategoryServices = {
    getShowingCategory: async ()=>{
        return _httpServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get("/category/show");
    },
    getBrandCatalog: async ()=>{
        return _httpServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get("/brandcatalog");
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CategoryServices);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4935:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _httpServices__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8272);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_httpServices__WEBPACK_IMPORTED_MODULE_0__]);
_httpServices__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const CouponServices = {
    getAllCoupons: async ()=>{
        return _httpServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get("/coupon");
    },
    getShowingCoupons: async ()=>{
        return _httpServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get("/coupon/show");
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CouponServices);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1086:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _httpServices__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8272);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_httpServices__WEBPACK_IMPORTED_MODULE_0__]);
_httpServices__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const EnquiryService = {
    getEnquiry: async ()=>{
        return _httpServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get("/enquiry");
    },
    PostEnquiry: async (body)=>{
        return _httpServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post("/enquiry", body);
    },
    getaskforprice: async ()=>{
        return _httpServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get("/askforprice");
    },
    Postaskforprice: async (body)=>{
        return _httpServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post("/askforprice", body);
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (EnquiryService);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6018:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _httpServices__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8272);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_httpServices__WEBPACK_IMPORTED_MODULE_0__]);
_httpServices__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const NotificationServices = {
    //store setting all function
    getAllNotification: async ()=>{
        return _httpServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get("notification/all");
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NotificationServices);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6139:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _httpServices__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8272);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_httpServices__WEBPACK_IMPORTED_MODULE_0__]);
_httpServices__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const OrderServices = {
    addOrder: async (body, headers)=>{
        return _httpServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post("/order/add", body, headers);
    },
    createPaymentIntent: async (body)=>{
        return _httpServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post("/order/create-payment-intent", body);
    },
    getOrderCustomer: async ({ page =1 , limit =8  })=>{
        return _httpServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/order?limit=${limit}&page=${page}`);
    },
    getOrderById: async (id, body)=>{
        return _httpServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/order/${id}`, body);
    },
    taxCredential: async (body)=>{
        return _httpServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post("/tax/taxaccordingstate", body);
    },
    getRequestForPrice: async ({ page =1 , limit =8  })=>{
        return _httpServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`askforprice?limit=${limit}&page=${page}`);
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (OrderServices);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2981:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _httpServices__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8272);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_httpServices__WEBPACK_IMPORTED_MODULE_0__]);
_httpServices__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const ProductServices = {
    getShowingProducts: async ()=>{
        return _httpServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get("/products/show");
    },
    getShowingStoreProducts: async ({ category ="" , title =""  })=>{
        return _httpServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/products/store?category=${category}&title=${title}`);
    },
    getSearchSuggestProducts: async ({ query =""  })=>{
        return _httpServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/homepage/search?searchQuery=${query}&limit=8&page=1`);
    },
    getDiscountedProducts: async ()=>{
        return _httpServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get("/products/discount");
    },
    getProductBySlug: async (slug)=>{
        return _httpServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/products/${slug}`);
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductServices);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2386:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "L1": () => (/* binding */ pages)
/* harmony export */ });
/* unused harmony exports userSidebar, sliderData, ctaCardData, featurePromo, contactData */
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2750);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_0__);

const pages = [
    // {
    //   title: 'User',
    //   href: '/user/dashboard',
    //   icon: FiUser,
    // },
    {
        title: "offer",
        href: "/offer",
        icon: react_icons_fi__WEBPACK_IMPORTED_MODULE_0__.FiGift
    },
    {
        title: "checkout",
        href: "/checkout",
        icon: react_icons_fi__WEBPACK_IMPORTED_MODULE_0__.FiShoppingBag
    },
    {
        title: "faq",
        href: "/faq",
        icon: react_icons_fi__WEBPACK_IMPORTED_MODULE_0__.FiHelpCircle
    },
    {
        title: "about us",
        href: "/about-us",
        icon: react_icons_fi__WEBPACK_IMPORTED_MODULE_0__.FiUsers
    },
    {
        title: "contact us",
        href: "/contact-us",
        icon: react_icons_fi__WEBPACK_IMPORTED_MODULE_0__.FiPhoneIncoming
    },
    {
        title: "privacy policy",
        href: "/privacy-policy",
        icon: react_icons_fi__WEBPACK_IMPORTED_MODULE_0__.FiPocket
    },
    {
        title: "terms and conditions",
        href: "/terms-and-conditions",
        icon: react_icons_fi__WEBPACK_IMPORTED_MODULE_0__.FiFileText
    },
    {
        title: "not found",
        href: "/404",
        icon: react_icons_fi__WEBPACK_IMPORTED_MODULE_0__.FiAlertCircle
    }, 
];
const userSidebar = [
    {
        title: "Dashboard",
        href: "/user/dashboard",
        icon: react_icons_fi__WEBPACK_IMPORTED_MODULE_0__.FiGrid
    },
    {
        title: "My Orders",
        href: "/user/my-orders",
        icon: react_icons_fi__WEBPACK_IMPORTED_MODULE_0__.FiList
    },
    {
        title: "Update Profile",
        href: "/user/update-profile",
        icon: react_icons_fi__WEBPACK_IMPORTED_MODULE_0__.FiSettings
    },
    {
        title: "Change Password",
        href: "/user/change-password",
        icon: react_icons_fi__WEBPACK_IMPORTED_MODULE_0__.FiFileText
    }, 
];
const sliderData = [
    {
        id: 1,
        title: "Slider1Title",
        info: "Slider1description",
        url: "/search?Category=biscuits--cakes",
        image: "/slider/slider-1.jpg"
    },
    {
        id: 2,
        title: "Slider2Title",
        info: "Slider2description",
        url: "/search?Category=fish--meat",
        image: "/slider/slider-2.jpg"
    },
    {
        id: 3,
        title: "Slider3Title",
        info: "Slider3description",
        url: "/search?category=fresh-vegetable",
        image: "/slider/slider-3.jpg"
    }, 
];
const ctaCardData = [
    {
        id: 1,
        title: "Taste of",
        subTitle: "Fresh & Natural",
        image: "/cta/cta-bg-1.jpg",
        url: "/search?category=fresh-vegetable"
    },
    {
        id: 2,
        title: "Taste of",
        subTitle: "Fish & Meat",
        image: "/cta/cta-bg-2.jpg",
        url: "/search?Category=fish--meat"
    },
    {
        id: 3,
        title: "Taste of",
        subTitle: "Bread & Bakery",
        image: "/cta/cta-bg-3.jpg",
        url: "/search?Category=biscuits--cakes"
    }, 
];
const featurePromo = [
    {
        id: 1,
        title: "featurePromo1-title",
        info: "featurePromo1-info",
        icon: react_icons_fi__WEBPACK_IMPORTED_MODULE_0__.FiTruck
    },
    {
        id: 2,
        title: "featurePromo2-title",
        info: "featurePromo2-info",
        icon: react_icons_fi__WEBPACK_IMPORTED_MODULE_0__.FiPhoneCall
    },
    {
        id: 3,
        title: "featurePromo3-title",
        info: "featurePromo3-info",
        icon: react_icons_fi__WEBPACK_IMPORTED_MODULE_0__.FiCreditCard
    },
    {
        id: 4,
        title: "featurePromo4-title",
        info: "featurePromo4-info",
        icon: react_icons_fi__WEBPACK_IMPORTED_MODULE_0__.FiGift
    }, 
];
const contactData = [
    {
        id: 1,
        title: "contact-page-box1-title",
        info: "contact-page-box1-info",
        icon: react_icons_fi__WEBPACK_IMPORTED_MODULE_0__.FiMail,
        contact: "TriDyota@gmail.com",
        className: "bg-gray-100"
    },
    {
        id: 2,
        title: "contact-page-box2-title",
        info: "contact-page-box2-info",
        icon: react_icons_fi__WEBPACK_IMPORTED_MODULE_0__.FiPhoneCall,
        contact: "029-00124667",
        className: "bg-yellow-100"
    },
    {
        id: 3,
        title: "contact-page-box3-title",
        info: "contact-page-box3-info",
        icon: react_icons_fi__WEBPACK_IMPORTED_MODULE_0__.FiMapPin,
        contact: "",
        className: "bg-indigo-100"
    }, 
];



/***/ })

};
;