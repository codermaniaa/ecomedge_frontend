"use strict";
exports.id = 596;
exports.ids = [596];
exports.modules = {

/***/ 3794:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(866);
/* harmony import */ var next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8027);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(543);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2750);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _component_common_Price__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7493);
/* harmony import */ var _component_common_Stock__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6616);
/* harmony import */ var _component_common_Tags__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(386);
/* harmony import */ var _utils_toast__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8548);
/* harmony import */ var _hooks_useAddToCart__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1353);
/* harmony import */ var _component_modal_MainModal__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1173);
/* harmony import */ var _component_common_Discount__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(6517);
/* harmony import */ var _component_variants_VariantList__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(2479);
/* harmony import */ var _context_SidebarContext__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(6812);
/* harmony import */ var _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(545);
/* harmony import */ var react_use_cart__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(9878);
/* harmony import */ var react_use_cart__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(react_use_cart__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var react_ui__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(7090);
/* harmony import */ var react_ui__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(react_ui__WEBPACK_IMPORTED_MODULE_18__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_component_common_Price__WEBPACK_IMPORTED_MODULE_7__, _component_modal_MainModal__WEBPACK_IMPORTED_MODULE_12__, _component_common_Discount__WEBPACK_IMPORTED_MODULE_13__, _component_variants_VariantList__WEBPACK_IMPORTED_MODULE_14__, _context_SidebarContext__WEBPACK_IMPORTED_MODULE_15__, _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_16__]);
([_component_common_Price__WEBPACK_IMPORTED_MODULE_7__, _component_modal_MainModal__WEBPACK_IMPORTED_MODULE_12__, _component_common_Discount__WEBPACK_IMPORTED_MODULE_13__, _component_variants_VariantList__WEBPACK_IMPORTED_MODULE_14__, _context_SidebarContext__WEBPACK_IMPORTED_MODULE_15__, _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_16__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







//internal import












const ProductModal = ({ modalOpen , setModalOpen , product , attributes , currency ,  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const { setIsLoading , isLoading , askForPriceProduct , useAskForPriceProduct  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useContext)(_context_SidebarContext__WEBPACK_IMPORTED_MODULE_15__/* .SidebarContext */ .l);
    const { t  } = next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_1___default()("ns1");
    const { items , addItem , updateItemQuantity , inCart  } = (0,react_use_cart__WEBPACK_IMPORTED_MODULE_17__.useCart)();
    const { handleIncreaseQuantity  } = (0,_hooks_useAddToCart__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z)();
    const { handleAddItem , setItem , item  } = (0,_hooks_useAddToCart__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z)();
    const { lang , showingTranslateValue , getNumber , getNumberTwo  } = (0,_hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z)();
    // react hook
    const { 0: value , 1: setValue  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)("");
    const { 0: price , 1: setPrice  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(0);
    const { 0: img , 1: setImg  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)("");
    const { 0: originalPrice , 1: setOriginalPrice  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(0);
    const { 0: stock , 1: setStock  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(0);
    const { 0: discount , 1: setDiscount  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(0);
    const { 0: selectVariant , 1: setSelectVariant  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)({});
    const { 0: selectVa , 1: setSelectVa  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)({});
    const { 0: variantTitle , 1: setVariantTitle  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)([]);
    const { 0: variants , 1: setVariants  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)([]);
    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
        if (item == 1) {
            setItem(product?.minimumOrderOfQuantity);
        }
        if (value) {
            const result = product?.variants?.filter((variant)=>Object.keys(selectVa).every((k)=>selectVa[k] === variant[k]));
            const res = result?.map(({ originalPrice , price , discount , quantity , barcode , sku , productId , image , ...rest })=>({
                    ...rest
                }));
            const filterKey = Object.keys(Object.assign({}, ...res));
            const selectVar = filterKey?.reduce((obj, key)=>({
                    ...obj,
                    [key]: selectVariant[key]
                }), {});
            const newObj = Object.entries(selectVar).reduce((a, [k, v])=>v ? (a[k] = v, a) : a, {});
            const result2 = result?.find((v)=>Object.keys(newObj).every((k)=>newObj[k] === v[k]));
            if (result.length <= 0 || result2 === undefined) return setStock(0);
            setVariants(result);
            setSelectVariant(result2);
            setSelectVa(result2);
            setImg(result2?.image);
            setStock(result2?.quantity);
        } else if (product?.variants?.length > 0) {
            const result1 = product?.variants?.filter((variant)=>Object.keys(selectVa).every((k)=>selectVa[k] === variant[k]));
            setVariants(result1);
            setStock(product.variants[0]?.quantity);
            setSelectVariant(product.variants[0]);
            setSelectVa(product.variants[0]);
            setImg(product.variants[0]?.image);
            const price = getNumber(product.variants[0]?.price);
            const originalPrice = getNumber(product.variants[0]?.originalPrice);
            const discountPercentage = getNumber((originalPrice - price) / originalPrice * 100);
            setDiscount(getNumber(discountPercentage));
            setPrice(price);
            setOriginalPrice(originalPrice);
        } else {
            setStock(product?.stock);
            setImg(product?.image[0]);
            const price1 = getNumber(product?.prices?.price);
            const originalPrice1 = getNumber(product?.prices?.originalPrice);
            const discountPercentage1 = getNumber((originalPrice1 - price1) / originalPrice1 * 100);
            setDiscount(getNumber(discountPercentage1));
            setPrice(price1);
            setOriginalPrice(originalPrice1);
        }
    }, [
        product?.prices?.discount,
        product?.prices?.originalPrice,
        product?.prices?.price,
        product?.stock,
        product.variants,
        selectVa,
        selectVariant,
        value, 
    ]);
    //  discount part
    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
        const price = getNumber(product?.prices?.price);
        const originalPrice = getNumber(product?.prices?.salePrice);
        const discountPercentage = getNumber((price - originalPrice) / price * 100);
        setDiscount(discountPercentage);
    }, [
        product?.prices?.price,
        product?.prices?.salePrice
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
        const res = Object.keys(Object.assign({}, ...product?.variants));
        const varTitle = attributes?.filter((att)=>res.includes(att?._id));
        setVariantTitle(varTitle?.sort());
    }, [
        variants,
        attributes
    ]);
    const handleAddToCart = (p)=>{
        console.log("handleAddToCart", p);
        if (p.variants.length === 1 && p.variants[0].quantity < 1) {
            return (0,_utils_toast__WEBPACK_IMPORTED_MODULE_10__/* .notifyError */ .cB)("Insufficient stock");
        }
        if (stock !== null && stock <= 0) {
            return (0,_utils_toast__WEBPACK_IMPORTED_MODULE_10__/* .notifyError */ .cB)("Insufficient stock");
        }
        if (product?.variants.map((variant)=>Object.entries(variant).sort().toString() === Object.entries(selectVariant).sort().toString())) {
            const { variants , categories , description , ...updatedProduct } = product;
            const newItem = {
                ...updatedProduct,
                id: `${p?.variants.length <= 0 ? p._id : p._id + "-" + variantTitle?.map((att)=>selectVariant[att._id]).join("-")}`,
                title: `${p?.variants.length <= 0 ? p.title : p.title + "-" + variantTitle?.map((att)=>att.variants?.find((v)=>v._id === selectVariant[att._id])).map((el)=>el?.name)}`,
                image: p?.image[0]?.medialink,
                variant: selectVariant || {},
                price: p.variants.length === 0 ? getNumber(p.prices.price) : getNumber(price),
                originalPrice: p.variants.length === 0 ? getNumber(p.prices.originalPrice) : getNumber(originalPrice),
                tax: p?.tax
            };
            addItem(newItem, item);
        } else {
            return (0,_utils_toast__WEBPACK_IMPORTED_MODULE_10__/* .notifyError */ .cB)("Please select all variants first!");
        }
    };
    const handleMoreInfo = (slug)=>{
        setModalOpen(false);
        router.push(`/product/${slug}`);
        setIsLoading(!isLoading);
    };
    const category_name = product?.category?.name?.toLowerCase()?.replace(/[^A-Z0-9]+/gi, "-");
    const varr = variantTitle.length > 0 ? 1 : product?.minimumOrderOfQuantity;
    // description
    const { 0: showFullDescription , 1: setShowFullDescription  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(false);
    const toggleDescription = ()=>{
        setShowFullDescription(!showFullDescription);
    };
    const renderDescription = ()=>{
        if (!product?.description) return null;
        if (!showFullDescription) {
            const words = product?.description.split(" ");
            if (words.length > 20) {
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: [
                        words.slice(0, 20).join(" "),
                        "...",
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: "text-blue-500 ml-2",
                            onClick: toggleDescription,
                            children: "More"
                        })
                    ]
                });
            }
        }
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                product?.description,
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                    className: "text-blue-500 ml-2",
                    onClick: toggleDescription,
                    children: "Less"
                })
            ]
        });
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_modal_MainModal__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
            modalOpen: modalOpen,
            setModalOpen: setModalOpen,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "inline-block overflow-y-auto h-full align-middle transition-all transform bg-white shadow-xl rounded-2xl",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex flex-col lg:flex-row md:flex-row w-full max-w-4xl overflow-hidden",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                            href: `/product/${product.slug}`,
                            passHref: true,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                onClick: ()=>setModalOpen(false),
                                className: "flex-shrink-0 flex items-center justify-center h-auto cursor-pointer",
                                children: [
                                    product?.prices?.salePrice > 1 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: "absolute text-dark text-sm bg-orange-500 text-white py-1 px-2 rounded font-medium z-10 left-4 top-4",
                                        children: [
                                            discount,
                                            "% off"
                                        ]
                                    }) : "",
                                    product.image[0] ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: product.image[0].medialink,
                                        width: 420,
                                        height: 420,
                                        alt: "product"
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: "https://res.cloudinary.com/ahossain/image/upload/v1655097002/placeholder_kvepfp.png",
                                        width: 420,
                                        height: 420,
                                        alt: "product Image"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: " flex flex-col p-5 md:p-8 w-full text-left",
                            style: {
                                maxWidth: "500px"
                            },
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "mb-2 md:mb-2.5 block -mt-1.5",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                            href: `/product/${product.slug}`,
                                            passHref: true,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                onClick: ()=>setModalOpen(false),
                                                className: "text-heading w-full text-lg md:text-xl lg:text-2xl font-semibold font-serif hover:text-black cursor-pointer",
                                                children: product?.title
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: `${stock <= 0 ? "relative py-1 mb-2" : "relative"}`,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_common_Stock__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                product: product,
                                                stock: stock
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "text-sm leading-6 text-gray-500 md:leading-6",
                                    children: renderDescription()
                                }),
                                product?.askForPrice === true ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                        href: `/askforprice?id=${product._id}`,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            onClick: ()=>useAskForPriceProduct(product),
                                            className: "w-full bg-gray-800 rounded h-7 text-white text-[12px] cursor-pointer hover:bg-gray-600 ",
                                            children: "Ask for price"
                                        })
                                    })
                                }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "flex items-center my-4",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_common_Price__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                product: product,
                                                currency: currency,
                                                price: product?.isCombination ? product?.variants[0]?.price : product?.prices?.price,
                                                originalPrice: product?.isCombination ? product?.variants[0]?.originalPrice : product?.prices?.salePrice
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: " flex justify-between gap-1",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "mb-1",
                                                    children: variantTitle?.map((a, i)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                            children: [
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h4", {
                                                                    className: "text-sm py-1 font-serif text-gray-700 font-bold",
                                                                    children: [
                                                                        a?.name,
                                                                        ":"
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: "flex flex-row mb-3",
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_variants_VariantList__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                                                                        att: a._id,
                                                                        lang: lang,
                                                                        option: a.option,
                                                                        setValue: setValue,
                                                                        varTitle: variantTitle,
                                                                        variants: product?.variants,
                                                                        setSelectVa: setSelectVa,
                                                                        selectVariant: selectVariant,
                                                                        setSelectVariant: setSelectVariant
                                                                    })
                                                                })
                                                            ]
                                                        }, a._id))
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: " flex gap-2 flex-wrap text-gray-500",
                                                    children: product?.moqSlab.map((item, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                        className: "text-[12px]",
                                                                        children: item.name
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                        className: "w-24 bg-[#D9D9D9] rounded flex flex-col p-1 ",
                                                                        children: [
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                className: "text-[12px]",
                                                                                children: [
                                                                                    item.minQuantity,
                                                                                    "-",
                                                                                    item.maxQuantity
                                                                                ]
                                                                            }),
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                className: "text-end text-[11px]",
                                                                                children: [
                                                                                    "₹ ",
                                                                                    item.moqSalePrice,
                                                                                    "/unit"
                                                                                ]
                                                                            })
                                                                        ]
                                                                    })
                                                                ]
                                                            }, i)
                                                        }))
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "flex items-center mt-4",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "flex items-center justify-between space-s-3 sm:space-s-4 w-full",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "group flex items-center justify-between rounded-md overflow-hidden flex-shrink-0 border h-11 md:h-12 border-gray-300",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                onClick: ()=>setItem(item - 1),
                                                                disabled: item === varr,
                                                                className: "flex items-center justify-center flex-shrink-0 h-full transition ease-in-out duration-300 focus:outline-none w-8 md:w-12 text-heading border-e border-gray-300 hover:text-gray-500",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                    className: "text-dark text-base",
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_6__.FiMinus, {})
                                                                })
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                className: "font-semibold flex items-center justify-center h-full transition-colors duration-250 ease-in-out cursor-default flex-shrink-0 text-base text-heading w-8 md:w-20 xl:w-24",
                                                                children: item
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                onClick: ()=>setItem(item + 1),
                                                                disabled: product.quantity < item || product.quantity === item,
                                                                className: "flex items-center justify-center h-full flex-shrink-0 transition ease-in-out duration-300 focus:outline-none w-8 md:w-12 text-heading border-s border-gray-300 hover:text-gray-500",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                    className: "text-dark text-base",
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_6__.FiPlus, {})
                                                                })
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                        onClick: ()=>handleAddToCart(product),
                                                        disabled: product.quantity < 1,
                                                        className: "text-sm leading-4 inline-flex items-center cursor-pointer transition ease-in-out duration-300 font-semibold font-serif text-center justify-center border-0 border-transparent rounded-md focus-visible:outline-none focus:outline-none text-white px-4 ml-4 md:px-6 lg:px-8 py-4 md:py-3.5 lg:py-4 hover:text-white bg-gray-800 hover:bg-gray-600 w-full h-12",
                                                        children: t("common:addToCart")
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "flex items-center mt-4",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex items-center justify-between space-s-3 sm:space-s-4 w-full",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                        className: "font-serif font-semibold py-1 text-sm d-block",
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                className: "text-gray-700",
                                                                children: [
                                                                    " ",
                                                                    t("common:category"),
                                                                    ":"
                                                                ]
                                                            }),
                                                            " ",
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                                href: `/search?category=${category_name}&_id=${product?.category?._id}`,
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                    type: "button",
                                                                    className: "text-gray-600 font-serif font-medium underline ml-2 hover:text-teal-600",
                                                                    onClick: ()=>setIsLoading(!isLoading),
                                                                    children: category_name
                                                                })
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_common_Tags__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        product: product
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    onClick: (e)=>handleMoreInfo(product.slug, e),
                                                    className: "font-sans font-medium text-sm text-orange-500",
                                                    children: t("common:moreInfo")
                                                })
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductModal);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1743:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3521);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8027);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_use_cart__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9878);
/* harmony import */ var react_use_cart__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_use_cart__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _component_common_Price__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7493);
/* harmony import */ var _component_common_Stock__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6616);
/* harmony import */ var _utils_toast__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8548);
/* harmony import */ var _hooks_useAddToCart__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1353);
/* harmony import */ var _component_common_Discount__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6517);
/* harmony import */ var _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(545);
/* harmony import */ var _component_modal_ProductModal__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(3794);
/* harmony import */ var _hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5538);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(543);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _context_SidebarContext__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(6812);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(9989);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(react_icons_io5__WEBPACK_IMPORTED_MODULE_15__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_component_common_Price__WEBPACK_IMPORTED_MODULE_5__, _component_common_Discount__WEBPACK_IMPORTED_MODULE_9__, _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_10__, _component_modal_ProductModal__WEBPACK_IMPORTED_MODULE_11__, _hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_12__, _context_SidebarContext__WEBPACK_IMPORTED_MODULE_14__]);
([_component_common_Price__WEBPACK_IMPORTED_MODULE_5__, _component_common_Discount__WEBPACK_IMPORTED_MODULE_9__, _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_10__, _component_modal_ProductModal__WEBPACK_IMPORTED_MODULE_11__, _hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_12__, _context_SidebarContext__WEBPACK_IMPORTED_MODULE_14__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





//internal import












const ProductCard = ({ product , attributes  })=>{
    const { 0: modalOpen , 1: setModalOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const { askForPriceProduct , useAskForPriceProduct  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useContext)(_context_SidebarContext__WEBPACK_IMPORTED_MODULE_14__/* .SidebarContext */ .l);
    const { items , addItem , updateItemQuantity , inCart  } = (0,react_use_cart__WEBPACK_IMPORTED_MODULE_4__.useCart)();
    const { handleIncreaseQuantity  } = (0,_hooks_useAddToCart__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
    const { globalSetting  } = (0,_hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z)();
    const { showingTranslateValue , getNumber  } = (0,_hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)();
    const currency = globalSetting?.default_currency || "₹";
    const { 0: discount , 1: setDiscount  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)();
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        const price = getNumber(product?.prices?.price);
        const originalPrice = getNumber(product?.prices?.salePrice);
        const discountPercentage = getNumber((price - originalPrice) / price * 100);
        setDiscount(discountPercentage);
    }, [
        product?.prices?.price,
        product?.prices?.salePrice
    ]);
    const handleAddItem = (p)=>{
        if (p.stock === 0) return (0,_utils_toast__WEBPACK_IMPORTED_MODULE_7__/* .notifyError */ .cB)("Insufficient stock!");
        // if (p?.variants?.length > 0) {
        //   setModalOpen(!modalOpen);
        //   return;
        // }
        console.log("handleAddItem", p);
        const { slug , variants , categories , description , ...updatedProduct } = product;
        const newItem = {
            ...updatedProduct,
            // title: showingTranslateValue(p?.title),
            id: p._id ? p._id : p.productId,
            variant: p.prices,
            price: p.prices.price,
            originalPrice: product.prices?.originalPrice,
            image: p.image[0]?.medialink,
            slug: p.slug
        };
        addItem(newItem);
    };
    const handleModalOpen = (event, id)=>{
        setModalOpen(event);
    };
    console.log("ProductCard..", product);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            modalOpen && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_modal_ProductModal__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                modalOpen: modalOpen,
                setModalOpen: setModalOpen,
                product: product,
                currency: currency,
                attributes: attributes
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "group box-border overflow-hidden flex rounded-md shadow-sm pe-0 flex-col items-center bg-white ",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        onClick: ()=>handleModalOpen(!modalOpen, product._id),
                        className: " flex flex-col justify-center w-full cursor-pointer",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "left-3",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_common_Stock__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                    product: product,
                                    stock: product.stock,
                                    card: true
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex justify-end",
                                children: product?.prices?.salePrice > 1 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                    className: " text-dark text-xs bg-orange-500 text-white py-1 px-2 rounded font-medium right-0 top-0",
                                    children: [
                                        discount,
                                        "% off"
                                    ]
                                }) : ""
                            }),
                            product?.image[0] ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                src: product.image[0].medialink,
                                style: {
                                    Width: "210px",
                                    height: "210px"
                                },
                                alt: "product"
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                src: "https://res.cloudinary.com/ahossain/image/upload/v1655097002/placeholder_kvepfp.png",
                                width: 210,
                                height: 210,
                                alt: "product"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("dev", {
                        className: "left-8"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full px-3 lg:px-4 pb-4 overflow-hidden ",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: " mb-1",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                    className: "text-heading truncate mb-0 block text-sm font-medium text-gray-600",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "line-clamp-2",
                                        children: product?.title
                                    })
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex justify-between items-center text-heading text-sm sm:text-base space-s-2 md:text-base lg:text-xl",
                                children: [
                                    product?.askForPrice === true ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_13___default()), {
                                        href: `/askforprice?id=${product._id}`,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            onClick: ()=>useAskForPriceProduct(product),
                                            className: "w-full bg-gray-800 rounded h-7 text-white text-[12px] cursor-pointer hover:bg-gray-600 ",
                                            children: "Ask for price"
                                        })
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_common_Price__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                        card: true,
                                        product: product,
                                        currency: currency,
                                        price: product?.isCombination ? product?.variants[0]?.price : product?.prices?.price,
                                        originalPrice: product?.isCombination ? product?.variants[0]?.originalPrice : product?.prices?.salePrice
                                    }),
                                    inCart(product._id) ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        children: [
                                            items.map((item)=>item.id === product._id && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    style: {
                                                        width: "max-content"
                                                    },
                                                    className: "h-9 w-auto flex flex-wrap items-center justify-evenly py-1 px-2 bg-gray-800 text-white rounded ",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                            onClick: ()=>updateItemQuantity(item.id, item.quantity - 1),
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                className: "text-dark text-base",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io5__WEBPACK_IMPORTED_MODULE_15__.IoRemove, {})
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            className: "text-sm text-dark px-1 font-serif font-semibold",
                                                            children: item.quantity
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                            onClick: ()=>item?.variants?.length > 0 ? handleAddItem(item) : handleIncreaseQuantity(item),
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                className: "text-dark text-base",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io5__WEBPACK_IMPORTED_MODULE_15__.IoAdd, {})
                                                            })
                                                        })
                                                    ]
                                                }, item.id)),
                                            " "
                                        ]
                                    }) : product?.askForPrice === true ? "" : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                        onClick: ()=>handleAddItem(product),
                                        "aria-label": "cart",
                                        className: "h-9 w-9 flex items-center justify-center border border-gray-200 rounded text-gray-800 hover:border-gray-800 hover:bg-gray-800 hover:text-white transition-all",
                                        children: [
                                            " ",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-xl",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io5__WEBPACK_IMPORTED_MODULE_15__.IoBagAddSharp, {
                                                    className: "gray-800"
                                                })
                                            }),
                                            " "
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (next_dynamic__WEBPACK_IMPORTED_MODULE_1___default()(()=>Promise.resolve(ProductCard), {
    ssr: false
}));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7576:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _httpServices__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8272);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_httpServices__WEBPACK_IMPORTED_MODULE_0__]);
_httpServices__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const AttributeServices = {
    getAllAttributes: async ()=>{
        return _httpServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get("/attributes");
    },
    getShowingAttributes: async ()=>{
        return _httpServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/attributes/show`);
    },
    addAttribute: async (body)=>{
        return _httpServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post("/attributes/add", body);
    },
    addAllAttributes: async (body)=>{
        return _httpServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post("/attributes/add/all", body);
    },
    getAttributeById: async (id)=>{
        return _httpServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/attributes/${id}`);
    },
    updateAttributes: async (id, body)=>{
        return _httpServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"].put */ .Z.put(`/attributes/${id}`, body);
    },
    updateStatus: async (id, body)=>{
        return _httpServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"].put */ .Z.put(`/attributes/status/${id}`, body);
    },
    deleteAttribute: async (id, body)=>{
        return _httpServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"]["delete"] */ .Z["delete"](`/attributes/${id}`, body);
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AttributeServices);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;