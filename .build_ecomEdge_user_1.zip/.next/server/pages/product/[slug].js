"use strict";
(() => {
var exports = {};
exports.id = 915;
exports.ids = [915];
exports.modules = {

/***/ 9472:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3521);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8027);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9989);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_io5__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_responsive_carousel__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4508);
/* harmony import */ var react_responsive_carousel__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_responsive_carousel__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3877);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3015);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swiper__WEBPACK_IMPORTED_MODULE_6__, swiper_react__WEBPACK_IMPORTED_MODULE_7__]);
([swiper__WEBPACK_IMPORTED_MODULE_6__, swiper_react__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












const ImageCarousel = ({ images , handleChangeImage , prevRef , nextRef  })=>{
    const { 0: currentIndex , 1: setCurrentIndex  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(0);
    const renderThumbs = ()=>{
        // Render thumbnails for the first four images only
        return images.slice(0, 4).map((img, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                onClick: ()=>handleChangeImage(img),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    className: "border inline-flex items-center justify-center px-3 py-1 mt-2",
                    src: img.medialink,
                    alt: "product",
                    width: 85,
                    height: 85
                })
            }, i + 1));
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_responsive_carousel__WEBPACK_IMPORTED_MODULE_5__.Carousel, {
            showArrows: true,
            showThumbs: true,
            renderThumbs: renderThumbs,
            width: 400,
            height: 400,
            children: images.slice(0, 4).map((img, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        src: img.medialink,
                        alt: "product"
                    })
                }, index))
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (next_dynamic__WEBPACK_IMPORTED_MODULE_1___default()(()=>Promise.resolve(ImageCarousel), {
    ssr: false
}));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7208:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2750);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5538);
/* harmony import */ var _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(545);
/* harmony import */ var react_icons_tb__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4152);
/* harmony import */ var react_icons_tb__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_icons_tb__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_3__, _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_4__]);
([_hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_3__, _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



//internal import



const Card = ({ product  })=>{
    const { storeCustomizationSetting  } = (0,_hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)();
    const { showingTranslateValue  } = (0,_hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)();
    // console.log("product?.warrantyPeriods?.duration", product);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
        className: "my-0",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                className: "flex items-center py-3",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "text-xl text-gray-400 items-start mr-4",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_2__.FiShieldOff, {})
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "font-sans leading-5 text-sm text-gray-500",
                        children: product?.warrantyPeriods?.duration == 0 ? showingTranslateValue(storeCustomizationSetting?.slug?.card_description_five) : `${product?.warrantyPeriods?.duration} years Warranty available for this item`
                    })
                ]
            }),
            product?.productSpecification?.returnPolicy?.isReturnable && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                className: "flex items-center py-3",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "text-xl text-gray-400 items-start mr-4",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_tb__WEBPACK_IMPORTED_MODULE_5__.TbTruckReturn, {})
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "font-sans leading-5 text-sm text-gray-500",
                        children: product?.productSpecification?.returnPolicy?.isReturnable == true ? `${product?.productSpecification?.returnPolicy?.returnDays} Day's Return available for this item` : ""
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Card);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7890:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _next_translate_root_i18n__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(608);
/* harmony import */ var next_translate_loadNamespaces__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7462);
/* harmony import */ var next_translate_loadNamespaces__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_translate_loadNamespaces__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(866);
/* harmony import */ var next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8027);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(543);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_icons_fa6__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8514);
/* harmony import */ var react_icons_fa6__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_icons_fa6__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2750);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react_share__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6158);
/* harmony import */ var react_share__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_share__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _component_common_Price__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7493);
/* harmony import */ var _component_common_Stock__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6616);
/* harmony import */ var _component_common_Tags__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(386);
/* harmony import */ var _layout_Layout__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(1286);
/* harmony import */ var _utils_toast__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(8548);
/* harmony import */ var _component_slug_card_Card__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(7208);
/* harmony import */ var _hooks_useAddToCart__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(1353);
/* harmony import */ var _component_preloader_Loading__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(8906);
/* harmony import */ var _component_product_ProductCard__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(1743);
/* harmony import */ var _component_variants_VariantList__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(2479);
/* harmony import */ var _context_SidebarContext__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(6812);
/* harmony import */ var _services_AttributeServices__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(7576);
/* harmony import */ var _services_ProductServices__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(2981);
/* harmony import */ var _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(545);
/* harmony import */ var _component_common_Discount__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(6517);
/* harmony import */ var _component_carousel_ImageCarousel__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(9472);
/* harmony import */ var _hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(5538);
/* harmony import */ var react_use_cart__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(9878);
/* harmony import */ var react_use_cart__WEBPACK_IMPORTED_MODULE_28___default = /*#__PURE__*/__webpack_require__.n(react_use_cart__WEBPACK_IMPORTED_MODULE_28__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_component_common_Price__WEBPACK_IMPORTED_MODULE_11__, _layout_Layout__WEBPACK_IMPORTED_MODULE_14__, _component_slug_card_Card__WEBPACK_IMPORTED_MODULE_16__, _component_product_ProductCard__WEBPACK_IMPORTED_MODULE_19__, _component_variants_VariantList__WEBPACK_IMPORTED_MODULE_20__, _context_SidebarContext__WEBPACK_IMPORTED_MODULE_21__, _services_AttributeServices__WEBPACK_IMPORTED_MODULE_22__, _services_ProductServices__WEBPACK_IMPORTED_MODULE_23__, _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_24__, _component_common_Discount__WEBPACK_IMPORTED_MODULE_25__, _component_carousel_ImageCarousel__WEBPACK_IMPORTED_MODULE_26__, _hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_27__]);
([_component_common_Price__WEBPACK_IMPORTED_MODULE_11__, _layout_Layout__WEBPACK_IMPORTED_MODULE_14__, _component_slug_card_Card__WEBPACK_IMPORTED_MODULE_16__, _component_product_ProductCard__WEBPACK_IMPORTED_MODULE_19__, _component_variants_VariantList__WEBPACK_IMPORTED_MODULE_20__, _context_SidebarContext__WEBPACK_IMPORTED_MODULE_21__, _services_AttributeServices__WEBPACK_IMPORTED_MODULE_22__, _services_ProductServices__WEBPACK_IMPORTED_MODULE_23__, _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_24__, _component_common_Discount__WEBPACK_IMPORTED_MODULE_25__, _component_carousel_ImageCarousel__WEBPACK_IMPORTED_MODULE_26__, _hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_27__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











//internal import


















const ProductScreen = ({ product , attributes , relatedProduct  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_7__.useRouter)();
    const prevRef = (0,react__WEBPACK_IMPORTED_MODULE_8__.useRef)(null);
    const nextRef = (0,react__WEBPACK_IMPORTED_MODULE_8__.useRef)(null);
    const { globalSetting  } = (0,_hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_27__/* ["default"] */ .Z)();
    const { lang , showingTranslateValue , getNumber  } = (0,_hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_24__/* ["default"] */ .Z)();
    const currency = globalSetting?.default_currency || "₹";
    const { isLoading , setIsLoading , askForPriceProduct , useAskForPriceProduct  } = (0,react__WEBPACK_IMPORTED_MODULE_8__.useContext)(_context_SidebarContext__WEBPACK_IMPORTED_MODULE_21__/* .SidebarContext */ .l);
    const { handleAddItem , item , setItem , handleIncreaseQuantity  } = (0,_hooks_useAddToCart__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z)();
    const { items , addItem , updateItemQuantity , inCart  } = (0,react_use_cart__WEBPACK_IMPORTED_MODULE_28__.useCart)();
    // react hook
    const { 0: value , 1: setValue  } = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)("");
    const { 0: price , 1: setPrice  } = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)(0);
    const { 0: img , 1: setImg  } = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)("");
    const { 0: originalPrice , 1: setOriginalPrice  } = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)(0);
    const { 0: stock , 1: setStock  } = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)(0);
    const { 0: discount , 1: setDiscount  } = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)(0);
    const { 0: selectVariant , 1: setSelectVariant  } = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)({});
    const { 0: isReadMore , 1: setIsReadMore  } = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)(true);
    const { 0: selectVa , 1: setSelectVa  } = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)({});
    const { 0: variantTitle , 1: setVariantTitle  } = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)([]);
    const { 0: variants , 1: setVariants  } = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)([]);
    const buttonClickOnUserManual = ()=>{
        const pdfUrl = product?.userManual[0].medialink;
        const link = document.createElement("a");
        link.href = pdfUrl;
        link.download = "document.pdf"; // specify the filename
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };
    const buttonClickOntechnicalSpecification = ()=>{
        const pdfUrl = product?.userManual[0].medialink;
        const link = document.createElement("a");
        link.href = pdfUrl;
        link.download = "document.pdf"; // specify the filename
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_8__.useEffect)(()=>{
        if (value) {
            const result = product?.variants?.filter((variant)=>Object.keys(selectVa).every((k)=>selectVa[k] === variant[k]));
            const res = result?.map(({ originalPrice , discount , quantity , inUse , inUseOrder , barcode , sku , productId , image , ...rest })=>({
                    ...rest
                }));
            const filterKey = Object.keys(Object.assign({}, ...res));
            const selectVar = filterKey?.reduce((obj, key)=>({
                    ...obj,
                    [key]: selectVariant[key]
                }), {});
            const newObj = Object.entries(selectVar).reduce((a, [k, v])=>v ? (a[k] = v, a) : a, {});
            const result2 = result?.find((v)=>Object.keys(newObj).every((k)=>newObj[k] === v[k]));
            if (result.length <= 0 || result2 === undefined) return setStock(0);
            setVariants(result);
            setSelectVariant(result2);
            setSelectVa(result2);
            setImg(result2?.image);
            setStock(result2?.quantity);
            const price = getNumber(result2?.price);
            const originalPrice = getNumber(result2?.originalPrice);
            const discountPercentage = getNumber((originalPrice - price) / originalPrice * 100);
            return setDiscount(getNumber(discountPercentage));
            return setPrice(price);
            return setOriginalPrice(originalPrice);
        } else if (product?.variants?.length > 0) {
            const result1 = product?.variants?.filter((variant)=>Object.keys(selectVa).every((k)=>selectVa[k] === variant[k]));
            setVariants(result1);
            setStock(product?.variants[0]?.quantity);
            setSelectVariant(product?.variants[0]);
            setSelectVa(product?.variants[0]);
            setImg(product?.variants[0]?.image);
            const price1 = getNumber(product?.variants[0]?.price);
            const originalPrice1 = getNumber(product?.variants[0]?.originalPrice);
            const discountPercentage1 = getNumber((originalPrice1 - price1) / originalPrice1 * 100);
            setDiscount(getNumber(discountPercentage1));
            setPrice(price1);
            setOriginalPrice(originalPrice1);
        } else {
            setStock(product?.stock);
            setImg(product?.image[0]);
            const price2 = getNumber(product?.prices?.price);
            const originalPrice2 = getNumber(product?.prices?.originalPrice);
            const discountPercentage2 = getNumber((originalPrice2 - price2) / originalPrice2 * 100);
            setDiscount(getNumber(discountPercentage2));
            setPrice(price2);
            setOriginalPrice(originalPrice2);
        }
    }, [
        product?.prices?.discount,
        product?.prices?.originalPrice,
        product?.prices?.price,
        product?.stock,
        product?.variants,
        selectVa,
        selectVariant,
        value, 
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_8__.useEffect)(()=>{
        const price = getNumber(product?.prices?.price);
        const originalPrice = getNumber(product?.prices?.salePrice);
        const discountPercentage = getNumber((price - originalPrice) / price * 100);
        setDiscount(discountPercentage);
    }, [
        product?.prices?.price,
        product?.prices?.salePrice
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_8__.useEffect)(()=>{
        const res = Object.keys(Object.assign({}, ...product?.variants));
        const varTitle = attributes?.filter((att)=>res.includes(att?._id));
        setVariantTitle(varTitle?.sort());
    }, [
        variants,
        attributes
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_8__.useEffect)(()=>{
        setIsLoading(false);
    }, [
        product
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_8__.useEffect)(()=>{
        if (item == 1) {
            setItem(product?.minimumOrderOfQuantity);
        }
    }, []);
    const handleAddToCart = (p)=>{
        if (p.variants.length === 1 && (p.variants[0].quantity === null || p.variants[0].quantity < 1)) return (0,_utils_toast__WEBPACK_IMPORTED_MODULE_15__/* .notifyError */ .cB)("Insufficient stock");
        if (stock !== null && stock <= 0) return (0,_utils_toast__WEBPACK_IMPORTED_MODULE_15__/* .notifyError */ .cB)("Insufficient stock");
        if (product?.variants.map((variant)=>Object.entries(variant).sort().toString() === Object.entries(selectVariant).sort().toString())) {
            const { variants , categories , description , ...updatedProduct } = product;
            const newItem = {
                ...updatedProduct,
                id: `${p.variants.length <= 1 ? p._id : p._id + variantTitle?.map((att)=>selectVariant[att._id]).join("-")}`,
                title: `${p.variants.length <= 1 ? product?.title : product?.title + "-" + variantTitle?.map((att)=>att.variants?.find((v)=>v._id === selectVariant[att._id])).map((el)=>el?.name)}`,
                image: img,
                variant: selectVariant,
                price: price,
                originalPrice: originalPrice
            };
            addItem(newItem, item);
        // handleIncreaseQuantity(newItem);
        } else {
            return (0,_utils_toast__WEBPACK_IMPORTED_MODULE_15__/* .notifyError */ .cB)("Please select all variant first!");
        }
    };
    const handleChangeImage = (img)=>{
        setImg(img);
    };
    const { t  } = next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_3___default()();
    // category name slug
    const category_name = product?.category?.name.toLowerCase().replace(/[^A-Z0-9]+/gi, "-");
    const varr = variantTitle.length > 0 ? 1 : product?.minimumOrderOfQuantity;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: isLoading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_preloader_Loading__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {
            loading: isLoading
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_layout_Layout__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
            title: showingTranslateValue(product?.title),
            description: showingTranslateValue(product?.description),
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "px-0 py-10 lg:py-10",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "mx-auto px-3 lg:px-10 max-w-screen-2xl",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "flex items-center pb-4",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ol", {
                                className: "flex items-center w-full overflow-hidden font-serif",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        className: "text-sm pr-1 transition duration-200 ease-in cursor-pointer hover:text-gray-500 font-semibold",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                                            href: "/",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                children: "Home"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                        className: "text-sm mt-[1px]",
                                        children: [
                                            " ",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_9__.FiChevronRight, {}),
                                            " "
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        className: "text-sm pl-1 transition duration-200 ease-in cursor-pointer hover:text-gray-500 font-semibold ",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                                            href: `/search?category=${category_name}&_id=${product?.category?._id}`,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                type: "button",
                                                onClick: ()=>setIsLoading(!isLoading),
                                                children: category_name
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                        className: "text-sm mt-[1px]",
                                        children: [
                                            " ",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_9__.FiChevronRight, {}),
                                            " "
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        className: "text-sm px-1 transition duration-200 ease-in ",
                                        children: showingTranslateValue(product?.title)
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-full rounded-lg p-3 lg:p-12 bg-white",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-col xl:flex-row",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex-shrink-0 xl:pr-10 lg:block w-full mx-auto md:w-6/12 lg:w-5/12 xl:w-4/12",
                                        children: [
                                            product?.prices?.salePrice > 1 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                className: "relative text-dark text-sm bg-orange-500 text-white py-1 px-2 rounded font-medium z-10 right-0 top-6",
                                                children: [
                                                    discount,
                                                    "% off"
                                                ]
                                            }) : "",
                                            product?.image?.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "flex flex-row flex-wrap mt-4 border-t",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_carousel_ImageCarousel__WEBPACK_IMPORTED_MODULE_26__/* ["default"] */ .Z, {
                                                    images: product?.image,
                                                    handleChangeImage: handleChangeImage,
                                                    prevRef: prevRef,
                                                    nextRef: nextRef
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "w-full",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex flex-col md:flex-row lg:flex-row xl:flex-row",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: " w-3/5 xl:pr-6 md:pr-6 md:w-2/3 mob-w-full",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "mb-6",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                                    className: "leading-7 text-lg md:text-xl lg:text-2xl mb-1 font-semibold font-serif text-gray-800",
                                                                    children: product?.title
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                    className: "uppercase font-serif font-medium text-gray-500 text-sm",
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                        className: "font-bold text-gray-600",
                                                                        children: product?.sku
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: "relative",
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_common_Stock__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                                        product: product,
                                                                        stock: stock
                                                                    })
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                                            onClick: buttonClickOnUserManual,
                                                            className: "bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold text-sm mr-4 mb-3 mt-3 py-2 px-4 rounded inline-flex items-center",
                                                            children: [
                                                                t("User Manual   "),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa6__WEBPACK_IMPORTED_MODULE_6__.FaFileArrowDown, {
                                                                    size: "32px",
                                                                    color: "1E90FF"
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                                            onClick: buttonClickOntechnicalSpecification,
                                                            className: "bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold text-sm py-2 px-4 mb-3 rounded inline-flex items-center",
                                                            children: [
                                                                t("Technical Specification"),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa6__WEBPACK_IMPORTED_MODULE_6__.FaFileArrowDown, {
                                                                    size: "32px",
                                                                    color: "#1E90FF"
                                                                })
                                                            ]
                                                        }),
                                                        product?.askForPrice === true ? "" : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_common_Price__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                                                    product: product,
                                                                    currency: currency,
                                                                    price: product?.isCombination ? product?.variants[0]?.price : product?.prices?.price,
                                                                    originalPrice: product?.isCombination ? product?.variants[0]?.originalPrice : product?.prices?.salePrice
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: "font-serif product-price font-bold",
                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                        className: "inline-block text-lg font-semibold text-gray-800",
                                                                        children: [
                                                                            "GST :",
                                                                            ` `,
                                                                            currency,
                                                                            product?.prices?.salePrice * product?.tax[0]?.amount / 100
                                                                        ]
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                    className: " flex justify-between gap-1",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "mb-4",
                                                                            children: variantTitle?.map((a, i)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                                    children: [
                                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h4", {
                                                                                            className: "text-sm py-1",
                                                                                            children: [
                                                                                                a?.name,
                                                                                                ":"
                                                                                            ]
                                                                                        }),
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                            className: "flex flex-row mb-3",
                                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_variants_VariantList__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {
                                                                                                att: a._id,
                                                                                                lang: lang,
                                                                                                option: a.option,
                                                                                                setValue: setValue,
                                                                                                varTitle: variantTitle,
                                                                                                setSelectVa: setSelectVa,
                                                                                                variants: product?.variants,
                                                                                                selectVariant: selectVariant,
                                                                                                setSelectVariant: setSelectVariant
                                                                                            })
                                                                                        })
                                                                                    ]
                                                                                }, i + 1))
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: " flex gap-2 flex-wrap text-gray-500",
                                                                            children: product?.moqSlab.map((item, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                        children: [
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                                                className: "text-[12px]",
                                                                                                children: item.name
                                                                                            }),
                                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                                className: "w-24 bg-[#D9D9D9] rounded flex flex-col p-1 ",
                                                                                                children: [
                                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                                        className: "text-[12px]",
                                                                                                        children: [
                                                                                                            item.minQuantity,
                                                                                                            "-",
                                                                                                            item.maxQuantity
                                                                                                        ]
                                                                                                    }),
                                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                                        className: "text-end text-[11px]",
                                                                                                        children: [
                                                                                                            "₹ ",
                                                                                                            item.moqSalePrice,
                                                                                                            "/unit"
                                                                                                        ]
                                                                                                    })
                                                                                                ]
                                                                                            })
                                                                                        ]
                                                                                    }, i)
                                                                                }))
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            children: [
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                    className: "text-sm leading-6 text-gray-500 md:leading-7",
                                                                    children: [
                                                                        isReadMore ? product?.description?.slice(0, 230) : product?.description,
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                                        Object?.keys(product?.description)?.includes(lang) ? product?.description[lang]?.length > 230 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                            onClick: ()=>setIsReadMore(!isReadMore),
                                                                            className: "read-or-hide",
                                                                            children: isReadMore ? t("common:moreInfo") : t("common:showLess")
                                                                        }) : product?.description?.en?.length > 230 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                            onClick: ()=>setIsReadMore(!isReadMore),
                                                                            className: "read-or-hide",
                                                                            children: isReadMore ? t("common:moreInfo") : t("common:showLess")
                                                                        })
                                                                    ]
                                                                }),
                                                                product?.askForPrice === true ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                                                                        href: `/askforprice?id=${product?._id}`,
                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                            onClick: ()=>useAskForPriceProduct(product),
                                                                            className: "w-full bg-gray-800 rounded h-7 text-white text-[12px] cursor-pointer hover:bg-gray-600 ",
                                                                            children: "Ask for price"
                                                                        })
                                                                    })
                                                                }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "flex items-center mt-4",
                                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                className: "flex items-center justify-between space-s-3 sm:space-s-4 w-full",
                                                                                children: [
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                        className: "group flex items-center justify-between rounded-md overflow-hidden flex-shrink-0 border h-11 md:h-12 border-gray-300",
                                                                                        children: [
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                                                onClick: ()=>setItem(item - 1),
                                                                                                // disabled={item === varr}
                                                                                                className: "flex items-center justify-center flex-shrink-0 h-full transition ease-in-out duration-300 focus:outline-none w-8 md:w-12 text-heading border-e border-gray-300 hover:text-gray-500",
                                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                    className: "text-dark text-base",
                                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_9__.FiMinus, {})
                                                                                                })
                                                                                            }),
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                                                className: "font-semibold flex items-center justify-center h-full transition-colors duration-250 ease-in-out cursor-default flex-shrink-0 text-base text-heading w-8 md:w-20 xl:w-24",
                                                                                                children: item
                                                                                            }),
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                                                onClick: ()=>setItem(item + 1),
                                                                                                // disabled={selectVariant?.quantity <= item}
                                                                                                className: "flex items-center justify-center h-full flex-shrink-0 transition ease-in-out duration-300 focus:outline-none w-8 md:w-12 text-heading border-s border-gray-300 hover:text-gray-500",
                                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                    className: "text-dark text-base",
                                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_9__.FiPlus, {})
                                                                                                })
                                                                                            })
                                                                                        ]
                                                                                    }),
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                                        onClick: ()=>handleAddToCart(product),
                                                                                        className: "text-sm leading-4 inline-flex items-center cursor-pointer transition ease-in-out duration-300 font-semibold font-serif text-center justify-center border-0 border-transparent rounded-md focus-visible:outline-none focus:outline-none text-white px-4 ml-4 md:px-6 lg:px-8 py-4 md:py-3.5 lg:py-4 hover:text-white bg-gray-800 hover:bg-gray-600 w-full h-12",
                                                                                        children: t("common:addToCart")
                                                                                    })
                                                                                ]
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                            className: "flex flex-col mt-4",
                                                                            children: [
                                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                                    className: "font-serif font-semibold py-1 text-sm d-block",
                                                                                    children: [
                                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                                            className: "text-gray-800",
                                                                                            children: [
                                                                                                t("common:category"),
                                                                                                ":"
                                                                                            ]
                                                                                        }),
                                                                                        " ",
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                                                                                            href: `/search?category=${category_name}&_id=${product?.category?._id}`,
                                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                                                type: "button",
                                                                                                className: "text-gray-600 font-serif font-medium underline ml-2 hover:text-teal-600",
                                                                                                onClick: ()=>setIsLoading(!isLoading),
                                                                                                children: category_name
                                                                                            })
                                                                                        })
                                                                                    ]
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_common_Tags__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                                                                    product: product
                                                                                })
                                                                            ]
                                                                        })
                                                                    ]
                                                                }),
                                                                product?.productSpecification.productType && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("dev", {
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                                        className: " mt-10 mb-6 text-gray-600 text-base font-semibold mb-1 font-serif",
                                                                        children: t("Product Specifations")
                                                                    })
                                                                }),
                                                                product?.productSpecification && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("dev", {
                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                                                                        id: "customers",
                                                                        children: [
                                                                            product?.productSpecification?.productType && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                                children: [
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                        className: "mt-3",
                                                                                        children: "Product Type \xa0\xa0"
                                                                                    }),
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                        children: "\xa0\xa0 : \xa0\xa0"
                                                                                    }),
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                                                        className: "mt-10 text-sm font-semibold mb-1 font-serif",
                                                                                        children: [
                                                                                            "\xa0\xa0",
                                                                                            product?.productSpecification?.productType
                                                                                        ]
                                                                                    })
                                                                                ]
                                                                            }),
                                                                            product?.productSpecification?.productLine && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                                children: [
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                        className: "mt-3",
                                                                                        children: "Product Line \xa0\xa0"
                                                                                    }),
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                        children: "\xa0\xa0 : \xa0\xa0"
                                                                                    }),
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                                                        className: "mt-10 text-sm font-semibold mb-1 font-serif",
                                                                                        children: [
                                                                                            "\xa0\xa0",
                                                                                            product?.productSpecification?.productLine
                                                                                        ]
                                                                                    })
                                                                                ]
                                                                            }),
                                                                            product?.productSpecification?.brand && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                                children: [
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                        className: "mt-3",
                                                                                        children: "Brand \xa0\xa0"
                                                                                    }),
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                        children: "\xa0\xa0 : \xa0\xa0"
                                                                                    }),
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                                                        className: "mt-10 text-sm font-semibold mb-1 font-serif",
                                                                                        children: [
                                                                                            "\xa0\xa0",
                                                                                            product?.productSpecification?.brand
                                                                                        ]
                                                                                    })
                                                                                ]
                                                                            }),
                                                                            product?.productSpecification?.uom && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                                children: [
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                        className: "mt-3",
                                                                                        children: "UOM \xa0\xa0"
                                                                                    }),
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                        children: "\xa0\xa0 : \xa0\xa0"
                                                                                    }),
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                                                        className: "mt-10 text-sm font-semibold mb-1 font-serif",
                                                                                        children: [
                                                                                            "\xa0\xa0",
                                                                                            product?.productSpecification?.uom
                                                                                        ]
                                                                                    })
                                                                                ]
                                                                            }),
                                                                            product?.productSpecification?.originCountry && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                                children: [
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                        className: "mt-3",
                                                                                        children: "Country OF Origin \xa0\xa0"
                                                                                    }),
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                        children: "\xa0\xa0 : \xa0\xa0"
                                                                                    }),
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                                                        className: "mt-10 text-sm font-semibold mb-1 font-serif",
                                                                                        children: [
                                                                                            "\xa0\xa0",
                                                                                            product?.productSpecification?.originCountry
                                                                                        ]
                                                                                    })
                                                                                ]
                                                                            }),
                                                                            product?.productSpecification?.importerName && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                                children: [
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                        className: "mt-3",
                                                                                        children: "Manufacturer/Importer Name \xa0\xa0"
                                                                                    }),
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                        children: "\xa0\xa0 : \xa0\xa0"
                                                                                    }),
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                                                        className: "mt-10 text-sm font-semibold mb-1 font-serif",
                                                                                        children: [
                                                                                            "\xa0\xa0",
                                                                                            product?.productSpecification?.importerName
                                                                                        ]
                                                                                    })
                                                                                ]
                                                                            }),
                                                                            product?.productSpecification?.importerAddress && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                                children: [
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                        className: "mt-3",
                                                                                        children: "Manufacturer/Importer Address \xa0\xa0"
                                                                                    }),
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                        children: "\xa0\xa0 : \xa0\xa0"
                                                                                    }),
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                                                        className: "mt-10 text-sm font-semibold mb-1 font-serif",
                                                                                        children: [
                                                                                            "\xa0\xa0",
                                                                                            product?.productSpecification?.importerAddress
                                                                                        ]
                                                                                    })
                                                                                ]
                                                                            })
                                                                        ]
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                    className: "mt-8",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                                            className: "text-base font-semibold mb-1 font-serif",
                                                                            children: t("common:shareYourSocial")
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                            className: "font-sans text-sm text-gray-500",
                                                                            children: t("common:shareYourSocialText")
                                                                        }),
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                                                            className: "flex mt-4",
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                                    className: "flex items-center text-center border border-gray-100 rounded-full hover:bg-gray-800 mr-2 transition ease-in-out duration-500",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_10__.FacebookShareButton, {
                                                                                        url: `https://supermarket-plum.vercel.app/product/${router.query.slug}`,
                                                                                        quote: "",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_10__.FacebookIcon, {
                                                                                            size: 32,
                                                                                            round: true
                                                                                        })
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                                    className: "flex items-center text-center border border-gray-100 rounded-full hover:bg-gray-800 mr-2 transition ease-in-out duration-500",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_10__.TwitterShareButton, {
                                                                                        url: `https://supermarket-plum.vercel.app/product/${router.query.slug}`,
                                                                                        quote: "",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_10__.TwitterIcon, {
                                                                                            size: 32,
                                                                                            round: true
                                                                                        })
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                                    className: "flex items-center text-center border border-gray-100 rounded-full hover:bg-gray-800 mr-2 transition ease-in-out duration-500",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_10__.RedditShareButton, {
                                                                                        url: `https://supermarket-plum.vercel.app/product/${router.query.slug}`,
                                                                                        quote: "",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_10__.RedditIcon, {
                                                                                            size: 32,
                                                                                            round: true
                                                                                        })
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                                    className: "flex items-center text-center border border-gray-100 rounded-full hover:bg-gray-800 mr-2 transition ease-in-out duration-500",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_10__.WhatsappShareButton, {
                                                                                        url: `https://supermarket-plum.vercel.app/product/${router.query.slug}`,
                                                                                        quote: "",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_10__.WhatsappIcon, {
                                                                                            size: 32,
                                                                                            round: true
                                                                                        })
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                                    className: "flex items-center text-center border border-gray-100 rounded-full hover:bg-gray-800 mr-2 transition ease-in-out duration-500",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_10__.LinkedinShareButton, {
                                                                                        url: `https://supermarket-plum.vercel.app/product/${router.query.slug}`,
                                                                                        quote: "",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_10__.LinkedinIcon, {
                                                                                            size: 32,
                                                                                            round: true
                                                                                        })
                                                                                    })
                                                                                })
                                                                            ]
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "w-full xl:w-5/12 lg:w-6/12 md:w-5/12",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "mt-6 md:mt-0 lg:mt-0 bg-gray-50 border border-gray-100 p-4 lg:p-8 rounded-lg",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_slug_card_Card__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                                                            product: product
                                                        })
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        }),
                        relatedProduct?.length >= 2 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "pt-10 lg:pt-20 lg:pb-10",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                    className: "leading-7 text-lg lg:text-xl mb-3 font-semibold font-serif hover:text-gray-600",
                                    children: t("common:relatedProducts")
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "flex",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "w-full",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 xl:grid-cols-5 2xl:grid-cols-6 gap-2 md:gap-3 lg:gap-3"
                                        })
                                    })
                                })
                            ]
                        })
                    ]
                })
            })
        })
    });
};
// you can use getServerSideProps alternative for getStaticProps and getStaticPaths
const _getServerSideProps = async (context)=>{
    const { slug  } = context.params;
    const [data, attributes] = await Promise.all([
        _services_ProductServices__WEBPACK_IMPORTED_MODULE_23__/* ["default"].getShowingStoreProducts */ .Z.getShowingStoreProducts({
            category: "",
            slug: slug
        }),
        _services_AttributeServices__WEBPACK_IMPORTED_MODULE_22__/* ["default"].getShowingAttributes */ .Z.getShowingAttributes({}), 
    ]);
    let product = {};
    if (slug) {
        product = data?.products?.find((p)=>p.slug === slug);
    }
    return {
        props: {
            product,
            relatedProduct: data?.relatedProduct,
            attributes
        }
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductScreen);
async function getServerSideProps(ctx) {
    let res = _getServerSideProps(ctx);
    if (typeof res.then === "function") res = await res;
    return {
        ...res,
        props: {
            ...res.props || {},
            ...await next_translate_loadNamespaces__WEBPACK_IMPORTED_MODULE_2___default()({
                ...ctx,
                pathname: "/product/[slug]",
                loaderName: "getServerSideProps",
                ..._next_translate_root_i18n__WEBPACK_IMPORTED_MODULE_1__,
                loadLocaleFrom: (l, n)=>__webpack_require__(7655)(`./${l}/${n}`).then((m)=>m.default)
            })
        }
    };
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8768:
/***/ ((module) => {

module.exports = require("@heroicons/react/outline");

/***/ }),

/***/ 6999:
/***/ ((module) => {

module.exports = require("@react-oauth/google");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 4515:
/***/ ((module) => {

module.exports = require("@stripe/react-stripe-js");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 1635:
/***/ ((module) => {

module.exports = require("dayjs");

/***/ }),

/***/ 7462:
/***/ ((module) => {

module.exports = require("next-translate/loadNamespaces");

/***/ }),

/***/ 866:
/***/ ((module) => {

module.exports = require("next-translate/useTranslation");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 5832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 5307:
/***/ ((module) => {

module.exports = require("rc-drawer");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6358:
/***/ ((module) => {

module.exports = require("react-dropzone");

/***/ }),

/***/ 8514:
/***/ ((module) => {

module.exports = require("react-icons/fa6");

/***/ }),

/***/ 2750:
/***/ ((module) => {

module.exports = require("react-icons/fi");

/***/ }),

/***/ 924:
/***/ ((module) => {

module.exports = require("react-icons/im");

/***/ }),

/***/ 9989:
/***/ ((module) => {

module.exports = require("react-icons/io5");

/***/ }),

/***/ 4152:
/***/ ((module) => {

module.exports = require("react-icons/tb");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 4508:
/***/ ((module) => {

module.exports = require("react-responsive-carousel");

/***/ }),

/***/ 6158:
/***/ ((module) => {

module.exports = require("react-share");

/***/ }),

/***/ 2633:
/***/ ((module) => {

module.exports = require("react-spinners/ScaleLoader");

/***/ }),

/***/ 1187:
/***/ ((module) => {

module.exports = require("react-toastify");

/***/ }),

/***/ 7090:
/***/ ((module) => {

module.exports = require("react-ui");

/***/ }),

/***/ 9878:
/***/ ((module) => {

module.exports = require("react-use-cart");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = import("@headlessui/react");;

/***/ }),

/***/ 2905:
/***/ ((module) => {

module.exports = import("html-react-parser");;

/***/ }),

/***/ 9915:
/***/ ((module) => {

module.exports = import("js-cookie");;

/***/ }),

/***/ 5641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ }),

/***/ 4275:
/***/ ((module) => {

module.exports = import("react-loading-skeleton");;

/***/ }),

/***/ 4612:
/***/ ((module) => {

module.exports = import("socket.io-client");;

/***/ }),

/***/ 3877:
/***/ ((module) => {

module.exports = import("swiper");;

/***/ }),

/***/ 3015:
/***/ ((module) => {

module.exports = import("swiper/react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [678,138,378,399,408,812,354,440,8,286,596], () => (__webpack_exec__(7890)));
module.exports = __webpack_exports__;

})();