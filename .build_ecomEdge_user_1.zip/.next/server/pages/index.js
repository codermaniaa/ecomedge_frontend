"use strict";
(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 6543:
/***/ ((module, __unused_webpack___webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(543);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5538);
/* harmony import */ var _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(545);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_3__, _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_4__]);
([_hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_3__, _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



//internal import


const Banner = ()=>{
    const { storeCustomizationSetting  } = useGetSetting();
    const { showingTranslateValue  } = useUtilsFunction();
    return /*#__PURE__*/ _jsx(_Fragment, {
        children: /*#__PURE__*/ _jsxs("div", {
            className: "flex justify-between items-center",
            children: [
                /*#__PURE__*/ _jsxs("div", {
                    children: [
                        /*#__PURE__*/ _jsxs("h1", {
                            className: "font-serif text-xl",
                            children: [
                                /*#__PURE__*/ _jsx("span", {
                                    className: "text-gray-600 font-bold",
                                    children: showingTranslateValue(storeCustomizationSetting?.home?.promotion_title)
                                }),
                                " "
                            ]
                        }),
                        /*#__PURE__*/ _jsx("p", {
                            className: "text-gray-500",
                            children: showingTranslateValue(storeCustomizationSetting?.home?.promotion_description)
                        })
                    ]
                }),
                /*#__PURE__*/ _jsx(Link, {
                    href: `${storeCustomizationSetting?.home?.promotion_button_link}`,
                    children: /*#__PURE__*/ _jsx("a", {
                        className: "text-sm font-serif font-medium px-6 py-2 bg-gray-800 text-center rounded-full text-white hover:bg-gray-700",
                        children: showingTranslateValue(storeCustomizationSetting?.home?.promotion_button_name)
                    })
                })
            ]
        })
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (Banner)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4333:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(543);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8027);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3015);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3877);
/* harmony import */ var _hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5538);
/* harmony import */ var _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(545);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swiper_react__WEBPACK_IMPORTED_MODULE_4__, swiper__WEBPACK_IMPORTED_MODULE_5__, _hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_6__, _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_7__]);
([swiper_react__WEBPACK_IMPORTED_MODULE_4__, swiper__WEBPACK_IMPORTED_MODULE_5__, _hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_6__, _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









//internal import


const MainCarousel = ()=>{
    const { storeCustomizationSetting , bannerData , getDetails  } = (0,_hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)();
    const { showingTranslateValue , showingUrl , showingImage  } = (0,_hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        getDetails();
    }, []);
    const sliderData = [
        {
            id: 1,
            title: showingTranslateValue(storeCustomizationSetting?.slider?.first_title),
            info: showingTranslateValue(storeCustomizationSetting?.slider?.first_description),
            buttonName: showingTranslateValue(storeCustomizationSetting?.slider?.first_button),
            url: showingUrl(storeCustomizationSetting?.slider?.first_link),
            image: showingImage(storeCustomizationSetting?.slider?.first_img) || "/slider/slider-1.jpg"
        },
        {
            id: 2,
            title: showingTranslateValue(storeCustomizationSetting?.slider?.second_title),
            info: showingTranslateValue(storeCustomizationSetting?.slider?.second_description),
            buttonName: showingTranslateValue(storeCustomizationSetting?.slider?.second_button),
            url: showingUrl(storeCustomizationSetting?.slider?.second_link),
            image: showingImage(storeCustomizationSetting?.slider?.second_img) || "/slider/slider-2.jpg"
        },
        {
            id: 3,
            title: showingTranslateValue(storeCustomizationSetting?.slider?.third_title),
            info: showingTranslateValue(storeCustomizationSetting?.slider?.third_description),
            buttonName: showingTranslateValue(storeCustomizationSetting?.slider?.third_button),
            url: showingUrl(storeCustomizationSetting?.slider?.third_link),
            image: showingImage(storeCustomizationSetting?.slider?.third_img) || "/slider/slider-3.jpg"
        },
        {
            id: 4,
            title: showingTranslateValue(storeCustomizationSetting?.slider?.four_title),
            info: showingTranslateValue(storeCustomizationSetting?.slider?.four_description),
            buttonName: showingTranslateValue(storeCustomizationSetting?.slider?.four_button),
            url: showingUrl(storeCustomizationSetting?.slider?.four_link),
            image: showingImage(storeCustomizationSetting?.slider?.four_img) || "/slider/slider-1.jpg"
        },
        {
            id: 5,
            title: showingTranslateValue(storeCustomizationSetting?.slider?.five_title),
            info: showingTranslateValue(storeCustomizationSetting?.slider?.five_description),
            buttonName: showingTranslateValue(storeCustomizationSetting?.slider?.five_button),
            url: showingUrl(storeCustomizationSetting?.slider?.five_link),
            image: showingImage(storeCustomizationSetting?.slider?.five_img) || "/slider/slider-2.jpg"
        }, 
    ];
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_4__.Swiper, {
            spaceBetween: 30,
            centeredSlides: true,
            autoplay: {
                delay: 2000,
                disableOnInteraction: false
            },
            loop: true,
            pagination: (storeCustomizationSetting?.slider?.bottom_dots || storeCustomizationSetting?.slider?.both_slider) && {
                clickable: true
            },
            navigation: (storeCustomizationSetting?.slider?.left_right_arrow || storeCustomizationSetting?.slider?.both_slider) && {
                clickable: true
            },
            modules: [
                swiper__WEBPACK_IMPORTED_MODULE_5__.Autoplay,
                swiper__WEBPACK_IMPORTED_MODULE_5__.Pagination,
                swiper__WEBPACK_IMPORTED_MODULE_5__.Navigation
            ],
            className: "mySwiper",
            children: bannerData && bannerData?.map((item, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("dev", {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(swiper_react__WEBPACK_IMPORTED_MODULE_4__.SwiperSlide, {
                        className: "h-full relative rounded-lg overflow-hidden",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "text-sm text-gray-600 w-full h-full hover:text-gray-dark",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    layout: "responsive",
                                    src: item?.image,
                                    alt: item?.heading,
                                    className: "w-full max-h-[500px] object-cover"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "absolute top-0 left-0 z-10 p-r-16 flex-col flex w-full h-full place-items-start justify-center",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "pl-4 pr-12 sm:pl-10 sm:pr-16 w-10/12 lg:w-8/12 xl:w-7/12",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                            className: "mb-2 font-serif text-xl sm:text-lg md:text-2xl line-clamp-1 md:line-clamp-none lg:line-clamp-none lg:text-3xl font-bold text-gray-800",
                                            children: item?.heading
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "text-base leading-6 text-gray-600 font-sans line-clamp-1 md:line-clamp-none lg:line-clamp-none",
                                            children: item?.description.split("-").join(" ")
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            href: item?.image,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                className: "hidden sm:inline-block lg:inline-block text-sm leading-6 font-serif font-medium mt-6 px-6 py-2 bg-gray-800 text-center rounded-md text-white hover:bg-gray-600",
                                                children: item?.ctaText.split("-").join(" ")
                                            })
                                        })
                                    ]
                                })
                            })
                        ]
                    }, i + 1)
                }))
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(MainCarousel));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 285:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(543);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8027);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3015);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3877);
/* harmony import */ var _hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5538);
/* harmony import */ var _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(545);
/* harmony import */ var _component_cta_card_CartThree__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7557);
/* harmony import */ var _services_SettingServices__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3644);
/* harmony import */ var _utils_toast__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8548);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swiper_react__WEBPACK_IMPORTED_MODULE_4__, swiper__WEBPACK_IMPORTED_MODULE_5__, _hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_6__, _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_7__, _component_cta_card_CartThree__WEBPACK_IMPORTED_MODULE_8__, _services_SettingServices__WEBPACK_IMPORTED_MODULE_9__]);
([swiper_react__WEBPACK_IMPORTED_MODULE_4__, swiper__WEBPACK_IMPORTED_MODULE_5__, _hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_6__, _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_7__, _component_cta_card_CartThree__WEBPACK_IMPORTED_MODULE_8__, _services_SettingServices__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









//internal import






const PromotionalBannerCarousel = ()=>{
    const { 0: bannerData , 1: setBannerData  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([
        1,
        2,
        3,
        4
    ]);
    const getDetails = ()=>{
        _services_SettingServices__WEBPACK_IMPORTED_MODULE_9__/* ["default"].getPromotionBanner */ .Z.getPromotionBanner().then((res)=>{
            if (res?.success === true) {
                // notifySuccess(res?.message);
                setBannerData(res?.PromotionDetailsdData);
            // setHomePage(res?.Pagination);
            // setOneTimeCallApi(true);
            } else {
                (0,_utils_toast__WEBPACK_IMPORTED_MODULE_10__/* .notifyError */ .cB)(res?.message);
            // setOneTimeCallApi(true);
            }
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        getDetails();
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "block mx-auto max-w-screen-2xl",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "mx-auto max-w-screen-2xl px-4 sm:px-10",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "lg:p-16 p-6 bg-gray-800 shadow-sm border rounded-lg",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full bg-white shadow-sm lg:px-10 lg:py-5 p-6 rounded-lg",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex flex-col lg:flex-row justify-between items-center",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "lg:w-3/5 mb-6 lg:mb-0",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                            className: "font-serif text-lg lg:text-2xl font-bold mb-1",
                                            children: "Quick Delivery to Your Home"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "text-sm font-sans leading-6",
                                            children: "There are many products you will find in our shop, Choose your daily necessary product from our EcommEdge shop and get some special offers. See Our latest discounted products from here and get a special discount."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "w-full lg:w-1/4 flex-grow hidden md:flex lg:justify-end",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_4__.Swiper, {
                                        spaceBetween: 30,
                                        centeredSlides: true,
                                        autoplay: {
                                            delay: 2000,
                                            disableOnInteraction: false
                                        },
                                        loop: true,
                                        pagination:  true && {
                                            clickable: true
                                        },
                                        // navigation={
                                        //   true && {
                                        //     clickable: true,
                                        //   }
                                        // }
                                        modules: [
                                            swiper__WEBPACK_IMPORTED_MODULE_5__.Autoplay,
                                            swiper__WEBPACK_IMPORTED_MODULE_5__.Pagination,
                                            swiper__WEBPACK_IMPORTED_MODULE_5__.Navigation
                                        ],
                                        className: "mySwiper",
                                        children: bannerData && bannerData?.map((item, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_4__.SwiperSlide, {
                                                className: "h-full relative rounded-lg overflow-hidden",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "block mx-auto max-w-screen-2xl",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "mx-auto max-w-screen-2xl px-4 sm:px-10",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_cta_card_CartThree__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                            item: item
                                                        })
                                                    })
                                                })
                                            }, i + 1))
                                    })
                                })
                            ]
                        })
                    })
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(PromotionalBannerCarousel));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7593:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3521);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9989);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_io5__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_use_cart__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9878);
/* harmony import */ var react_use_cart__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_use_cart__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _context_SidebarContext__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6812);
/* harmony import */ var _hooks_useAsync__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9338);
/* harmony import */ var _services_SettingServices__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3644);
/* harmony import */ var _hooks_useCheckoutSubmit__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7284);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_context_SidebarContext__WEBPACK_IMPORTED_MODULE_5__, _services_SettingServices__WEBPACK_IMPORTED_MODULE_7__, _hooks_useCheckoutSubmit__WEBPACK_IMPORTED_MODULE_8__]);
([_context_SidebarContext__WEBPACK_IMPORTED_MODULE_5__, _services_SettingServices__WEBPACK_IMPORTED_MODULE_7__, _hooks_useCheckoutSubmit__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





//internal import




const StickyCart = ()=>{
    const { totalItems , cartTotal  } = (0,react_use_cart__WEBPACK_IMPORTED_MODULE_4__.useCart)();
    const { toggleCartDrawer  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(_context_SidebarContext__WEBPACK_IMPORTED_MODULE_5__/* .SidebarContext */ .l);
    const { data: globalSetting  } = (0,_hooks_useAsync__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)(_services_SettingServices__WEBPACK_IMPORTED_MODULE_7__/* ["default"].getGlobalSetting */ .Z.getGlobalSetting);
    const { total  } = (0,_hooks_useCheckoutSubmit__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
    const currency = globalSetting?.default_currency || "₹";
    const { 0: isVisible , 1: setIsVisible  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(true);
    let scrollTimeout;
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        const handleScroll = ()=>{
            setIsVisible(false);
            // Clear the previous timeout if scrolling continues
            clearTimeout(scrollTimeout);
            // Set a timeout to show the component after scrolling stops
            scrollTimeout = setTimeout(()=>{
                setIsVisible(true);
            }, 200); // Adjust the timeout duration as needed
        };
        // Add the scroll event listener
        window.addEventListener("scroll", handleScroll);
        // Clean up the event listener on component unmount
        return ()=>{
            window.removeEventListener("scroll", handleScroll);
            clearTimeout(scrollTimeout);
        };
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: `sticky-cart ${isVisible ? "visible" : "hidden"}`,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
            "aria-label": "Cart",
            onClick: toggleCartDrawer,
            className: "absolute",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "right-0 w-35 float-right fixed top-1/6 bottom-5/6 align-middle shadow-lg cursor-pointer z-30 hidden lg:block xl:block",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-col items-center justify-center bg-indigo-50 rounded-tl-lg p-2 text-gray-700",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "text-2xl m b-1 text-gray-800",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io5__WEBPACK_IMPORTED_MODULE_3__.IoBagHandleOutline, {})
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "px-2 text-sm font-serif font-medium",
                                children: [
                                    totalItems,
                                    " Items"
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-col items-center justify-center bg-gray-800 p-2 text-white text-base font-serif font-medium rounded-bl-lg mx-auto",
                        children: [
                            currency,
                            parseFloat(total).toFixed(2)
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (next_dynamic__WEBPACK_IMPORTED_MODULE_1___default()(()=>Promise.resolve(StickyCart), {
    ssr: false
}));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4103:
/***/ ((module, __unused_webpack___webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8027);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(543);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5538);
/* harmony import */ var _component_preloader_CMSkeleton__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2038);
/* harmony import */ var _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(545);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_4__, _component_preloader_CMSkeleton__WEBPACK_IMPORTED_MODULE_5__, _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_6__]);
([_hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_4__, _component_preloader_CMSkeleton__WEBPACK_IMPORTED_MODULE_5__, _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




//internal import



const CardTwo = ()=>{
    const { storeCustomizationSetting , error , loading  } = useGetSetting();
    const { showingTranslateValue  } = useUtilsFunction();
    return /*#__PURE__*/ _jsx(_Fragment, {
        children: /*#__PURE__*/ _jsx("div", {
            className: "w-full bg-white shadow-sm lg:px-10 lg:py-5 p-6 rounded-lg",
            children: /*#__PURE__*/ _jsxs("div", {
                className: "flex justify-between items-center",
                children: [
                    /*#__PURE__*/ _jsxs("div", {
                        className: "lg:w-3/5",
                        children: [
                            /*#__PURE__*/ _jsx("span", {
                                className: "text-base lg:text-lg",
                                children: /*#__PURE__*/ _jsx(CMSkeleton, {
                                    count: 1,
                                    height: 20,
                                    error: error,
                                    loading: loading,
                                    data: storeCustomizationSetting?.home?.quick_delivery_subtitle
                                })
                            }),
                            /*#__PURE__*/ _jsx("h2", {
                                className: "font-serif text-lg lg:text-2xl font-bold mb-1",
                                children: /*#__PURE__*/ _jsx(CMSkeleton, {
                                    count: 1,
                                    height: 30,
                                    error: error,
                                    loading: loading,
                                    data: storeCustomizationSetting?.home?.quick_delivery_title
                                })
                            }),
                            /*#__PURE__*/ _jsx("p", {
                                className: "text-sm font-sans leading-6",
                                children: /*#__PURE__*/ _jsx(CMSkeleton, {
                                    count: 4,
                                    height: 20,
                                    error: error,
                                    loading: loading,
                                    data: storeCustomizationSetting?.home?.quick_delivery_description
                                })
                            }),
                            /*#__PURE__*/ _jsx(Link, {
                                href: `${storeCustomizationSetting?.home?.quick_delivery_link}`,
                                children: /*#__PURE__*/ _jsx("a", {
                                    className: "lg:w-1/3 text-xs font-serif font-medium inline-block mt-5 px-8 py-3 bg-gray-800 text-center text-white rounded-full hover:text-white contact-btn",
                                    target: "_blank",
                                    children: showingTranslateValue(storeCustomizationSetting?.home?.quick_delivery_button)
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ _jsx("div", {
                        className: "w-1/5 flex-grow hidden lg:flex md:flex md:justify-items-center lg:justify-end",
                        children: /*#__PURE__*/ _jsx("img", {
                            width: 373,
                            height: 250,
                            alt: "Quick Delivery to Your Home",
                            className: "block w-auto object-contain",
                            src: storeCustomizationSetting?.home?.quick_delivery_img || "/cta/delivery-boy.png"
                        })
                    })
                ]
            })
        })
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (CardTwo)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7557:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8027);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(543);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5538);
/* harmony import */ var _component_preloader_CMSkeleton__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2038);
/* harmony import */ var _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(545);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_4__, _component_preloader_CMSkeleton__WEBPACK_IMPORTED_MODULE_5__, _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_6__]);
([_hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_4__, _component_preloader_CMSkeleton__WEBPACK_IMPORTED_MODULE_5__, _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




//internal import



const CartThree = ({ item  })=>{
    const { storeCustomizationSetting , error , loading  } = (0,_hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)();
    const { showingTranslateValue  } = (0,_hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)();
    console.log("item..for carosal", item);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "w-full bg-white rounded-lg",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex-grow hidden lg:flex md:flex md:justify-items-center lg:justify-center",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    alt: "Quick Delivery to Your Home",
                    loading: "lazy",
                    width: "250",
                    height: "250",
                    decoding: "async",
                    src: item?.image
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CartThree);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9706:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _component_coupon_Coupon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7106);
/* harmony import */ var _hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5538);
/* harmony import */ var _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(545);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_component_coupon_Coupon__WEBPACK_IMPORTED_MODULE_2__, _hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_3__, _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_4__]);
([_component_coupon_Coupon__WEBPACK_IMPORTED_MODULE_2__, _hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_3__, _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


//internal import



const OfferCard = ()=>{
    const { storeCustomizationSetting  } = (0,_hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)();
    const { showingTranslateValue  } = (0,_hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-full group",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "bg-gray-50 h-full border-2 transition duration-150 ease-linear transform rounded shadow",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "bg-orange-100 text-gray-900 px-6 py-0 rounded-t border-b flex items-center justify-center",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "homepage-section-title",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: "text-base font-serif font-medium ",
                            children: showingTranslateValue(storeCustomizationSetting?.home?.discount_title)
                        })
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "overflow-hidden",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_coupon_Coupon__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        couponInHome: true
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (OfferCard);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4875:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _next_translate_root_i18n__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(608);
/* harmony import */ var next_translate_loadNamespaces__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7462);
/* harmony import */ var next_translate_loadNamespaces__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_translate_loadNamespaces__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _context_SidebarContext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6812);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(866);
/* harmony import */ var next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _hooks_useAsync__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9338);
/* harmony import */ var _services_CouponServices__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4935);
/* harmony import */ var _layout_Layout__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1286);
/* harmony import */ var _component_banner_Banner__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6543);
/* harmony import */ var _hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5538);
/* harmony import */ var _component_cta_card_CardTwo__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(4103);
/* harmony import */ var _component_offer_OfferCard__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9706);
/* harmony import */ var _component_cart_StickyCart__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(7593);
/* harmony import */ var _component_preloader_Loading__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(8906);
/* harmony import */ var _services_ProductServices__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(2981);
/* harmony import */ var _component_product_ProductCard__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(1743);
/* harmony import */ var _component_carousel_MainCarousel__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(4333);
/* harmony import */ var _component_category_FeatureCategory__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(1334);
/* harmony import */ var _services_AttributeServices__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(7576);
/* harmony import */ var _component_preloader_CMSkeleton__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(2038);
/* harmony import */ var _component_carousel_PromotionalBannerCarousel__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(285);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_context_SidebarContext__WEBPACK_IMPORTED_MODULE_3__, _services_CouponServices__WEBPACK_IMPORTED_MODULE_8__, _layout_Layout__WEBPACK_IMPORTED_MODULE_9__, _component_banner_Banner__WEBPACK_IMPORTED_MODULE_10__, _hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_11__, _component_cta_card_CardTwo__WEBPACK_IMPORTED_MODULE_12__, _component_offer_OfferCard__WEBPACK_IMPORTED_MODULE_13__, _component_cart_StickyCart__WEBPACK_IMPORTED_MODULE_14__, _services_ProductServices__WEBPACK_IMPORTED_MODULE_16__, _component_product_ProductCard__WEBPACK_IMPORTED_MODULE_17__, _component_carousel_MainCarousel__WEBPACK_IMPORTED_MODULE_18__, _component_category_FeatureCategory__WEBPACK_IMPORTED_MODULE_19__, _services_AttributeServices__WEBPACK_IMPORTED_MODULE_20__, _component_preloader_CMSkeleton__WEBPACK_IMPORTED_MODULE_21__, _component_carousel_PromotionalBannerCarousel__WEBPACK_IMPORTED_MODULE_22__]);
([_context_SidebarContext__WEBPACK_IMPORTED_MODULE_3__, _services_CouponServices__WEBPACK_IMPORTED_MODULE_8__, _layout_Layout__WEBPACK_IMPORTED_MODULE_9__, _component_banner_Banner__WEBPACK_IMPORTED_MODULE_10__, _hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_11__, _component_cta_card_CardTwo__WEBPACK_IMPORTED_MODULE_12__, _component_offer_OfferCard__WEBPACK_IMPORTED_MODULE_13__, _component_cart_StickyCart__WEBPACK_IMPORTED_MODULE_14__, _services_ProductServices__WEBPACK_IMPORTED_MODULE_16__, _component_product_ProductCard__WEBPACK_IMPORTED_MODULE_17__, _component_carousel_MainCarousel__WEBPACK_IMPORTED_MODULE_18__, _component_category_FeatureCategory__WEBPACK_IMPORTED_MODULE_19__, _services_AttributeServices__WEBPACK_IMPORTED_MODULE_20__, _component_preloader_CMSkeleton__WEBPACK_IMPORTED_MODULE_21__, _component_carousel_PromotionalBannerCarousel__WEBPACK_IMPORTED_MODULE_22__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







//internal import
















// import image from "/lineart.png"
const Home = ({ popularProducts , discountProducts , fetureproduct , attributes ,  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter)();
    const { isLoading , setIsLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useContext)(_context_SidebarContext__WEBPACK_IMPORTED_MODULE_3__/* .SidebarContext */ .l);
    const { loading , error , storeCustomizationSetting  } = (0,_hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z)();
    const { data  } = (0,_hooks_useAsync__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)(_services_CouponServices__WEBPACK_IMPORTED_MODULE_8__/* ["default"].getShowingCoupons */ .Z.getShowingCoupons);
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        if (router.asPath === "/") {
            setIsLoading(false);
        } else {
            setIsLoading(false);
        }
    }, [
        router
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: isLoading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_preloader_Loading__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
            loading: isLoading
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_layout_Layout__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "min-h-screen",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_cart_StickyCart__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "bg-white",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "mx-auto py-4 w-full",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex w-full",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: `flex-shrink-0 xl:pr-0 lg:block w-full`,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_carousel_MainCarousel__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {})
                                })
                            })
                        })
                    }),
                    data?.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full hidden lg:flex",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_offer_OfferCard__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {})
                    }),
                    storeCustomizationSetting?.home?.featured_status && // <div className="bg-gray-100 lg:py-16 py-10">
                    //   <div className="mx-auto max-w-screen-2xl px-3 sm:px-10">
                    //     <div className="mb-10 flex justify-center">
                    //       <div className="text-center w-full lg:w-2/5">
                    //         <h2 className="text-xl lg:text-2xl mb-2 font-serif font-semibold">
                    //           <CMSkeleton
                    //             count={1}
                    //             height={30}
                    //             // error={error}
                    //             loading={loading}
                    //             data={storeCustomizationSetting?.home?.feature_title}
                    //           />
                    //         </h2>
                    //         <p className="text-base font-sans text-gray-600 leading-6">
                    //           <CMSkeleton
                    //             count={4}
                    //             height={10}
                    //             error={error}
                    //             loading={loading}
                    //             data={
                    //               storeCustomizationSetting?.home?.feature_description
                    //             }
                    //           />
                    //         </p>
                    //       </div>
                    //     </div>
                    //     <FeatureCategory />
                    //   </div>
                    // </div>
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "bg-gray-100 lg:py-16 py-10",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                                id: "shopify-section-template",
                                className: "bg-gray-100 lg:py-16 shopify-section section",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "page-width page-width--full-width section--padding",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "slideshow slideshow--only1 slideshow--modern slideshow--adapt_first slideshow--mobile-adapt_first slideshow--mobile-overlay",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "slideshow__center center mobile-left page-width"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "relative w-full h-32 lg:h-48 flex items-center justify-between",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "absolute inset-0 flex items-center justify-between",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                            src: "/logo/lineart4.png",
                                                            alt: "Left Image",
                                                            className: "w-1/3 h-full object-cover",
                                                            style: {
                                                                width: "9%",
                                                                height: "69px"
                                                            }
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                            className: "z-2 text-gray-800 text-xl lg:text-5xl font-bold text-center mx-0 ",
                                                            children: "Trending Categories"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                            src: "/logo/lineart4.png",
                                                            alt: "Right Image",
                                                            className: "w-1/3 h-full object-cover transform scale-x-[-1]",
                                                            style: {
                                                                width: "9%",
                                                                height: "69px"
                                                            }
                                                        })
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_category_FeatureCategory__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z, {})
                        ]
                    }),
                    storeCustomizationSetting?.home?.popular_products_status && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "bg-gray-50 lg:py-16 py-10 mx-auto max-w-screen-2xl px-3 sm:px-10",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "mb-10 flex justify-center",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "text-center w-full lg:w-2/5",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                            className: "text-xl lg:text-2xl mb-2 font-serif font-semibold",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_preloader_CMSkeleton__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .Z, {
                                                count: 1,
                                                height: 30,
                                                // error={error}
                                                loading: loading,
                                                data: storeCustomizationSetting?.home?.popular_title
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "text-base font-sans text-gray-600 leading-6",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_preloader_CMSkeleton__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .Z, {
                                                count: 5,
                                                height: 10,
                                                error: error,
                                                loading: loading,
                                                data: storeCustomizationSetting?.home?.popular_description
                                            })
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "w-full",
                                    children: loading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_preloader_CMSkeleton__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .Z, {
                                        count: 20,
                                        height: 20,
                                        error: error,
                                        loading: loading
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 xl:grid-cols-5 2xl:grid-cols-6 gap-2 md:gap-3 lg:gap-3",
                                        children: popularProducts?.slice(0, storeCustomizationSetting?.home?.popular_product_limit).map((product)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_product_ProductCard__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                                                product: product,
                                                attributes: attributes
                                            }, product._id))
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_carousel_PromotionalBannerCarousel__WEBPACK_IMPORTED_MODULE_22__/* ["default"] */ .Z, {}),
                    storeCustomizationSetting?.home?.discount_product_status && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        id: "discount",
                        className: "bg-gray-50 lg:py-16 py-10 mx-auto max-w-screen-2xl px-3 sm:px-10",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "mb-10 flex justify-center",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "text-center w-full lg:w-2/5",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                            className: "text-xl lg:text-2xl mb-2 font-serif font-semibold",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_preloader_CMSkeleton__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .Z, {
                                                count: 1,
                                                height: 30,
                                                // error={error}
                                                loading: loading,
                                                data: storeCustomizationSetting?.home?.latest_discount_title
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "text-base font-sans text-gray-600 leading-6",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_preloader_CMSkeleton__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .Z, {
                                                count: 5,
                                                height: 20,
                                                // error={error}
                                                loading: loading,
                                                data: storeCustomizationSetting?.home?.latest_discount_description
                                            })
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "w-full",
                                    children: loading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_preloader_CMSkeleton__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .Z, {
                                        count: 20,
                                        height: 20,
                                        error: error,
                                        loading: loading
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 xl:grid-cols-5 2xl:grid-cols-6 gap-2 md:gap-3 lg:gap-3",
                                        children: discountProducts?.slice(0, storeCustomizationSetting?.home?.latest_discount_product_limit).map((product)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_product_ProductCard__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                                                product: product,
                                                attributes: attributes
                                            }, product._id))
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        id: "downloadApp",
                        className: "bg-indigo-50 py-10 lg:py-16 bg-repeat bg-center overflow-hidden",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "max-w-screen-2xl mx-auto px-4 sm:px-10",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 2xl:grid-cols-3 gap-2 md:gap-3 lg:gap-3 items-center",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "hidden md:flex md:justify-center lg:justify-start",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            alt: "app download",
                                            fetchpriority: "high",
                                            width: "500",
                                            height: "394",
                                            decoding: "async",
                                            className: "block w-auto",
                                            srcSet: "/logo/banner1.png",
                                            src: "/logo/banner1.png",
                                            style: {
                                                color: "transparent"
                                            }
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "text-center",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                className: "text-xl md:text-2xl lg:text-3xl font-bold font-serif mb-3",
                                                children: "Get Your Daily Needs From Our EcommEdge Store"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: "text-base opacity-90 leading-7",
                                                children: "There are many products you will find in our shop, Choose your daily necessary product from our EcommEdge shop and get some special offers."
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "hidden lg:flex justify-end",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            alt: "app download",
                                            fetchpriority: "high",
                                            width: "500",
                                            height: "394",
                                            decoding: "async",
                                            className: "block w-auto",
                                            srcSet: "/logo/banner2.png",
                                            src: "/logo/banner2.png",
                                            style: {
                                                color: "transparent"
                                            }
                                        })
                                    })
                                ]
                            })
                        })
                    })
                ]
            })
        })
    });
};
const _getServerSideProps = async (context)=>{
    const { cookies  } = context.req;
    const { query , _id  } = context.query;
    const [data, attributes] = await Promise.all([
        _services_ProductServices__WEBPACK_IMPORTED_MODULE_16__/* ["default"].getShowingStoreProducts */ .Z.getShowingStoreProducts({
            category: _id ? _id : "",
            title: query ? query : ""
        }),
        _services_AttributeServices__WEBPACK_IMPORTED_MODULE_20__/* ["default"].getShowingAttributes */ .Z.getShowingAttributes(), 
    ]);
    console.log("getShowingStoreProducts", data);
    const popularProducts = data?.products.filter((p)=>p.prices.discount >= 1);
    console.log("popularProducts", data);
    const discountProducts = data?.products.filter((p)=>p.prices?.discount >= 1);
    console.log("discountProducts", data);
    const fetureproduct = data?.fetureproduct;
    return {
        props: {
            popularProducts: popularProducts.slice(0, 50),
            discountProducts: discountProducts,
            fetureproduct: fetureproduct,
            cookies: cookies,
            attributes
        }
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Home);
async function getServerSideProps(ctx) {
    let res = _getServerSideProps(ctx);
    if (typeof res.then === "function") res = await res;
    return {
        ...res,
        props: {
            ...res.props || {},
            ...await next_translate_loadNamespaces__WEBPACK_IMPORTED_MODULE_2___default()({
                ...ctx,
                pathname: "/index",
                loaderName: "getServerSideProps",
                ..._next_translate_root_i18n__WEBPACK_IMPORTED_MODULE_1__,
                loadLocaleFrom: (l, n)=>__webpack_require__(7655)(`./${l}/${n}`).then((m)=>m.default)
            })
        }
    };
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8768:
/***/ ((module) => {

module.exports = require("@heroicons/react/outline");

/***/ }),

/***/ 6999:
/***/ ((module) => {

module.exports = require("@react-oauth/google");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 4515:
/***/ ((module) => {

module.exports = require("@stripe/react-stripe-js");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 1635:
/***/ ((module) => {

module.exports = require("dayjs");

/***/ }),

/***/ 7462:
/***/ ((module) => {

module.exports = require("next-translate/loadNamespaces");

/***/ }),

/***/ 866:
/***/ ((module) => {

module.exports = require("next-translate/useTranslation");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 5832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 5307:
/***/ ((module) => {

module.exports = require("rc-drawer");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 2807:
/***/ ((module) => {

module.exports = require("react-copy-to-clipboard");

/***/ }),

/***/ 6358:
/***/ ((module) => {

module.exports = require("react-dropzone");

/***/ }),

/***/ 2750:
/***/ ((module) => {

module.exports = require("react-icons/fi");

/***/ }),

/***/ 924:
/***/ ((module) => {

module.exports = require("react-icons/im");

/***/ }),

/***/ 9989:
/***/ ((module) => {

module.exports = require("react-icons/io5");

/***/ }),

/***/ 4152:
/***/ ((module) => {

module.exports = require("react-icons/tb");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 6158:
/***/ ((module) => {

module.exports = require("react-share");

/***/ }),

/***/ 2633:
/***/ ((module) => {

module.exports = require("react-spinners/ScaleLoader");

/***/ }),

/***/ 1305:
/***/ ((module) => {

module.exports = require("react-timer-hook");

/***/ }),

/***/ 1187:
/***/ ((module) => {

module.exports = require("react-toastify");

/***/ }),

/***/ 7090:
/***/ ((module) => {

module.exports = require("react-ui");

/***/ }),

/***/ 9878:
/***/ ((module) => {

module.exports = require("react-use-cart");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = import("@headlessui/react");;

/***/ }),

/***/ 2905:
/***/ ((module) => {

module.exports = import("html-react-parser");;

/***/ }),

/***/ 9915:
/***/ ((module) => {

module.exports = import("js-cookie");;

/***/ }),

/***/ 5641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ }),

/***/ 4275:
/***/ ((module) => {

module.exports = import("react-loading-skeleton");;

/***/ }),

/***/ 4612:
/***/ ((module) => {

module.exports = import("socket.io-client");;

/***/ }),

/***/ 3877:
/***/ ((module) => {

module.exports = import("swiper");;

/***/ }),

/***/ 3015:
/***/ ((module) => {

module.exports = import("swiper/react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [678,138,378,399,408,812,354,440,8,286,596,334,106], () => (__webpack_exec__(4875)));
module.exports = __webpack_exports__;

})();