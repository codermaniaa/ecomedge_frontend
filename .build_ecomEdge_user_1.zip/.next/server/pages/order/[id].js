"use strict";
(() => {
var exports = {};
exports.id = 441;
exports.ids = [441];
exports.modules = {

/***/ 9911:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1635);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(dayjs__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(543);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8027);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _component_order_OrderTable__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8584);
/* harmony import */ var _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(545);
/* harmony import */ var _context_OrderContext__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5376);
/* harmony import */ var _hooks_useCheckoutSubmit__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7284);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_component_order_OrderTable__WEBPACK_IMPORTED_MODULE_5__, _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_6__, _hooks_useCheckoutSubmit__WEBPACK_IMPORTED_MODULE_8__]);
([_component_order_OrderTable__WEBPACK_IMPORTED_MODULE_5__, _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_6__, _hooks_useCheckoutSubmit__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





//internal import




const Invoice = ({ data , printRef , globalSetting , currency  })=>{
    const { submitHandler , orderResponse , loading  } = (0,_hooks_useCheckoutSubmit__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
    const { getNumberTwo  } = (0,_hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)();
    const { order  } = (0,_context_OrderContext__WEBPACK_IMPORTED_MODULE_7__/* .useOrder */ .A)();
    console.log("orderResponseinvoive", order);
    // Iterate over each item and sum up the taxAmount property of each tax object
    const { 0: totalTax , 1: setTotalTax  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(0);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        let totalTaxAmount = 0;
        order.cart.forEach((item)=>{
            item.tax["GST 18"].forEach((tax)=>{
                totalTaxAmount += tax.taxAmount;
            });
        });
        setTotalTax(totalTaxAmount);
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        ref: printRef,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "bg-indigo-50 p-8 rounded-t-xl",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex lg:flex-row md:flex-row flex-col lg:items-center justify-between pb-4 border-b border-gray-50",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: "font-bold font-serif text-2xl uppercase",
                                        children: "Invoice"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h6", {
                                        className: "text-gray-700",
                                        children: [
                                            "Status :",
                                            " ",
                                            order?.status === "Delivered" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-gray-500",
                                                children: order?.status
                                            }),
                                            order?.status === "POS-Completed" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-gray-500",
                                                children: order?.status
                                            }),
                                            order?.status === "Pending" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-orange-500",
                                                children: order?.status
                                            }),
                                            order?.status === "Cancel" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-red-500",
                                                children: order?.status
                                            }),
                                            order?.status === "Processing" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-indigo-500",
                                                children: order?.status
                                            }),
                                            order?.status === "Deleted" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-red-700",
                                                children: order?.status
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "lg:text-right text-left",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                        className: "text-lg font-serif font-semibold mt-4 lg:mt-0 md:mt-0",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                            href: "/",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                className: "",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                    width: 30,
                                                    height: 20,
                                                    src: "/logo/Ecomedge.png",
                                                    alt: "logo"
                                                })
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "text-sm text-gray-500 pt-3",
                                        children: globalSetting?.address || "Akshya Nagar 1st Block 1st Cross, Rammurthy nagar, Bangalore-560016"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex lg:flex-row md:flex-row flex-col justify-between pt-4",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "mb-3 md:mb-0 lg:mb-0 flex flex-col",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "font-bold font-serif text-sm uppercase text-gray-600 block",
                                        children: "Date"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text-sm text-gray-500 block",
                                        children: order?.createdAt !== undefined && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            children: dayjs__WEBPACK_IMPORTED_MODULE_1___default()(order?.createdAt).format("MMMM D, YYYY")
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "mb-3 md:mb-0 lg:mb-0 flex flex-col",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "font-bold font-serif text-sm uppercase text-gray-600 block",
                                        children: "Invoice No."
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: "text-sm text-gray-500 block",
                                        children: [
                                            "#",
                                            order?.invoiceDetails?.invoiceNumber
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-col lg:text-right text-left",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "font-bold font-serif text-sm uppercase text-gray-600 block",
                                        children: "Invoice To."
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: "text-sm text-gray-500 block",
                                        children: [
                                            order?.user_info?.name,
                                            " ",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                            order?.user_info?.email,
                                            " ",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "ml-2",
                                                children: order?.user_info?.contact
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                            order?.user_info?.address,
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                            order?.city,
                                            " ",
                                            order?.country,
                                            " ",
                                            order?.zipCode,
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "font-bold font-serif text-sm uppercase text-gray-600 block",
                                                children: "GST NO."
                                            }),
                                            order?.user_info?.gstnumber
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "s",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "overflow-hidden lg:overflow-visible px-8 my-10",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "-my-2 overflow-x-auto",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                            className: "table-auto min-w-full border border-gray-100 divide-y divide-gray-200",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                    className: "bg-gray-50",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                        className: "text-xs bg-gray-100",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                scope: "col",
                                                className: "font-serif font-semibold px-6 py-2 text-gray-700 uppercase tracking-wider text-left",
                                                children: "Sr."
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                scope: "col",
                                                className: "font-serif font-semibold px-6 py-2 text-gray-700 uppercase tracking-wider text-left",
                                                children: "Product Name"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                scope: "col",
                                                className: "font-serif font-semibold px-6 py-2 text-gray-700 uppercase tracking-wider text-center",
                                                children: "Quantity"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                scope: "col",
                                                className: "font-serif font-semibold px-6 py-2 text-gray-700 uppercase tracking-wider text-center",
                                                children: "Item Price"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                scope: "col",
                                                className: "font-serif font-semibold px-6 py-2 text-gray-700 uppercase tracking-wider text-center",
                                                children: order?.cart[0]?.tax["GST 18"][0].taxName === "IGST" ? "IGST" : "CGST & SGST"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                scope: "col",
                                                className: "font-serif font-semibold px-6 py-2 text-gray-700 uppercase tracking-wider text-right",
                                                children: "Amount"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_order_OrderTable__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                    order: order,
                                    currency: currency
                                })
                            ]
                        })
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "border-t border-b border-gray-100 p-10 bg-gray-50",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex lg:flex-row md:flex-row flex-col justify-between pt-4",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "mb-3 md:mb-0 lg:mb-0 flex flex-col sm:flex-wrap",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "mb-1 font-bold font-serif text-sm uppercase text-gray-600 block",
                                    children: "Payment Method"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "text-sm text-gray-500 font-semibold font-serif block",
                                    children: order?.paymentMethod
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "mb-3 md:mb-0 lg:mb-0 flex flex-col sm:flex-wrap",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "mb-1 font-bold font-serif text-sm uppercase text-gray-600 block",
                                    children: "Shipping Cost"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "text-sm text-gray-500 font-semibold font-serif block",
                                    children: getNumberTwo(order?.shippingCost)
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "mb-3 md:mb-0 lg:mb-0 flex flex-col sm:flex-wrap",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "mb-1 font-bold font-serif text-sm uppercase text-gray-600 block",
                                    children: "Discount"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "text-sm text-gray-500 font-semibold font-serif block",
                                    children: getNumberTwo(order?.discount)
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "mb-3 md:mb-0 lg:mb-0 flex flex-col sm:flex-wrap",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "mb-1 font-bold font-serif text-sm uppercase text-gray-600 block",
                                    children: "Total tax"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "text-sm text-gray-500 font-semibold font-serif block",
                                    children: getNumberTwo(totalTax ? totalTax : 0)
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex flex-col sm:flex-wrap",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "mb-1 font-bold font-serif text-sm uppercase text-gray-600 block",
                                    children: "Total Amount"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "text-2xl font-serif font-bold text-red-500 block",
                                    children: getNumberTwo(order?.total)
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Invoice);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 886:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3260);
/* harmony import */ var _react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1635);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(dayjs__WEBPACK_IMPORTED_MODULE_2__);



_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.Font.register({
    family: "Open Sans",
    fonts: [
        {
            src: "https://cdn.jsdelivr.net/npm/open-sans-all@0.1.3/fonts/open-sans-regular.ttf"
        },
        {
            src: "https://cdn.jsdelivr.net/npm/open-sans-all@0.1.3/fonts/open-sans-600.ttf",
            fontWeight: 600
        }, 
    ]
});
_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.Font.register({
    family: "DejaVu Sans",
    fonts: [
        {
            src: "https://kendo.cdn.telerik.com/2017.2.621/styles/fonts/DejaVu/DejaVuSans.ttf"
        },
        {
            src: "https://kendo.cdn.telerik.com/2017.2.621/styles/fonts/DejaVu/DejaVuSans-Bold.ttf"
        }, 
    ]
});
const styles = _react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.StyleSheet.create({
    page: {
        marginRight: 10,
        marginBottom: 20,
        marginLeft: 10,
        paddingTop: 30,
        paddingLeft: 10,
        paddingRight: 29,
        lineHeight: 1.5
    },
    table: {
        display: "table",
        width: "auto",
        color: "#4b5563",
        marginRight: 10,
        marginBottom: 20,
        marginLeft: 10,
        marginTop: 0,
        borderRadius: "8px",
        borderColor: "#e9e9e9",
        borderStyle: "solid",
        borderWidth: 0.5,
        padding: 0,
        textAlign: "left"
    },
    tableRow: {
        // margin: 'auto',
        flexDirection: "row",
        paddingBottom: 2,
        paddingTop: 2,
        textAlign: "left",
        borderWidth: 0.8,
        borderColor: "#E5E7EB",
        borderBottom: "0"
    },
    tableRowHeder: {
        // margin: 'auto',
        flexDirection: "row",
        backgroundColor: "#f9fafb",
        paddingBottom: 4,
        paddingTop: 4,
        paddingLeft: 0,
        borderBottomWidth: 0.8,
        borderColor: "#E5E7EB",
        borderStyle: "solid",
        textTransform: "uppercase",
        textAlign: "left"
    },
    tableCol: {
        width: "25%",
        textAlign: "left"
    },
    tableCell: {
        margin: "auto",
        marginTop: 5,
        fontSize: 10,
        // textAlign:'center',
        paddingLeft: "0",
        paddingRight: "0",
        marginLeft: "13",
        marginRight: "13"
    },
    tableCellQuantity: {
        margin: "auto",
        marginTop: 5,
        fontSize: 10,
        textAlign: "center",
        paddingLeft: "0",
        paddingRight: "0",
        marginLeft: "12",
        marginRight: "12"
    },
    invoiceFirst: {
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        paddingBottom: 18,
        paddingLeft: 10,
        paddingRight: 10,
        borderBottom: 1,
        borderColor: "#f3f4f6"
    },
    invoiceSecond: {
        display: "flex",
        flexDirection: "row",
        alignItems: "flex-start",
        justifyContent: "space-between",
        paddingTop: 20,
        paddingBottom: 10,
        // backgroundColor:'#EEF2FF',
        paddingLeft: 10,
        paddingRight: 10
    },
    invoiceThird: {
        display: "flex",
        flexDirection: "row",
        alignItems: "baseline",
        justifyContent: "space-between",
        paddingTop: 20,
        paddingBottom: 20,
        paddingLeft: 10,
        paddingRight: 10,
        borderTop: 1,
        borderColor: "#ffffff",
        backgroundColor: "#f4f5f7",
        borderRadius: 12,
        marginLeft: "13",
        marginRight: "13"
    },
    logo: {
        width: 64,
        height: 25,
        bottom: 5,
        right: 10,
        marginBottom: 10,
        textAlign: "right",
        color: "#4b5563",
        fontFamily: "Open Sans",
        fontWeight: "bold",
        fontSize: 10.3,
        marginRight: "39%",
        textTransform: "uppercase"
    },
    title: {
        color: "#2f3032",
        fontFamily: "Open Sans",
        fontWeight: "bold",
        fontSize: 8.1,
        textTransform: "uppercase"
    },
    info: {
        fontSize: 9,
        color: "#6b7280"
    },
    infoCost: {
        fontSize: 10,
        color: "#6b7280",
        marginLeft: "4%",
        marginTop: "7px",
        textAlign: "left",
        width: "25%"
    },
    invoiceNum: {
        fontSize: 9,
        color: "#6b7280",
        marginLeft: "6%"
    },
    topAddress: {
        fontSize: 10,
        color: "#6b7280",
        width: "100%"
    },
    amount: {
        fontSize: 10,
        color: "#ef4444"
    },
    totalAmount: {
        fontSize: 10,
        color: "#ef4444",
        fontFamily: "Open Sans",
        fontWeight: "bold",
        textTransform: "uppercase",
        textAlign: "right"
    },
    status: {
        color: "#10b981"
    },
    quantity: {
        color: "#1f2937",
        textAlign: "center"
    },
    itemPrice: {
        color: "#1f2937",
        textAlign: "left"
    },
    header: {
        color: "#6b7280",
        fontSize: 9,
        fontFamily: "Open Sans",
        fontWeight: "bold",
        textTransform: "uppercase",
        textAlign: "left"
    },
    thanks: {
        color: "#22c55e"
    },
    infoRight: {
        textAlign: "right",
        fontSize: 9,
        color: "#6b7280",
        width: "25%",
        marginRight: "39%",
        fontFamily: "Open Sans",
        fontWeight: "bold"
    },
    titleRight: {
        textAlign: "right",
        fontFamily: "Open Sans",
        fontWeight: "bold",
        fontSize: 8.1,
        width: "25%",
        marginRight: "39%",
        textTransform: "uppercase",
        color: "#2f3032"
    },
    topBg: {
    },
    invoiceDiv: {
        alignItems: "baseline"
    }
});
const InvoiceForDownload = ({ data , currency , globalSetting , getNumberTwo ,  })=>{
    console.log("InvoiceForDownload", data);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.Document, {
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.Page, {
                size: "A4",
                style: styles.page,
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.View, {
                        style: styles.invoiceFirst,
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.View, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                        style: {
                                            fontFamily: "Open Sans",
                                            fontWeight: "bold"
                                        },
                                        children: "INVOICE"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                        style: styles.info,
                                        children: [
                                            "Status : ",
                                            data?.status
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.View, {
                                style: styles.topBg,
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                        style: {
                                            width: "100%",
                                            marginRight: "40%"
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.Image, {
                                            src: "https://res.cloudinary.com/ahossain/image/upload/v1681454665/logo/logo-color_qw1trc.png",
                                            alt: "Invoice",
                                            style: {
                                                width: 80,
                                                textAlign: "right"
                                            }
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                        style: styles.topAddress,
                                        children: globalSetting?.address || "Cecilia Chapman, 561-4535 Nulla LA, United States 96522"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.View, {
                        style: styles.invoiceSecond,
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.View, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                        style: styles.title,
                                        children: "DATE"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                        style: styles.info,
                                        children: dayjs__WEBPACK_IMPORTED_MODULE_2___default()(data?.createdAt).format("MMMM D, YYYY")
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.View, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                        style: styles.title,
                                        children: "INVOICE NO"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                        style: styles.info,
                                        children: [
                                            "#",
                                            data?.invoiceDetails?.invoiceNumber
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.View, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                        style: styles.title,
                                        children: "INVOICE TO"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                        style: styles.info,
                                        children: data?.user_info?.name
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                        style: styles.info,
                                        children: [
                                            " ",
                                            data?.user_info?.address?.substring(0, 25)
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                        style: styles.info,
                                        children: [
                                            data?.user_info?.city,
                                            ", ",
                                            data?.user_info?.country,
                                            ",",
                                            " ",
                                            data?.user_info?.zipCode
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.View, {
                        style: styles.table,
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.View, {
                                style: styles.tableRow,
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.View, {
                                        style: styles.tableCol,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                            style: styles.tableCell,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                                style: styles.header,
                                                children: "Sr."
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.View, {
                                        style: styles.tableCol,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                            style: styles.tableCell,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                                style: styles.header,
                                                children: "Product Name"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.View, {
                                        style: styles.tableCol,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                            style: styles.tableCell,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                                style: styles.header,
                                                children: "Quantity"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.View, {
                                        style: styles.tableCol,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                            style: styles.tableCell,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                                style: styles.header,
                                                children: "Item Price"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.View, {
                                        style: styles.tableCol,
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                            style: styles.tableCell,
                                            children: [
                                                " ",
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                                    style: styles.header,
                                                    children: "Amount"
                                                })
                                            ]
                                        })
                                    })
                                ]
                            }),
                            data?.cart?.map((item, i)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.View, {
                                    style: styles.tableRow,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.View, {
                                            style: styles.tableCol,
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                                style: styles.tableCell,
                                                children: [
                                                    i + 1,
                                                    " "
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.View, {
                                            style: styles.tableCol,
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                                style: styles.tableCell,
                                                children: [
                                                    item.title,
                                                    " "
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.View, {
                                            style: styles.tableCol,
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                                style: styles.tableCell,
                                                children: [
                                                    " ",
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                                        style: styles.quantity,
                                                        children: item.quantity
                                                    }),
                                                    " "
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.View, {
                                            style: styles.tableCol,
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                                style: styles.tableCell,
                                                children: [
                                                    " ",
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                                        style: styles.quantity,
                                                        children: [
                                                            currency,
                                                            getNumberTwo(item.price)
                                                        ]
                                                    }),
                                                    " "
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.View, {
                                            style: styles.tableCol,
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                                style: styles.tableCell,
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                                        style: styles.amount,
                                                        children: [
                                                            currency,
                                                            getNumberTwo(item.itemTotal)
                                                        ]
                                                    }),
                                                    " "
                                                ]
                                            })
                                        })
                                    ]
                                }, i))
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.View, {
                        style: styles.invoiceThird,
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.View, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                        style: styles.title,
                                        children: " Payment Method"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                        style: styles.info,
                                        children: [
                                            " ",
                                            data.paymentMethod,
                                            " "
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.View, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                        style: styles.title,
                                        children: "Shipping Cost"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                        style: styles.info,
                                        children: [
                                            currency,
                                            getNumberTwo(data.shippingCost)
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.View, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                        style: styles.title,
                                        children: "Discount"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                        style: styles.info,
                                        children: [
                                            " ",
                                            currency,
                                            getNumberTwo(data.discount)
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.View, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                        style: styles.title,
                                        children: "Total Amount"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                        style: styles.amount,
                                        children: [
                                            currency,
                                            getNumberTwo(data.total)
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.View, {
                        style: {
                            textAlign: "center",
                            fontSize: 12,
                            paddingBottom: 50,
                            paddingTop: 50
                        },
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.Text, {
                            children: [
                                "Thank you ",
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                    style: styles.thanks,
                                    children: [
                                        data.name,
                                        ","
                                    ]
                                }),
                                " Your order have been received !"
                            ]
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (InvoiceForDownload);


/***/ }),

/***/ 8584:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(545);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_1__]);
_hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const OrderTable = ({ order , currency  })=>{
    const { getNumberTwo  } = (0,_hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)();
    console.log("OrderTable data..", order);
    const { 0: totalTax , 1: setTotalTax  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(0);
    // Iterate over each item and sum up the taxAmount property of each tax object
    // useEffect(()=>{
    //   let totalTaxAmount = 0;
    //   order.cart.forEach(item => {
    //     item.tax["GST 18"].forEach(tax => {
    //         totalTaxAmount += tax.taxAmount;
    //     });
    // });
    //   setTotalTax(totalTaxAmount); 
    // })
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
        className: "bg-white divide-y divide-gray-100 text-serif text-sm",
        children: order?.cart?.map((item, i)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("th", {
                        className: "px-6 py-1 whitespace-nowrap font-normal text-gray-500 text-left",
                        children: [
                            i + 1,
                            " "
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                        className: "px-6 py-1 whitespace-nowrap font-normal text-gray-500",
                        children: item.title
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                        className: "px-6 py-1 whitespace-nowrap font-bold text-center",
                        children: [
                            item.quantity,
                            " "
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                        className: "px-6 py-1 whitespace-nowrap font-bold text-center font-DejaVu",
                        children: getNumberTwo(item?.pricePerUnit - item?.discountPerUnit)
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                        className: "px-6 py-1 whitespace-nowrap font-bold text-center font-DejaVu",
                        children: getNumberTwo(item?.totalTaxAmount)
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                        className: "px-6 py-1 whitespace-nowrap text-right font-bold font-DejaVu k-grid text-red-500",
                        children: getNumberTwo(item?.finalPrice)
                    })
                ]
            }, i))
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (OrderTable);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9092:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _next_translate_root_i18n__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(608);
/* harmony import */ var next_translate_loadNamespaces__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7462);
/* harmony import */ var next_translate_loadNamespaces__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_translate_loadNamespaces__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3260);
/* harmony import */ var _react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3521);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9989);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_icons_io5__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_to_print__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(53);
/* harmony import */ var react_to_print__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_to_print__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _layout_Layout__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1286);
/* harmony import */ var _hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5538);
/* harmony import */ var _component_invoice_Invoice__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9911);
/* harmony import */ var _component_preloader_Loading__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(8906);
/* harmony import */ var _context_UserContext__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(5408);
/* harmony import */ var _services_OrderServices__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(6139);
/* harmony import */ var _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(545);
/* harmony import */ var _component_invoice_InvoiceForDownload__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(886);
/* harmony import */ var _hooks_useCheckoutSubmit__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(7284);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_layout_Layout__WEBPACK_IMPORTED_MODULE_9__, _hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_10__, _component_invoice_Invoice__WEBPACK_IMPORTED_MODULE_11__, _context_UserContext__WEBPACK_IMPORTED_MODULE_13__, _services_OrderServices__WEBPACK_IMPORTED_MODULE_14__, _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_15__, _hooks_useCheckoutSubmit__WEBPACK_IMPORTED_MODULE_17__]);
([_layout_Layout__WEBPACK_IMPORTED_MODULE_9__, _hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_10__, _component_invoice_Invoice__WEBPACK_IMPORTED_MODULE_11__, _context_UserContext__WEBPACK_IMPORTED_MODULE_13__, _services_OrderServices__WEBPACK_IMPORTED_MODULE_14__, _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_15__, _hooks_useCheckoutSubmit__WEBPACK_IMPORTED_MODULE_17__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









//internal import









const Order = ({ params  })=>{
    const printRef = (0,react__WEBPACK_IMPORTED_MODULE_6__.useRef)();
    const orderId = params.id;
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter)();
    const { 0: data , 1: setData  } = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)({});
    const { 0: loading , 1: setLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(true);
    const { state: { userInfo  } ,  } = (0,react__WEBPACK_IMPORTED_MODULE_6__.useContext)(_context_UserContext__WEBPACK_IMPORTED_MODULE_13__/* .UserContext */ .S);
    const { showingTranslateValue , getNumberTwo  } = (0,_hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z)();
    const { storeCustomizationSetting , globalSetting  } = (0,_hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)();
    const { submitHandler , orderResponse  } = (0,_hooks_useCheckoutSubmit__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z)();
    (0,react__WEBPACK_IMPORTED_MODULE_6__.useEffect)(()=>{
        (async ()=>{
            try {
                const res = await _services_OrderServices__WEBPACK_IMPORTED_MODULE_14__/* ["default"].getOrderById */ .Z.getOrderById(orderId);
                setData(res);
                setLoading(false);
                console.log("getOrderById", res);
            } catch (err) {
                setLoading(false);
                console.log("err", err.message);
            }
        })();
        console.log("orderResponse in Order page", printRef);
        console.log("orderResponse in Order page", data);
        console.log("orderResponse in Order page", params);
        if (!userInfo) {
            router.push("/");
        }
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_layout_Layout__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
        title: "Invoice",
        description: "order confirmation page",
        children: loading && !data ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_preloader_Loading__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
            loading: loading
        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "max-w-screen-2xl mx-auto py-10 px-3 sm:px-6",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "bg-gray-300 rounded-md mb-5 px-4 py-3",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                        children: [
                            showingTranslateValue(storeCustomizationSetting?.dashboard?.invoice_message_first),
                            " ",
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "font-bold text-gray-600",
                                children: [
                                    data?.user_info?.name,
                                    ","
                                ]
                            }),
                            " ",
                            showingTranslateValue(storeCustomizationSetting?.dashboard?.invoice_message_last)
                        ]
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "bg-white rounded-lg shadow-sm",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_invoice_Invoice__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                            data: data,
                            printRef: printRef,
                            globalSetting: globalSetting,
                            currency: globalSetting?.default_currency || "$"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "bg-white p-8 rounded-b-xl",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex lg:flex-row md:flex-row sm:flex-row flex-col justify-between invoice-btn",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__.PDFDownloadLink, {
                                        document: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_invoice_InvoiceForDownload__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                                            data: data,
                                            globalSetting: globalSetting,
                                            getNumberTwo: getNumberTwo,
                                            currency: globalSetting?.default_currency || "$"
                                        }),
                                        fileName: "Invoice"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_to_print__WEBPACK_IMPORTED_MODULE_8___default()), {
                                        trigger: ()=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                                className: "mb-3 sm:mb-0 md:mb-0 lg:mb-0 flex items-center justify-center bg-gray-800 text-white transition-all font-serif text-sm font-semibold h-10 py-2 px-5 rounded-md",
                                                children: [
                                                    showingTranslateValue(storeCustomizationSetting?.dashboard?.print_button),
                                                    " ",
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "ml-2",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io5__WEBPACK_IMPORTED_MODULE_7__.IoPrintOutline, {})
                                                    })
                                                ]
                                            }),
                                        content: ()=>printRef.current,
                                        documentTitle: "Invoice"
                                    })
                                ]
                            })
                        })
                    ]
                })
            ]
        })
    });
};
const _getServerSideProps = ({ params  })=>{
    return {
        props: {
            params
        }
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (next_dynamic__WEBPACK_IMPORTED_MODULE_4___default()(()=>Promise.resolve(Order), {
    ssr: false
}));
async function getServerSideProps(ctx) {
    let res = _getServerSideProps(ctx);
    if (typeof res.then === "function") res = await res;
    return {
        ...res,
        props: {
            ...res.props || {},
            ...await next_translate_loadNamespaces__WEBPACK_IMPORTED_MODULE_2___default()({
                ...ctx,
                pathname: "/order/[id]",
                loaderName: "getServerSideProps",
                ..._next_translate_root_i18n__WEBPACK_IMPORTED_MODULE_1__,
                loadLocaleFrom: (l, n)=>__webpack_require__(7655)(`./${l}/${n}`).then((m)=>m.default)
            })
        }
    };
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8768:
/***/ ((module) => {

module.exports = require("@heroicons/react/outline");

/***/ }),

/***/ 6999:
/***/ ((module) => {

module.exports = require("@react-oauth/google");

/***/ }),

/***/ 3260:
/***/ ((module) => {

module.exports = require("@react-pdf/renderer");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 4515:
/***/ ((module) => {

module.exports = require("@stripe/react-stripe-js");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 1635:
/***/ ((module) => {

module.exports = require("dayjs");

/***/ }),

/***/ 7462:
/***/ ((module) => {

module.exports = require("next-translate/loadNamespaces");

/***/ }),

/***/ 866:
/***/ ((module) => {

module.exports = require("next-translate/useTranslation");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 5832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 5307:
/***/ ((module) => {

module.exports = require("rc-drawer");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6358:
/***/ ((module) => {

module.exports = require("react-dropzone");

/***/ }),

/***/ 2750:
/***/ ((module) => {

module.exports = require("react-icons/fi");

/***/ }),

/***/ 924:
/***/ ((module) => {

module.exports = require("react-icons/im");

/***/ }),

/***/ 9989:
/***/ ((module) => {

module.exports = require("react-icons/io5");

/***/ }),

/***/ 4152:
/***/ ((module) => {

module.exports = require("react-icons/tb");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 6158:
/***/ ((module) => {

module.exports = require("react-share");

/***/ }),

/***/ 2633:
/***/ ((module) => {

module.exports = require("react-spinners/ScaleLoader");

/***/ }),

/***/ 53:
/***/ ((module) => {

module.exports = require("react-to-print");

/***/ }),

/***/ 1187:
/***/ ((module) => {

module.exports = require("react-toastify");

/***/ }),

/***/ 9878:
/***/ ((module) => {

module.exports = require("react-use-cart");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = import("@headlessui/react");;

/***/ }),

/***/ 2905:
/***/ ((module) => {

module.exports = import("html-react-parser");;

/***/ }),

/***/ 9915:
/***/ ((module) => {

module.exports = import("js-cookie");;

/***/ }),

/***/ 5641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ }),

/***/ 4275:
/***/ ((module) => {

module.exports = import("react-loading-skeleton");;

/***/ }),

/***/ 4612:
/***/ ((module) => {

module.exports = import("socket.io-client");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [678,138,378,399,408,812,354,440,8,286], () => (__webpack_exec__(9092)));
module.exports = __webpack_exports__;

})();