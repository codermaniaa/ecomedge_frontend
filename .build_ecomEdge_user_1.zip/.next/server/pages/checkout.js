"use strict";
(() => {
var exports = {};
exports.id = 222;
exports.ids = [222];
exports.modules = {

/***/ 7651:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const InputPayment = ({ register , Icon , name , value , setShowCard  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "px-3 py-4 card border border-gray-200 bg-white rounded-md",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
            className: "cursor-pointer label",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex item-center justify-between",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex items-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "text-xl mr-3 text-gray-400",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Icon, {})
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                className: "font-serif font-medium text-sm text-gray-600",
                                children: name
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                        onClick: ()=>setShowCard(value === "Card" ? true : false),
                        ...register("paymentMethod", {
                            required: "Payment Method is required!"
                        }),
                        type: "radio",
                        value: value,
                        name: "paymentMethod",
                        className: "form-radio outline-none focus:ring-0 text-gray-500"
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (InputPayment);


/***/ }),

/***/ 6659:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2750);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_2__);



const InputShipping = ({ register , value , time , cost , Image , currency , handleShippingCost , id ,  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "p-3 card border border-gray-200 bg-white rounded-md",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                className: "cursor-pointer label",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex items-center justify-between",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex items-center",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "text-2xl mr-3 text-gray-400",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: Image,
                                        alt: "icon",
                                        width: 30,
                                        height: 30
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                            className: "font-serif font-medium text-sm text-gray-600",
                                            children: value
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                            className: "text-xs text-gray-500 font-medium",
                                            children: [
                                                "Delivery:",
                                                " ",
                                                time > 1 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                    children: [
                                                        time,
                                                        " days"
                                                    ]
                                                }) : time == 0 ? "Today" : "Tomorrow",
                                                " ",
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                    className: "font-medium text-gray-600",
                                                    children: [
                                                        "Cost :",
                                                        currency,
                                                        cost,
                                                        ".00"
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            onClick: ()=>handleShippingCost(cost, id),
                            ...register(`shippingOption`, {
                                required: `Shipping Option is required!`
                            }),
                            name: "shippingOption",
                            type: "radio",
                            value: value,
                            className: "form-radio outline-none focus:ring-0 text-gray-500"
                        })
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (InputShipping);


/***/ }),

/***/ 5562:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _next_translate_root_i18n__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(608);
/* harmony import */ var next_translate_appWithI18n__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5668);
/* harmony import */ var next_translate_appWithI18n__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_translate_appWithI18n__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3521);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _stripe_react_stripe_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4515);
/* harmony import */ var _stripe_react_stripe_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_stripe_react_stripe_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(543);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9989);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_icons_io5__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_icons_im__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(924);
/* harmony import */ var react_icons_im__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_icons_im__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(866);
/* harmony import */ var next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _layout_Layout__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1286);
/* harmony import */ var _component_form_Error__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9948);
/* harmony import */ var _component_cart_CartItem__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(9340);
/* harmony import */ var _component_form_InputArea__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(6791);
/* harmony import */ var _hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(5538);
/* harmony import */ var _component_form_InputPayment__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(7651);
/* harmony import */ var _hooks_useCheckoutSubmit__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(7284);
/* harmony import */ var _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(545);
/* harmony import */ var _component_form_Label__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(9545);
/* harmony import */ var _component_form_InputShipping__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(6659);
/* harmony import */ var _services_OrderServices__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(6139);
/* harmony import */ var _utils_toast__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(8548);
/* harmony import */ var _hooks_useAsync__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(9338);
/* harmony import */ var _services_AboutServices__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(5644);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(5641);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_layout_Layout__WEBPACK_IMPORTED_MODULE_10__, _component_cart_CartItem__WEBPACK_IMPORTED_MODULE_12__, _hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_14__, _hooks_useCheckoutSubmit__WEBPACK_IMPORTED_MODULE_16__, _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_17__, _services_OrderServices__WEBPACK_IMPORTED_MODULE_20__, _services_AboutServices__WEBPACK_IMPORTED_MODULE_23__, react_hook_form__WEBPACK_IMPORTED_MODULE_24__]);
([_layout_Layout__WEBPACK_IMPORTED_MODULE_10__, _component_cart_CartItem__WEBPACK_IMPORTED_MODULE_12__, _hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_14__, _hooks_useCheckoutSubmit__WEBPACK_IMPORTED_MODULE_16__, _hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_17__, _services_OrderServices__WEBPACK_IMPORTED_MODULE_20__, _services_AboutServices__WEBPACK_IMPORTED_MODULE_23__, react_hook_form__WEBPACK_IMPORTED_MODULE_24__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










// import { Select } from "@windmill/react-ui";
//internal import















const Checkout = ()=>{
    const { handleSubmit , submitHandler , handleShippingCost , register , errors , showCard , setShowCard , error , stripe , couponInfo , couponRef , handleCouponCode , discountAmount , shippingCost , total , isEmpty , items , cartTotal , currency , isCheckoutSubmit , shippingDetails , tax , taxCalRes , selectItemId , handleSameDetails , billingState , setBillingState , shippingState , setShippingState , handleAddress , handleShippingContactInfo , handleShippingPersonInfo ,  } = (0,_hooks_useCheckoutSubmit__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z)();
    const { t  } = next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_9___default()();
    const { storeCustomizationSetting  } = (0,_hooks_useGetSetting__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z)();
    const { showingTranslateValue  } = (0,_hooks_useUtilsFunction__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z)();
    // const { register, handleSubmit, reset, formState: { errors } } = useForm();
    const totalSalePrice = items.map((items)=>items.prices.salePrice * items.quantity).reduce((acc, curr)=>acc + curr, 0);
    console.log(items, "items total tax price yash");
    const { data  } = (0,_hooks_useAsync__WEBPACK_IMPORTED_MODULE_22__/* ["default"] */ .Z)(()=>_services_AboutServices__WEBPACK_IMPORTED_MODULE_23__/* ["default"].getState */ .Z.getState());
    //console.log("checkout page...", data);
    console.log("taxCalRes checkout", taxCalRes);
    const formatTaxInfo = (taxObject)=>{
        return Object.keys(taxObject).map((key)=>{
            const taxArray = taxObject[key];
            //console.log("taxArray checkout", taxArray);
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                children: taxArray.map((element, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        children: [
                            element.taxName,
                            `(${element.amount}${element.type == "percentage" && "%"})`,
                            "\xa0"
                        ]
                    }, index))
            }, key);
        });
    };
    // Tax calculation
    let totalTax = 0;
    const taxElements = taxCalRes && taxCalRes.map((ele, i)=>{
        // Accumulate total tax
        totalTax += ele?.totalTaxAmount || 0;
        // Return JSX for tax item
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex items-center py-2 text-sm w-full font-semibold text-gray-500 last:border-b-0 last:text-base last:pb-0",
            children: [
                formatTaxInfo(ele?.tax),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: "ml-auto flex-shrink-0 text-gray-800 font-bold",
                    children: [
                        currency,
                        ele?.totalTaxAmount?.toFixed(2)
                    ]
                })
            ]
        }, i);
    });
    let totalTaxByType = {};
    // Iterate through each element in taxCalRes
    taxCalRes && taxCalRes.forEach((ele)=>{
        // Iterate through each tax type within the tax object
        Object.keys(ele.tax).forEach((taxType)=>{
            // Iterate through each tax detail within the tax type
            ele.tax[taxType].forEach((taxDetail)=>{
                // Accumulate tax amount for each tax name
                if (taxDetail.taxName in totalTaxByType) {
                    totalTaxByType[taxDetail.taxName] += taxDetail.taxAmount;
                } else {
                    totalTaxByType[taxDetail.taxName] = taxDetail.taxAmount;
                }
            });
        });
    });
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_layout_Layout__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
            title: "Checkout",
            description: "this is checkout page",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "mx-auto max-w-screen-2xl px-3 sm:px-10",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "py-10 lg:py-12 px-0 2xl:max-w-screen-2xl w-full xl:max-w-screen-xl flex flex-col md:flex-row lg:flex-row",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "md:w-full lg:w-3/5 flex h-full flex-col order-2 sm:order-1 lg:order-1",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "mt-5 md:mt-0 md:col-span-2",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    onSubmit: handleSubmit(submitHandler),
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "form-group",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                                                    className: "font-semibold font-serif text-base text-gray-700 pb-3",
                                                    children: [
                                                        "01.",
                                                        " ",
                                                        showingTranslateValue(storeCustomizationSetting?.checkout?.personal_details)
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "grid grid-cols-6 gap-6",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "col-span-6 sm:col-span-3",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_InputArea__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                                                    register: register,
                                                                    label: showingTranslateValue(storeCustomizationSetting?.checkout?.first_name),
                                                                    name: "firstName",
                                                                    type: "text",
                                                                    placeholder: "First Name"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_Error__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                                                    errorName: errors.firstName
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "col-span-6 sm:col-span-3",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_InputArea__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                                                    register: register,
                                                                    label: showingTranslateValue(storeCustomizationSetting?.checkout?.last_name),
                                                                    name: "lastName",
                                                                    type: "text",
                                                                    placeholder: "Last Name"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_Error__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                                                    errorName: errors.lastName
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "col-span-6 sm:col-span-3",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_InputArea__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                                                    register: register,
                                                                    label: showingTranslateValue(storeCustomizationSetting?.checkout?.email_address),
                                                                    name: "email",
                                                                    type: "email",
                                                                    placeholder: "youremail@gmail.com"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_Error__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                                                    errorName: errors.email
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "col-span-6 sm:col-span-3",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_InputArea__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                                                    register: register,
                                                                    label: showingTranslateValue(storeCustomizationSetting?.checkout?.checkout_phone),
                                                                    name: "contact",
                                                                    type: "tel",
                                                                    inputmode: "numeric",
                                                                    maxLength: 10,
                                                                    pattern: "[0-9]{10}",
                                                                    errMsg: "Please enter a 10-digit phone number",
                                                                    placeholder: "XXXX-XXXX-XX"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_Error__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                                                    errorName: errors.contact
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "col-span-6 sm:col-span-3",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_InputArea__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                                                register: register,
                                                                label: "GST Number",
                                                                name: "gstnumber",
                                                                type: "text",
                                                                placeholder: "22AAAAA0000A1Z5",
                                                                notRequiredField: true
                                                            })
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "form-group mt-12",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                                                    className: "font-semibold font-serif text-base text-gray-700 pb-3",
                                                    children: [
                                                        "02.",
                                                        " ",
                                                        showingTranslateValue(storeCustomizationSetting?.checkout?.shipping_details)
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "grid grid-cols-6 gap-6 mb-8",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "col-span-6",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_InputArea__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                                                    register: register,
                                                                    label: showingTranslateValue(storeCustomizationSetting?.checkout?.street_address),
                                                                    name: "address",
                                                                    type: "text",
                                                                    placeholder: "Full Address",
                                                                    handleInputData: handleAddress,
                                                                    requiredOnChange: true
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_Error__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                                                    errorName: errors.address
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "col-span-6 sm:col-span-6 lg:col-span-2",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_Label__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {
                                                                    label: "State"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: "flex-grow-0 md:flex-grow lg:flex-grow xl:flex-grow ",
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("select", {
                                                                        onChange: (e)=>setShippingState(e.target.value),
                                                                        value: shippingState,
                                                                        className: "border h-12 text-sm focus:outline-none block w-full rounded bg-gray-100 border-transparent focus:bg-white",
                                                                        children: data?.stateDetails?.map((ele, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                                value: ele?.name,
                                                                                children: ele?.name
                                                                            }, i))
                                                                    })
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "col-span-6 sm:col-span-6 lg:col-span-2",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_InputArea__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                                                    register: register,
                                                                    label: showingTranslateValue(storeCustomizationSetting?.checkout?.city),
                                                                    name: "city",
                                                                    type: "text",
                                                                    placeholder: "City",
                                                                    handleInputData: handleAddress,
                                                                    requiredOnChange: true
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_Error__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                                                    errorName: errors.city
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "col-span-6 sm:col-span-3 lg:col-span-2",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_InputArea__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                                                    register: register,
                                                                    label: showingTranslateValue(storeCustomizationSetting?.checkout?.zip_code),
                                                                    name: "zipCode",
                                                                    type: "text",
                                                                    placeholder: "PIN code",
                                                                    handleInputData: handleAddress,
                                                                    requiredOnChange: true
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_Error__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                                                    errorName: errors.zipCode
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "form-group mt-12",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "flex justify-between gap-1 items-center",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                            className: "font-semibold font-serif text-base text-gray-700 pb-3",
                                                            children: "03.Billing Details"
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                            className: "text-sm text-zinc-700",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                    type: "checkbox",
                                                                    onChange: (e)=>handleSameDetails(e),
                                                                    className: "border border-green-500 rounded"
                                                                }),
                                                                " ",
                                                                "Same as Shipping details"
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "grid grid-cols-6 gap-6 mb-8",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "col-span-6",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_InputArea__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                                                    register: register,
                                                                    label: showingTranslateValue(storeCustomizationSetting?.checkout?.street_address),
                                                                    name: "BIllingAddress",
                                                                    type: "text",
                                                                    placeholder: "Full Address"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_Error__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                                                    errorName: errors.address
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "col-span-6 sm:col-span-6 lg:col-span-2",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_Label__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {
                                                                    label: "State"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: "flex-grow-0 md:flex-grow lg:flex-grow xl:flex-grow ",
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("select", {
                                                                        onChange: (e)=>setBillingState(e.target.value),
                                                                        value: billingState,
                                                                        className: "border h-12 text-sm focus:outline-none block w-full rounded bg-gray-100 border-transparent focus:bg-white",
                                                                        children: data?.stateDetails?.map((ele, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                                value: ele?.name,
                                                                                children: ele?.name
                                                                            }, i))
                                                                    })
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "col-span-6 sm:col-span-6 lg:col-span-2",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_InputArea__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                                                    register: register,
                                                                    label: showingTranslateValue(storeCustomizationSetting?.checkout?.city),
                                                                    name: "BIllingCity",
                                                                    type: "text",
                                                                    placeholder: "City"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_Error__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                                                    errorName: errors.city
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "col-span-6 sm:col-span-3 lg:col-span-2",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_InputArea__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                                                    register: register,
                                                                    label: showingTranslateValue(storeCustomizationSetting?.checkout?.zip_code),
                                                                    name: "BIllingZipCode",
                                                                    type: "text",
                                                                    placeholder: "PIN Code"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_Error__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                                                    errorName: errors.zipCode
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "form-group mt-12",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                                                    className: "font-semibold font-serif text-base text-gray-700 pb-3",
                                                    children: [
                                                        "04.",
                                                        " ",
                                                        showingTranslateValue(storeCustomizationSetting?.checkout?.shipping_cost)
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "grid grid-cols-6 gap-6",
                                                    children: shippingDetails && shippingDetails?.map((item, i)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "col-span-6 sm:col-span-3",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_InputShipping__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z, {
                                                                    currency: currency,
                                                                    handleShippingCost: handleShippingCost,
                                                                    register: register,
                                                                    Image: item?.icon,
                                                                    value: item?.shippingMethod,
                                                                    time: item?.deliveryTime,
                                                                    cost: item?.cost,
                                                                    id: item._id
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_Error__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                                                    errorName: errors.shippingOption
                                                                }),
                                                                selectItemId === item._id && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                            type: "text",
                                                                            ...register(`personInfo`, {
                                                                                required: `Contact person name is required!`
                                                                            }),
                                                                            name: "personInfo",
                                                                            onChange: (e)=>handleShippingPersonInfo(e.target.value),
                                                                            placeholder: "Contact person name",
                                                                            className: "placeholder:text-[12px] placeholder:text-zinc-400 w-full border-none rounded my-1 shadow-md focus:border-green-700"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_Error__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                                                            errorName: errors.personInfo
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                            type: "tel",
                                                                            ...register(`contactInfo`, {
                                                                                required: `Contact person  number is required!`
                                                                            }),
                                                                            name: "contactInfo",
                                                                            onChange: (e)=>handleShippingContactInfo(e.target.value),
                                                                            inputmode: "numeric",
                                                                            maxLength: 10,
                                                                            pattern: "[0-9]{10}",
                                                                            title: "Please enter a 10-digit phone number",
                                                                            placeholder: "Contact person number",
                                                                            className: "placeholder:text-[12px] placeholder:text-zinc-400 w-full border-none rounded my-1 shadow-md focus:border-green-700"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_Error__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                                                            errorName: errors.contactInfo
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        }, i))
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "form-group mt-12",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                                                    className: "font-semibold font-serif text-base text-gray-700 pb-3",
                                                    children: [
                                                        "05.",
                                                        " ",
                                                        showingTranslateValue(storeCustomizationSetting?.checkout?.payment_method)
                                                    ]
                                                }),
                                                showCard && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "mb-3",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stripe_react_stripe_js__WEBPACK_IMPORTED_MODULE_5__.CardElement, {}),
                                                        " ",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            className: "text-red-400 text-sm mt-1",
                                                            children: error
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "grid grid-cols-6 gap-6",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "col-span-6 sm:col-span-3",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_InputPayment__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                                                                    setShowCard: setShowCard,
                                                                    register: register,
                                                                    name: t("common:cashOnDelivery"),
                                                                    value: "Cash",
                                                                    Icon: react_icons_io5__WEBPACK_IMPORTED_MODULE_7__.IoWalletSharp
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_Error__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                                                    errorName: errors.paymentMethod
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "col-span-6 sm:col-span-3",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_InputPayment__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                                                                    setShowCard: setShowCard,
                                                                    register: register,
                                                                    name: t("common:creditCard"),
                                                                    value: "Card",
                                                                    Icon: react_icons_im__WEBPACK_IMPORTED_MODULE_8__.ImCreditCard
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_form_Error__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                                                    errorName: errors.paymentMethod
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "grid grid-cols-6 gap-4 lg:gap-6 mt-10",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-span-6 sm:col-span-3",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                        href: "/",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                                            className: "bg-indigo-50 border border-indigo-100 rounded py-3 text-center text-sm font-medium text-gray-700 hover:text-gray-800 hover:border-gray-300 transition-all flex justify-center font-serif w-full",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                    className: "text-xl mr-2",
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io5__WEBPACK_IMPORTED_MODULE_7__.IoReturnUpBackOutline, {})
                                                                }),
                                                                showingTranslateValue(storeCustomizationSetting?.checkout?.continue_button)
                                                            ]
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-span-6 sm:col-span-3",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                        type: "submit",
                                                        disabled: isEmpty || !stripe || isCheckoutSubmit,
                                                        className: "bg-gray-800 hover:bg-gray-600 border border-gray-500 transition-all rounded py-3 text-center text-sm font-serif font-medium text-white flex justify-center w-full",
                                                        children: isCheckoutSubmit ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                            className: "flex justify-center text-center",
                                                            children: [
                                                                " ",
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                    src: "/loader/spinner.gif",
                                                                    alt: "Loading",
                                                                    width: 20,
                                                                    height: 10
                                                                }),
                                                                " ",
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                    className: "ml-2",
                                                                    children: t("common:processing")
                                                                })
                                                            ]
                                                        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                            className: "flex justify-center text-center",
                                                            children: [
                                                                showingTranslateValue(storeCustomizationSetting?.checkout?.confirm_button),
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                    className: "text-xl ml-2",
                                                                    children: [
                                                                        " ",
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io5__WEBPACK_IMPORTED_MODULE_7__.IoArrowForward, {})
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "md:w-full lg:w-2/5 lg:ml-10 xl:ml-14 md:ml-6 flex flex-col h-full md:sticky lg:sticky top-28 md:order-2 lg:order-2",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "border p-5 lg:px-8 lg:py-8 rounded-lg bg-white order-1 sm:order-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                        className: "font-semibold font-serif text-lg pb-4",
                                        children: showingTranslateValue(storeCustomizationSetting?.checkout?.order_summary)
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "overflow-y-scroll flex-grow scrollbar-hide w-full max-h-64 bg-gray-50 block",
                                        children: [
                                            items.map((item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_cart_CartItem__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                    item: item,
                                                    currency: currency
                                                }, item.id)),
                                            isEmpty && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "text-center py-10",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "flex justify-center my-auto text-gray-500 font-semibold text-4xl",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io5__WEBPACK_IMPORTED_MODULE_7__.IoBagHandle, {})
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                        className: "font-medium font-serif text-sm pt-2 text-gray-600",
                                                        children: "No Item Added Yet!"
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "flex items-center mt-4 py-4 lg:py-4 text-sm w-full font-semibold text-heading last:border-b-0 last:text-base last:pb-0",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                                            className: "w-full",
                                            children: couponInfo.couponCode ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                className: "bg-gray-50 px-4 py-3 leading-tight w-full rounded-md flex justify-between",
                                                children: [
                                                    " ",
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                        className: "text-gray-600",
                                                        children: "Coupon Applied "
                                                    }),
                                                    " ",
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "text-red-500 text-right",
                                                        children: couponInfo.couponCode
                                                    })
                                                ]
                                            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "flex flex-col sm:flex-row items-start justify-end",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                        ref: couponRef,
                                                        type: "text",
                                                        placeholder: t("common:couponCode"),
                                                        className: "form-input py-2 px-3 md:px-4 w-full appearance-none transition ease-in-out border text-input text-sm rounded-md h-12 duration-200 bg-white border-gray-200 focus:ring-0 focus:outline-none focus:border-gray-500 placeholder-gray-500 placeholder-opacity-75"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                        onClick: handleCouponCode,
                                                        className: "md:text-sm leading-4 inline-flex items-center cursor-pointer transition ease-in-out duration-300 font-semibold text-center justify-center border border-gray-200 rounded-md placeholder-white focus-visible:outline-none focus:outline-none px-5 md:px-6 lg:px-8 py-3 md:py-3.5 lg:py-3 mt-3 sm:mt-0 sm:ml-3 md:mt-0 md:ml-3 lg:mt-0 lg:ml-3 hover:text-white hover:bg-gray-800 h-12 text-sm lg:text-base w-full sm:w-auto",
                                                        children: showingTranslateValue(storeCustomizationSetting?.checkout?.apply_button)
                                                    })
                                                ]
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex items-center py-2 text-sm w-full font-semibold text-gray-500 last:border-b-0 last:text-base last:pb-0",
                                        children: [
                                            showingTranslateValue(storeCustomizationSetting?.checkout?.sub_total),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                className: "ml-auto flex-shrink-0 text-gray-800 font-bold",
                                                children: [
                                                    currency,
                                                    totalSalePrice
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex items-center py-2 text-sm w-full font-semibold text-gray-500 last:border-b-0 last:text-base last:pb-0",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "mr-auto",
                                                children: "Total Tax:"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                className: "ml-auto flex-shrink-0 text-gray-800 font-bold",
                                                children: [
                                                    currency,
                                                    totalTax.toFixed(2)
                                                ]
                                            })
                                        ]
                                    }),
                                    Object.keys(totalTaxByType).map((taxName, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex items-center py-2 text-sm w-full font-semibold text-gray-500 last:border-b-0 last:text-base last:pb-0",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                    className: "mr-auto",
                                                    children: [
                                                        taxName,
                                                        " Tax:"
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                    className: "ml-auto flex-shrink-0 text-gray-800 font-bold",
                                                    children: [
                                                        currency,
                                                        totalTaxByType[taxName].toFixed(2)
                                                    ]
                                                })
                                            ]
                                        }, index)),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex items-center py-2 text-sm w-full font-semibold text-gray-500 last:border-b-0 last:text-base last:pb-0",
                                        children: [
                                            showingTranslateValue(storeCustomizationSetting?.checkout?.shipping_cost),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                className: "ml-auto flex-shrink-0 text-gray-800 font-bold",
                                                children: [
                                                    currency,
                                                    shippingCost.toFixed(2)
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex items-center py-2 text-sm w-full font-semibold text-gray-500 last:border-b-0 last:text-base last:pb-0",
                                        children: [
                                            showingTranslateValue(storeCustomizationSetting?.checkout?.discount),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                className: "ml-auto flex-shrink-0 font-bold text-orange-400",
                                                children: [
                                                    currency,
                                                    discountAmount.toFixed(2)
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "border-t mt-4",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex items-center font-bold font-serif justify-between pt-5 text-sm uppercase",
                                            children: [
                                                showingTranslateValue(storeCustomizationSetting?.checkout?.total_cost),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                    className: "font-serif font-extrabold text-lg",
                                                    children: [
                                                        currency,
                                                        parseFloat(total).toFixed(2)
                                                    ]
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        })
                    ]
                })
            })
        })
    });
};
const __Page_Next_Translate__ = next_dynamic__WEBPACK_IMPORTED_MODULE_4___default()(()=>Promise.resolve(Checkout), {
    ssr: false
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (next_translate_appWithI18n__WEBPACK_IMPORTED_MODULE_2___default()(__Page_Next_Translate__, {
    ..._next_translate_root_i18n__WEBPACK_IMPORTED_MODULE_1__,
    isLoader: true,
    skipInitialProps: false,
    loadLocaleFrom: (l, n)=>__webpack_require__(7655)(`./${l}/${n}`).then((m)=>m.default)
}));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5644:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _httpServices__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8272);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_httpServices__WEBPACK_IMPORTED_MODULE_0__]);
_httpServices__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const AboutServices = {
    getAbout: async ()=>{
        return _httpServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get("/about");
    },
    getContact: async ()=>{
        return _httpServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get("/setting/global/all");
    },
    getState: async ()=>{
        return _httpServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get("/state");
    },
    getContact: async (body)=>{
        return _httpServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post("/contact", body);
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AboutServices);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8768:
/***/ ((module) => {

module.exports = require("@heroicons/react/outline");

/***/ }),

/***/ 6999:
/***/ ((module) => {

module.exports = require("@react-oauth/google");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 4515:
/***/ ((module) => {

module.exports = require("@stripe/react-stripe-js");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 1635:
/***/ ((module) => {

module.exports = require("dayjs");

/***/ }),

/***/ 5668:
/***/ ((module) => {

module.exports = require("next-translate/appWithI18n");

/***/ }),

/***/ 866:
/***/ ((module) => {

module.exports = require("next-translate/useTranslation");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 5832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 5307:
/***/ ((module) => {

module.exports = require("rc-drawer");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6358:
/***/ ((module) => {

module.exports = require("react-dropzone");

/***/ }),

/***/ 2750:
/***/ ((module) => {

module.exports = require("react-icons/fi");

/***/ }),

/***/ 924:
/***/ ((module) => {

module.exports = require("react-icons/im");

/***/ }),

/***/ 9989:
/***/ ((module) => {

module.exports = require("react-icons/io5");

/***/ }),

/***/ 4152:
/***/ ((module) => {

module.exports = require("react-icons/tb");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 6158:
/***/ ((module) => {

module.exports = require("react-share");

/***/ }),

/***/ 2633:
/***/ ((module) => {

module.exports = require("react-spinners/ScaleLoader");

/***/ }),

/***/ 1187:
/***/ ((module) => {

module.exports = require("react-toastify");

/***/ }),

/***/ 9878:
/***/ ((module) => {

module.exports = require("react-use-cart");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = import("@headlessui/react");;

/***/ }),

/***/ 2905:
/***/ ((module) => {

module.exports = import("html-react-parser");;

/***/ }),

/***/ 9915:
/***/ ((module) => {

module.exports = import("js-cookie");;

/***/ }),

/***/ 5641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ }),

/***/ 4275:
/***/ ((module) => {

module.exports = import("react-loading-skeleton");;

/***/ }),

/***/ 4612:
/***/ ((module) => {

module.exports = import("socket.io-client");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [678,138,378,399,408,812,354,440,8,286], () => (__webpack_exec__(5562)));
module.exports = __webpack_exports__;

})();