(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 7655:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var map = {
	"./de/common": [
		1545,
		545
	],
	"./de/common.json": [
		1545,
		545
	],
	"./en/common": [
		464,
		464
	],
	"./en/common.json": [
		464,
		464
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(() => {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return __webpack_require__.e(ids[1]).then(() => {
		return __webpack_require__.t(id, 3 | 16);
	});
}
webpackAsyncContext.keys = () => (Object.keys(map));
webpackAsyncContext.id = 7655;
module.exports = webpackAsyncContext;

/***/ }),

/***/ 4514:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ common_DefaultSeo)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: external "next-seo"
const external_next_seo_namespaceObject = require("next-seo");
;// CONCATENATED MODULE: ./src/component/common/DefaultSeo.js



const DefaultSeo = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(external_next_seo_namespaceObject.DefaultSeo, {
        title: "EcommEdge",
        openGraph: {
            type: "website",
            locale: "en_IE",
            url: "https://TriDyota-store.vercel.app/",
            site_name: "EcommEdge"
        },
        twitter: {
            handle: "@handle",
            site: "@site",
            cardType: "summary_large_image"
        },
        additionalMetaTags: [
            {
                name: "viewport",
                content: "minimum-scale=1, initial-scale=1, width=device-width, shrink-to-fit=no, viewport-fit=cover"
            },
            {
                name: "apple-mobile-web-app-capable",
                content: "yes"
            },
            {
                name: "theme-color",
                content: "#ffffff"
            }, 
        ],
        additionalLinkTags: [
            {
                rel: "apple-touch-icon",
                href: "/icon-192x192.png"
            },
            {
                rel: "manifest",
                href: "/manifest.json"
            }, 
        ]
    });
};
/* harmony default export */ const common_DefaultSeo = (DefaultSeo);


/***/ }),

/***/ 5376:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A": () => (/* binding */ useOrder),
/* harmony export */   "u": () => (/* binding */ OrderProvider)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


// Create the OrderContext
const OrderContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)();
// Create the OrderProvider
const OrderProvider = ({ children  })=>{
    const { 0: order , 1: setOrder  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null); // State to hold order data
    // Function to set order data
    const setOrderData = (data)=>{
        setOrder(data);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(OrderContext.Provider, {
        value: {
            order,
            setOrderData
        },
        children: children
    });
};
// Custom hook to consume the context
const useOrder = ()=>{
    const context = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(OrderContext);
    if (!context) {
        throw new Error("useOrder must be used within an OrderProvider");
    }
    return context;
};


/***/ }),

/***/ 4587:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _next_translate_root_i18n__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(608);
/* harmony import */ var next_translate_appWithI18n__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5668);
/* harmony import */ var next_translate_appWithI18n__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_translate_appWithI18n__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_use_cart__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9878);
/* harmony import */ var react_use_cart__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_use_cart__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _stripe_react_stripe_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4515);
/* harmony import */ var _stripe_react_stripe_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_stripe_react_stripe_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _react_oauth_google__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6999);
/* harmony import */ var _react_oauth_google__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_react_oauth_google__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var redux_persist_integration_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1127);
/* harmony import */ var redux_persist_integration_react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(redux_persist_integration_react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var redux_persist__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4161);
/* harmony import */ var redux_persist__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(redux_persist__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _redux_store__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7946);
/* harmony import */ var _utils_stripe__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9420);
/* harmony import */ var _context_UserContext__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5408);
/* harmony import */ var _component_common_DefaultSeo__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(4514);
/* harmony import */ var _context_SidebarContext__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(6812);
/* harmony import */ var _context_OrderContext__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(5376);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_context_UserContext__WEBPACK_IMPORTED_MODULE_11__, _context_SidebarContext__WEBPACK_IMPORTED_MODULE_13__]);
([_context_UserContext__WEBPACK_IMPORTED_MODULE_11__, _context_SidebarContext__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










//internal import






const stripePromise = (0,_utils_stripe__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)();
let persistor = (0,redux_persist__WEBPACK_IMPORTED_MODULE_7__.persistStore)(_redux_store__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z);
function MyApp({ Component , pageProps  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_oauth_google__WEBPACK_IMPORTED_MODULE_5__.GoogleOAuthProvider, {
            clientId: "your_google_api_client",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_context_UserContext__WEBPACK_IMPORTED_MODULE_11__/* .UserProvider */ .d, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_context_OrderContext__WEBPACK_IMPORTED_MODULE_14__/* .OrderProvider */ .u, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_redux__WEBPACK_IMPORTED_MODULE_8__.Provider, {
                        store: _redux_store__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(redux_persist_integration_react__WEBPACK_IMPORTED_MODULE_6__.PersistGate, {
                            loading: null,
                            persistor: persistor,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_context_SidebarContext__WEBPACK_IMPORTED_MODULE_13__/* .SidebarProvider */ .H, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stripe_react_stripe_js__WEBPACK_IMPORTED_MODULE_4__.Elements, {
                                    stripe: stripePromise,
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_use_cart__WEBPACK_IMPORTED_MODULE_3__.CartProvider, {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_common_DefaultSeo__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {}),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                                                ...pageProps
                                            })
                                        ]
                                    })
                                })
                            })
                        })
                    })
                })
            })
        })
    });
}
const __Page_Next_Translate__ = MyApp;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (next_translate_appWithI18n__WEBPACK_IMPORTED_MODULE_2___default()(__Page_Next_Translate__, {
    ..._next_translate_root_i18n__WEBPACK_IMPORTED_MODULE_1__,
    isLoader: true,
    skipInitialProps: true,
    loadLocaleFrom: (l, n)=>__webpack_require__(7655)(`./${l}/${n}`).then((m)=>m.default)
}));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7946:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ store)
});

;// CONCATENATED MODULE: external "redux-persist/lib/storage/session"
const session_namespaceObject = require("redux-persist/lib/storage/session");
var session_default = /*#__PURE__*/__webpack_require__.n(session_namespaceObject);
// EXTERNAL MODULE: external "@reduxjs/toolkit"
var toolkit_ = __webpack_require__(5184);
// EXTERNAL MODULE: external "redux-persist"
var external_redux_persist_ = __webpack_require__(4161);
;// CONCATENATED MODULE: ./src/redux/slice/dynamicDataSlice.js

const uniqueArrayOfObjects = (arr)=>{
    const map = new Map();
    arr?.forEach((obj)=>map.set(obj?._id, obj));
    return Array.from(map?.values());
};
const dynamicDataSlice = (0,toolkit_.createSlice)({
    name: "data",
    initialState: {
        dynamicData: []
    },
    reducers: {
        addData: (state, action)=>{
            const existsItem = state.dynamicData.find((x)=>x.name === action.payload.name);
            if (existsItem) {
                return {
                    ...state,
                    dynamicData: state.dynamicData.map((x)=>{
                        if (x.name === existsItem.name) {
                            return x;
                        }
                        return x;
                    })
                };
            } else {
                return {
                    ...state,
                    dynamicData: [
                        ...state.dynamicData,
                        action.payload
                    ]
                };
            }
        },
        addSingleData: (state, action)=>{
            const singleItem = state.dynamicData.find((x)=>x.name === action.payload.name);
            const items = state.dynamicData.filter((x)=>x.name !== action.payload.name);
            const uniqueArray = uniqueArrayOfObjects([
                ...singleItem?.data,
                action.payload.data, 
            ]);
            const dynamicData = [
                ...items,
                {
                    name: singleItem.name,
                    data: uniqueArray
                }, 
            ];
            return {
                ...state,
                dynamicData: dynamicData
            };
        },
        updateSingleData: (state, action)=>{
            // find single item
            const updatedItem = state.dynamicData.find((x)=>x.name === action.payload.name);
            const notUpdatedItems = state.dynamicData.filter((x)=>x.name !== action.payload.name);
            const result = updatedItem?.data?.filter((el)=>el?._id !== action?.payload?.data?._id);
            const updatedArr = [
                ...result,
                action?.payload?.data
            ];
            const updatedData = [
                ...notUpdatedItems,
                {
                    name: updatedItem.name,
                    data: updatedArr
                }, 
            ];
            return {
                ...state,
                dynamicData: updatedData
            };
        },
        updateMultipleData: (state, action)=>{
            // console.log("action.payload>>>>", action.payload);
            const updatedMultipleItem = state.dynamicData.find((x)=>x.name === action.payload.name);
            const notUpdatedMultipleItems = state.dynamicData.filter((x)=>x.name !== action.payload.name);
            const multipleUpdatedData = updatedMultipleItem?.data?.filter((el)=>!action?.payload?.ids?.includes(el?._id));
            const updatedFinalArr = [
                ...multipleUpdatedData,
                ...action?.payload?.data, 
            ];
            const updatedDatMultiple = [
                ...notUpdatedMultipleItems,
                {
                    name: updatedMultipleItem.name,
                    data: updatedFinalArr
                }, 
            ];
            return {
                ...state,
                dynamicData: updatedDatMultiple
            };
        },
        removeData: (state, action)=>{
            return {
                ...state,
                dynamicData: state.dynamicData.filter((x)=>x.name !== action.payload)
            };
        },
        removeSingleData: (state, action)=>{
            // find single item
            const singleRemoveItem = state.dynamicData.find((x)=>x.name === action.payload.name);
            const notUpdatedRemovedData = state.dynamicData?.filter((x)=>x.name !== action.payload.name);
            const updatedSingleRemovedData = singleRemoveItem?.data?.filter((el)=>el?._id !== action?.payload.id);
            const dynamicDataSingleRemoved = [
                ...notUpdatedRemovedData,
                {
                    name: singleRemoveItem.name,
                    data: updatedSingleRemovedData
                }, 
            ];
            return {
                ...state,
                dynamicData: dynamicDataSingleRemoved
            };
        },
        removeMultipleData: (state, action)=>{
            // find single item
            const multipleRemoveItem = state.dynamicData.find((x)=>x.name === action.payload.name);
            const notUpdatedMultipleRemovedData = state.dynamicData?.filter((x)=>x.name !== action.payload.name);
            const updatedMultipleRemovedData = multipleRemoveItem?.data?.filter((el)=>!action?.payload?.ids?.includes(el?._id));
            const dynamicDataMultipleRemoved = [
                ...notUpdatedMultipleRemovedData,
                {
                    name: multipleRemoveItem.name,
                    data: updatedMultipleRemovedData
                }, 
            ];
            return {
                ...state,
                dynamicData: dynamicDataMultipleRemoved
            };
        },
        clearData: (state)=>{
            return {
                ...state,
                dynamicData: []
            };
        }
    }
});
const { addData , clearData , removeData , addSingleData , updateSingleData , updateMultipleData , removeSingleData , removeMultipleData ,  } = dynamicDataSlice.actions;
/* harmony default export */ const slice_dynamicDataSlice = (dynamicDataSlice.reducer);

// EXTERNAL MODULE: ./src/redux/slice/settingSlice.js
var settingSlice = __webpack_require__(4636);
;// CONCATENATED MODULE: ./src/redux/store.js
// import storage from "redux-persist/lib/storage";





const persistConfig = {
    key: "root",
    version: 1,
    storage: (session_default()),
    blacklist: [
        "/"
    ]
};
const rootReducer = (0,toolkit_.combineReducers)({
    setting: settingSlice/* default */.ZP,
    data: slice_dynamicDataSlice
});
const persistedReducer = (0,external_redux_persist_.persistReducer)(persistConfig, rootReducer);
const reduxStore = (0,toolkit_.configureStore)({
    reducer: persistedReducer,
    middleware: (getDefaultMiddleware)=>getDefaultMiddleware({
            serializableCheck: {
                ignoredActions: [
                    external_redux_persist_.FLUSH,
                    external_redux_persist_.REHYDRATE,
                    external_redux_persist_.PAUSE,
                    external_redux_persist_.PERSIST,
                    external_redux_persist_.PURGE,
                    external_redux_persist_.REGISTER
                ]
            }
        })
});
/* harmony default export */ const store = (reduxStore);


/***/ }),

/***/ 9420:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ stripe)
});

;// CONCATENATED MODULE: external "@stripe/stripe-js"
const stripe_js_namespaceObject = require("@stripe/stripe-js");
;// CONCATENATED MODULE: ./src/utils/stripe.js

let stripePromise;
const getStripe = ()=>{
    if (!stripePromise) {
        stripePromise = (0,stripe_js_namespaceObject.loadStripe)(`${"pk_test_51OAq4nSIYmhT6lykZvPtQvTMEpfyDS4cmDVYsH3C6koUxX4d1Anx8Ud80hEENL3zZl8LL3ruPhzZ7UgF2LYMDO64006IClGbJX"}` || 0);
    }
    return stripePromise;
};
/* harmony default export */ const stripe = (getStripe);


/***/ }),

/***/ 6999:
/***/ ((module) => {

"use strict";
module.exports = require("@react-oauth/google");

/***/ }),

/***/ 5184:
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 4515:
/***/ ((module) => {

"use strict";
module.exports = require("@stripe/react-stripe-js");

/***/ }),

/***/ 5668:
/***/ ((module) => {

"use strict";
module.exports = require("next-translate/appWithI18n");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 9878:
/***/ ((module) => {

"use strict";
module.exports = require("react-use-cart");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 4161:
/***/ ((module) => {

"use strict";
module.exports = require("redux-persist");

/***/ }),

/***/ 1127:
/***/ ((module) => {

"use strict";
module.exports = require("redux-persist/integration/react");

/***/ }),

/***/ 9915:
/***/ ((module) => {

"use strict";
module.exports = import("js-cookie");;

/***/ }),

/***/ 4612:
/***/ ((module) => {

"use strict";
module.exports = import("socket.io-client");;

/***/ }),

/***/ 608:
/***/ ((module) => {

"use strict";
module.exports = JSON.parse('{"locales":["en","de"],"defaultLocale":"en","pages":{"*":["common"]}}');

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [408,812], () => (__webpack_exec__(4587)));
module.exports = __webpack_exports__;

})();